/* Quantum — ponte nativa (Capacitor).
   Na web/PWA não faz nada. No APK, usa os plugins que estiverem instalados (cada um é opcional):
   @capacitor/status-bar · @capacitor/app · @capacitor/splash-screen · @capacitor/keyboard · @capacitor/camera (usado em script.js) */
(()=>{
  const C=window.Capacitor;
  if(!C||!C.isNativePlatform||!C.isNativePlatform())return;
  document.documentElement.classList.add('is-native');

  const P=n=>{try{return(C.Plugins&&C.Plugins[n])||null}catch(e){return null}};
  const run=(fn)=>{try{const r=fn();r&&r.catch&&r.catch(()=>{})}catch(e){}};
  const COR='#05080F';

  /* Barra de status: fundo igual ao do app, ícones claros; a WebView não fica por baixo dela */
  const sb=P('StatusBar');
  if(sb){
    run(()=>sb.setStyle({style:'DARK'}));            /* DARK = ícones claros em fundo escuro */
    run(()=>sb.setBackgroundColor({color:COR}));      /* só Android */
    run(()=>sb.setOverlaysWebView({overlay:false}));
  }

  /* Botão "voltar" do Android: volta na navegação do app; na raiz, sai */
  const ap=P('App');
  if(ap&&ap.addListener){
    run(()=>ap.addListener('backButton',e=>{
      if(e&&e.canGoBack)history.back();
      else if(ap.exitApp)run(()=>ap.exitApp());
    }));
  }

  /* Splash: a duração vem do capacitor.config.json; aqui só garantimos o fecho quando o app carregou */
  const sp=P('SplashScreen');
  if(sp&&sp.hide)window.addEventListener('load',()=>run(()=>sp.hide()),{once:true});

  /* Teclado: o layout redimensiona (configurável em plugins.Keyboard no capacitor.config.json) */
  /* const kb=P('Keyboard'); if(kb){ kb.addListener('keyboardWillShow',()=>document.body.classList.add('kb-on')); kb.addListener('keyboardWillHide',()=>document.body.classList.remove('kb-on')); } */
})();
