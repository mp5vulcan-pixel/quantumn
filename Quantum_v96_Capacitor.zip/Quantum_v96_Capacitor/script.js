const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const I=n=>`<svg class="i"><use href="#${n}"/></svg>`;

/* ===== v91: Cloudinary (upload unsigned) ===== */
const CLD={cloud:'whv2grgm',preset:'quantum_uploads',maxImg:10*1024*1024,maxVid:100*1024*1024}; /* limites do plano grátis do Cloudinary */
CLD.url='https://api.cloudinary.com/v1_1/'+CLD.cloud+'/auto/upload';
const cldOk=v=>typeof v=='string'&&v.length<=700&&v.startsWith('https://res.cloudinary.com/'+CLD.cloud+'/'); /* só aceita URLs da NOSSA conta */
/* envia File/Blob por FormData e devolve a secure_url (opt.signal permite cancelar) */
async function uploadToCloudinary(file,opt){
 if(!file)throw new Error('Nenhum arquivo.');
 const fd=new FormData();fd.append('file',file,file.name||((file.type||'').startsWith('video/')?'video.mp4':'foto.jpg'));fd.append('upload_preset',CLD.preset);
 let r;try{r=await fetch(CLD.url,{method:'POST',body:fd,signal:opt&&opt.signal})}catch(e){if(e&&e.name=='AbortError')throw e;throw new Error('Sem ligação à internet.')}
 let j={};try{j=await r.json()}catch(e){}
 if(!r.ok||!j.secure_url)throw new Error((j.error&&j.error.message)||'Falha no upload.');
 return j.secure_url}
/* canvas → Blob → Cloudinary */
const cldCanvas=(c,mime,q,opt)=>new Promise((ok,no)=>c.toBlob(b=>b?ok(uploadToCloudinary(new File([b],'img.'+({'image/png':'png','image/webp':'webp'}[b.type]||'jpg'),{type:b.type}),opt)):no(new Error('Não foi possível preparar a imagem.')),mime,q));
/* aviso de "Enviando…" por cima da tela (usado nos uploads do editor de página) */
function cldBusy(on,txt){let o=$('#cldov');if(!o){o=document.createElement('div');o.id='cldov';o.className='cld-ov';o.hidden=true;o.setAttribute('role','status');o.innerHTML='<div><span class="spin"></span><span></span></div>';document.body.appendChild(o)}
 o.firstChild.lastChild.textContent=txt||'Enviando…';o.hidden=!on}
const today=()=>new Date().toISOString().slice(0,10);

/* ===== v90: sons (MP3 reais em sons/) e vibração — estilo app nativo ===== */
const SoundManager={
 files:{tap:'sons/tap.mp3',send:'sons/send.mp3',receive:'sons/receive.mp3',success:'sons/success.mp3',error:'sons/error.mp3'},
 vol:{tap:.5,send:.7,receive:.8,success:.8,error:.8},
 bad:{},unlocked:false
};
/* v96: 1 elemento <audio> reaproveitado por tipo (criar new Audio() a cada toque pesava na thread principal) */
const SND={};
function sndGet(type){
 const src=SoundManager.files[type];if(!src||SoundManager.bad[type])return null;
 let a=SND[type];
 if(!a){a=SND[type]=new Audio(src);a.preload='auto';
  /* ficheiro ainda não existe (ou formato recusado): marca e não tenta de novo */
  a.addEventListener('error',()=>{SoundManager.bad[type]=1;delete SND[type]},{once:true})}
 return a}
function playSound(type){
 try{
  const a=sndGet(type);if(!a)return;
  a.volume=SoundManager.vol[type]||.7;
  if(!a.paused&&!a.ended)a.currentTime=0;
  const p=a.play();if(p&&p.catch)p.catch(()=>{});
 }catch(e){}
}
/* o WebView do APK/Chrome só libera áudio depois do 1º toque: toca um WAV mudo embutido (não depende dos MP3) */
function unlockAudio(){
 if(SoundManager.unlocked)return;SoundManager.unlocked=true;
 (self.requestIdleCallback||setTimeout)(()=>{try{Object.keys(SoundManager.files).forEach(sndGet)}catch(e){}});
 ['pointerdown','touchend','click','keydown'].forEach(t=>removeEventListener(t,unlockAudio,true));
 try{const a=new Audio('data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=');a.volume=0;const p=a.play();if(p&&p.catch)p.catch(()=>{})}catch(e){}
}
['pointerdown','touchend','click','keydown'].forEach(t=>addEventListener(t,unlockAudio,{capture:true,passive:true}));
const Haptics={tap:10,success:[30,50,30],error:[100,50,100]};
function vibrate(type){try{const p=Haptics[type];if(p!=null&&navigator.vibrate)navigator.vibrate(p)}catch(e){}}
let _fxE=0;function errFx(){const n=Date.now();if(n-_fxE<700)return;_fxE=n;playSound('error');vibrate('error')}
const ERR_RX=/não foi possível|não conseguimos|não encontramos|incorret|inválid|sem permissão|sem ligação|sem internet|muitas tentativas|desativad|suspensa|já tem conta|já está em uso|pesado demais|erro|falha|bloquead|expirou|não autorizado|não está ativ|deve ter|não pode/i;
/* toque nos botões do dock, no avatar (menu) e nos "+" */
document.addEventListener('click',e=>{if(e.target.closest&&e.target.closest('.dk-tab,#avb,#msrnc,#edadd'))requestAnimationFrame(()=>playSound('tap'))},{capture:true,passive:true});
const blankProfile=()=>({name:'',bio:'',links:[],photo:'',username:'',goal:'',plats:[],bg:'',btn:'',look:cleanLook(),onboarded:false});
const PF_MAX=20;
/* ===== v38: aparência (look) — modelo e validação ===== */
const LK_FONTS=['inter','poppins','dmsans','montserrat','lora','playfair','sourceserif','bebas','oswald','abril','pacifico','caveat','dancing','spacemono','jetbrains','archivo','anton','lexend','orbitron','baskerville','spectral','eczar','cambo','croissant','limelight','monoton','piedra','tradewinds','chewy','shortstack','molle','oleo','lobster','righteous','permanentmarker','gloria','sacramento','parisienne','greatvibes','pinyon','allura','satisfy','yellowtail','tangerine','albert','belanosima','bricolage','epilogue','plex','lato','mplus','manrope','nunito','opensans','roboto','worksans','quicksand','raleway','spacegrotesk','rubik','outfit','sora','jakarta','fraunces'];
const LK_BG=['solid','gradient','blur','pattern','image','video'],LK_PAT=['dots','grid','checks','stripes'],LK_FX=['none','mono','blur','halftone'];
const LK_SHAPE=['square','round','pill'],LK_FILL=['solid','outline'],LK_SHADOW=['none','soft','hard'],LK_HOVER=['none','lift','grow','glow'];
const LK_PSIZE=['s','m','l'],LK_PSHAPE=['circle','squircle'],LK_SOC=['top','bottom'];
const LK_LAYOUT=['classic','hero','banner','crop','shape','fashion','sheet'],LK_LOGO_MAX=150000;
const SH_SONG_MAX=30000;
const SH_IC={mic:['Microfone','<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>'],music:['Música','<path d="M9 18V6l10-2v12"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="16" r="2"/>'],camera:['Câmara','<path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/>'],brush:['Pincel','<path d="M4 20c3 0 5-1 5-4a3 3 0 0 1 3-3l7-8-3-1-8 7a3 3 0 0 0-3 3c0 3-1 4-1 6z"/>'],code:['Código','<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M13.500 5l-3 14"/>'],star:['Estrela','<path d="M12 3l2.700 5.600 6.100.9-4.400 4.300 1 6.100L12 17l-5.400 2.900 1-6.100L3.200 9.500l6.100-.9z"/>'],bag:['Mala','<rect x="4" y="8" width="16" height="12" rx="2"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>'],heart:['Coração','<path d="M12 20s-7-4.500-7-10a4 4 0 0 1 7-2 4 4 0 0 1 7 2c0 5.500-7 10-7 10z"/>'],pen:['Caneta','<path d="M4 20l1-4L16 5l3 3L8 19z"/>'],film:['Cinema','<rect x="4" y="5" width="16" height="14" rx="2"/><path d="M4 9h16M4 15h16M8 5v14M16 5v14"/>']};
function cleanSh(x){x=x&&typeof x=='object'?x:{};const t=(v,d)=>typeof v=='string'?v.slice(0,24):d;
 const songs=(Array.isArray(x.songs)?x.songs:[]).slice(0,8).map(o=>o&&typeof o=='object'&&typeof o.i=='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(o.i)&&o.i.length<=SH_SONG_MAX?{i:o.i,c:t(o.c,'')}:null).filter(Boolean);
 const profs=Array.isArray(x.profs)?x.profs.slice(0,6).map(o=>o&&typeof o=='object'&&obP(o.p)&&typeof o.u=='string'&&/^https?:\/\//i.test(o.u)?{p:o.p,u:o.u.slice(0,300)}:null).filter(Boolean):null;
 return {chip:t(x.chip,'Criador'),ic:lkPick(x.ic,Object.keys(SH_IC),'star'),st:t(x.st,'Destaques'),pt:t(x.pt,'Perfis'),songs,profs}}
const LK_PHOTO_MAX=480000,LK_COVER_MAX=400000,LK_VIDEO_MAX=480000,LK_VIDEO_FILE=350*1024; /* foto de perfil (~350 KB) · capa: imagem (~300 KB) · vídeo curto (~350 KB) */
const LK_SHP={loop:'<ellipse cx="44" cy="31" rx="44" ry="29"/><ellipse cx="56" cy="69" rx="44" ry="29"/>',
 flor:'<circle cx="30" cy="30" r="28"/><circle cx="70" cy="30" r="28"/><circle cx="30" cy="70" r="28"/><circle cx="70" cy="70" r="28"/><rect x="25" y="25" width="50" height="50"/>',
 oval:'<ellipse cx="50" cy="50" rx="50" ry="40"/>',
 arredondado:'<rect x="2" y="6" width="96" height="88" rx="26"/>',
 arco:'<path d="M0 100V50A50 50 0 0 1 100 50V100z"/>',
 hexagono:'<polygon points="25,4 75,4 100,50 75,96 25,96 0,50"/>',
 estrela:'<polygon points="50,2 62,36 98,37 69,58 80,94 50,73 20,94 31,58 2,37 38,36"/>'};
const LK_SHPN=[['loop','Loop'],['flor','Flor'],['oval','Oval'],['arredondado','Arredondado'],['arco','Arco'],['hexagono','Hexágono'],['estrela','Estrela']];
const lkShapeUrl=id=>'url("data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none">'+(LK_SHP[id]||LK_SHP.loop)+'</svg>')+'")';
const LK_IMG_MAX=420000; /* caracteres do data: da imagem de fundo (~310 KB) */
/* codifica o canvas na melhor qualidade que cabe em max: baixa a qualidade aos poucos e só depois reduz o tamanho */
function qEnc(src,mime,q,max){let c=src,d=c.toDataURL(mime,q);if(!max)return d;
 for(let t=0;t<8;t++){for(let k=q;k>=.6;k-=.05){d=c.toDataURL(mime,k);if(d.length<=max)return d}
  const n=document.createElement('canvas');n.width=Math.max(64,Math.round(c.width*.88));n.height=Math.max(64,Math.round(c.height*.88));
  const x=n.getContext('2d');if(mime=='image/jpeg'){x.fillStyle='#fff';x.fillRect(0,0,n.width,n.height)}x.imageSmoothingQuality='high';x.drawImage(c,0,0,n.width,n.height);c=n}
 return d}
/* fontes VIP (Plus): só as que nenhum tema grátis usa. Para mudar, edite esta lista. */
const LK_FONT_PL={sourceserif:1,bebas:1,oswald:1,abril:1,caveat:1,orbitron:1,limelight:1,monoton:1,piedra:1,tradewinds:1,chewy:1,molle:1,permanentmarker:1,greatvibes:1,pinyon:1,allura:1,belanosima:1,bricolage:1,lato:1,mplus:1,spacegrotesk:1,rubik:1,outfit:1,sora:1,jakarta:1,fraunces:1};
const LK_FONT_ORDER=['archivo','anton','bebas','oswald','montserrat','poppins','inter','dmsans','lexend','orbitron','playfair','baskerville','spectral','eczar','cambo','lora','sourceserif','abril','croissant','limelight','monoton','piedra','tradewinds','chewy','shortstack','molle','oleo','lobster','pacifico','righteous','permanentmarker','gloria','caveat','dancing','sacramento','parisienne','greatvibes','pinyon','allura','satisfy','yellowtail','tangerine','spacemono','jetbrains','albert','belanosima','bricolage','epilogue','plex','lato','mplus','manrope','nunito','opensans','roboto','worksans','quicksand','raleway','spacegrotesk','rubik','outfit','sora','jakarta','fraunces'];
const lkHex=(v,d)=>/^#[0-9a-f]{6}$/i.test(v||'')?v.toLowerCase():d;
const lkNumD=(v,a,b,d)=>{v=+v;return Number.isFinite(v)?Math.min(b,Math.max(a,Math.round(v*10)/10)):d};
const lkPick=(v,list,d)=>list.includes(v)?v:d;
const lkNum=(v,a,b,d)=>{v=+v;return Number.isFinite(v)?Math.min(b,Math.max(a,Math.round(v))):d};
function cleanLook(l,p){l=l&&typeof l=='object'?l:{};p=p||{};
 const bg0=lkHex(p.bg,'#1e6bff'),lb=['pro','casual','modern'].includes(p.btn)?p.btn:'casual';
 const b=l.bg&&typeof l.bg=='object'?l.bg:{},g=b.g&&typeof b.g=='object'?b.g:{},
  bt=l.btn&&typeof l.btn=='object'?l.btn:{},f=l.font&&typeof l.font=='object'?l.font:{},ph=l.photo&&typeof l.photo=='object'?l.photo:{};
 const img=cldOk(b.img)||(typeof b.img=='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(b.img)&&b.img.length<=LK_IMG_MAX)?b.img:'';
 const vid=cldOk(b.video)||(typeof b.video=='string'&&/^data:video\/(mp4|webm);base64,/.test(b.video)&&b.video.length<=LK_VIDEO_MAX)?b.video:'',
  t0=lkPick(b.type,LK_BG,'solid'),type=(t0=='image'&&!img)||(t0=='video'&&!vid)?'solid':t0;
 return {v:1,theme:/^[a-z0-9_-]{0,24}$/.test(l.theme||'')?(l.theme||''):'',
  bg:{type,color:lkHex(b.color,bg0),
   g:{c1:lkHex(g.c1,bg0),c2:lkHex(g.c2,'#7c3aed'),angle:lkNum(g.angle,0,360,135)},
   img:type=='image'?img:'',video:type=='video'?vid:'',fx:lkPick(b.fx,LK_FX,'none'),tone:lkNum(b.tone,-60,60,0),
   pattern:lkPick(b.pattern,LK_PAT,'dots'),animate:b.animate===true,grain:b.grain===true},
  btn:{shape:lkPick(bt.shape,LK_SHAPE,{pro:'square',casual:'pill',modern:'round'}[lb]),fill:lkPick(bt.fill,LK_FILL,'solid'),
   shadow:lkPick(bt.shadow,LK_SHADOW,'none'),color:lkHex(bt.color,''),text:lkHex(bt.text,''),hover:lkPick(bt.hover,LK_HOVER,'lift'),rad:lkNum(bt.rad,-1,40,-1),op:lkNum(bt.op,10,100,100),bw:lkNum(bt.bw,-1,8,-1),bh:lkNum(bt.bh,40,80,56),wd:lkNum(bt.wd,40,100,100)},
  font:{name:lkPick(f.name,LK_FONTS,'inter'),bio:lkPick(f.bio,LK_FONTS,'inter'),btn:lkPick(f.btn,LK_FONTS,lb=='pro'?'sourceserif':'inter')},
  photo:{size:lkPick(ph.size,LK_PSIZE,'m'),shape:lkPick(ph.shape,LK_PSHAPE,'circle')},
  head:cleanHead(l.head),
  social:lkPick(l.social,LK_SOC,'top'),tx:lkHex(l.tx,''),hideBrand:l.hideBrand===true}}
function cleanHead(x){x=x&&typeof x=='object'?x:{};
 const logo=typeof x.logo=='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(x.logo)&&x.logo.length<=LK_LOGO_MAX?x.logo:'';
 const cv=x.cover&&typeof x.cover=='object'?x.cover:{};
 const ci=cldOk(cv.img)||(typeof cv.img=='string'&&/^data:image\/(jpeg|png|webp);base64,/.test(cv.img)&&cv.img.length<=LK_COVER_MAX)?cv.img:'';
 const cd=cldOk(cv.video)||(typeof cv.video=='string'&&/^data:video\/(mp4|webm);base64,/.test(cv.video)&&cv.video.length<=LK_VIDEO_MAX)?cv.video:'';
 return {sh:cleanSh(x.sh),layout:lkPick(x.layout,LK_LAYOUT,'classic'),titleStyle:x.titleStyle=='logo'?'logo':'text',logo,altFont:x.altFont===true,font:lkPick(x.font,LK_FONTS,'inter'),color:lkHex(x.color,''),
  shape:lkPick(x.shape,Object.keys(LK_SHP),'loop'),cover:{type:cv.type=='video'&&cd?'video':'image',img:ci,video:cd},
  fo:lkNum(x.fo,0,100,55),fz:lkNumD(x.fz,50,300,100),fx:lkNumD(x.fx,0,100,50),fy:lkNumD(x.fy,0,100,50),nz:lkNum(x.nz,28,72,46),bz:lkNum(x.bz,12,32,17),bc:lkHex(x.bc,''),fa:lkPick(x.fa,['left','center','right'],'center'),fp:lkPick(x.fp,['top','mid','bottom'],'mid'),nx:lkNum(x.nx,-300,300,0),ny:lkNum(x.ny,-400,400,0),bx:lkNum(x.bx,-300,300,0),by:lkNum(x.by,-400,400,0),lx:lkNum(x.lx,-300,300,0),ly:lkNum(x.ly,-400,400,0)}}
/* o que o plano do dono realmente permite (página pública e salvar) */
function lkEnforce(L,r){if(r>=2)return L;const x=JSON.parse(JSON.stringify(L));
 if(r<1){x.head.layout='classic';x.head.titleStyle='text';x.head.altFont=false;x.hideBrand=false}
 if(x.bg.type=='image'||x.bg.type=='video')x.bg.type='solid';x.bg.animate=false;
 if(x.head.cover.type=='video'){x.head.cover={type:'image',img:x.head.cover.img,video:''}}
 return x}
function cleanProfile(p){p=p&&typeof p=='object'?p:{};
 return {name:String(p.name||'').slice(0,60),bio:String(p.bio||'').slice(0,160),text:p.text===undefined?String(p.bio||'').slice(0,160):String(p.text||'').slice(0,160),
  photo:cldOk(p.photo)||(typeof p.photo=='string'&&p.photo.startsWith('data:image/'))?p.photo:'',
  username:/^[a-z0-9_]{3,20}$/.test(p.username||'')?p.username:'',
  goal:['creator','business','personal'].includes(p.goal)?p.goal:'',plats:(Array.isArray(p.plats)?p.plats:[]).filter(x=>typeof x=='string').slice(0,20).map(x=>x.slice(0,20)),
  bg:/^#[0-9a-f]{6}$/i.test(p.bg||'')?p.bg:'',btn:['pro','casual','modern'].includes(p.btn)?p.btn:'',look:cleanLook(p.look,p),onboarded:p.onboarded===true,verify:['pending','ok','no'].includes(p.verify)?p.verify:'',pcv:['sunset','snow','mist','graphite','ocean','violet','forest','rose'].includes(p.pcv)?p.pcv:'',
  links:(Array.isArray(p.links)?p.links:[]).filter(l=>l&&typeof l=='object').slice(0,PF_MAX).map(l=>{const x={name:String(l.name||'').slice(0,60),url:String(l.url||'').slice(0,500)};if(l.hide===true)x.hide=true;if(l.arch===true)x.arch=true;return x})}}
const blank=()=>({u:null,profile:blankProfile()});
let S=blank();
/* Firebase / Firestore */
let pendName='',pendFix=false,justCreated=false,FB=null,uid=null,cloudOK=false,authReady=false,saveT=null,loginIntent=false,seq=0;
const fbReady=()=>window.FB?Promise.resolve(window.FB):new Promise(r=>addEventListener('fb-ready',()=>r(window.FB),{once:true}));
function toast(m,ms=3800,kind){if(kind!=='quiet'&&(kind==='error'||ERR_RX.test(String(m))))errFx();const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(()=>t.hidden=true,ms)}
/* v82: pop-up de confirmação do Quantum (substitui o confirm() do navegador). cfm({t,m,ok,no,i,d,run}) -> Promise<boolean>
   run (opcional): ao confirmar mostra o círculo a rodar no botão e só fecha quando run terminar */
function cfm(o){return new Promise(res=>{const bx=$('#cfm'),ok=$('#cfmok'),no=$('#cfmno');if(bx.dataset.bz){res(false);return}
 $('#cfmt').textContent=o.t||'Tem certeza?';$('#cfmm').textContent=o.m||'';$('#cfmi').innerHTML=I(o.i||'help');
 bx.toggleAttribute('data-d',!!o.d);ok.className='cfm-ok'+(o.d?' dg':'');ok.disabled=no.disabled=false;ok.textContent=o.ok||'Sim';no.textContent=o.no||'Cancelar';
 let done=false,busy=false;
 const close=v=>{if(done)return;done=true;delete bx.dataset.bz;document.removeEventListener('keydown',kd,true);bx.classList.remove('on');setTimeout(()=>{if(!bx.classList.contains('on'))bx.hidden=true},220);res(v)},
  kd=e=>{if(e.key=='Escape'){e.stopPropagation();if(!busy)close(false)}},
  yes=async()=>{if(busy)return;if(!o.run){close(true);return}
   busy=true;bx.dataset.bz='1';ok.style.minWidth=ok.offsetWidth+'px';ok.innerHTML='<span class="spin"></span>';ok.classList.add('bz');no.disabled=true;
   try{await o.run()}catch(e){console.error(e)}
   close(true)};
 ok.onclick=yes;no.onclick=()=>{if(!busy)close(false)};$('#cfmbk').onclick=()=>{if(!busy)close(false)};
 document.addEventListener('keydown',kd,true);bx.hidden=false;requestAnimationFrame(()=>{bx.classList.add('on');try{no.focus({preventScroll:true})}catch(e){}})})}
const snap=()=>JSON.parse(JSON.stringify({u:{name:S.u&&S.u.name,email:S.u&&S.u.email},profile:S.profile}));
function save(){if(!uid||!cloudOK)return;clearTimeout(saveT);saveT=setTimeout(flush,600)}
async function flush(){clearTimeout(saveT);if(!uid||!cloudOK||!FB)return;
 try{await FB.setDoc(FB.doc(FB.db,'users',uid),{...snap(),updatedAt:FB.serverTimestamp()},{merge:true});publishPage()}
 catch(e){console.error('Firestore:',e);toast('Não foi possível sincronizar os dados. Verifique a ligação.')}}
addEventListener('pagehide',flush);document.addEventListener('visibilitychange',()=>{if(document.visibilityState=='hidden')flush()});
const AERR={'auth/invalid-email':'E-mail inválido.','auth/user-disabled':'Esta conta foi desativada.','auth/user-not-found':'E-mail ou senha incorretos.','auth/wrong-password':'E-mail ou senha incorretos.','auth/invalid-credential':'E-mail ou senha incorretos.','auth/invalid-login-credentials':'E-mail ou senha incorretos.','auth/email-already-in-use':'Este e-mail já tem conta. Tente entrar.','auth/weak-password':'A senha deve ter pelo menos 6 caracteres.','auth/too-many-requests':'Muitas tentativas. Tente de novo daqui a pouco.','auth/network-request-failed':'Sem ligação à internet.','auth/popup-closed-by-user':'','auth/cancelled-popup-request':'','auth/account-exists-with-different-credential':'Este e-mail já está registado com outro método de login.','auth/operation-not-allowed':'Este método de login não está ativado.','auth/unauthorized-domain':'Domínio não autorizado no Firebase (Authentication > Settings).'};
const aerr=e=>{const m=AERR[e&&e.code];return m===undefined?'Não foi possível concluir. Tente novamente.':m};
function applyDoc(d,user,fresh){const b=blank(),n=(user.displayName||'').trim()||(user.email||'').split('@')[0]||'Utilizador';
 const u=d&&d.u?d.u:{};
 S={u:{name:u.name||n,email:user.email||u.email||'',plan:PL[u.plan]?u.plan:'free',premiumUntil:+u.premiumUntil||0,prevPlan:PL[u.prevPlan]?u.prevPlan:''},profile:cleanProfile(d&&d.profile)};
 if(u.bill)S.u.bill=u.bill;if(fresh&&(pendName||user.displayName))S.u.name=pendName||user.displayName;pendName='';pendFix=checkPremium()||!!(u.email&&user.email&&u.email!==user.email)}
async function kick(){uid=null;cloudOK=false;clearTimeout(saveT);S=blank();toast("Conta suspensa.",6000);try{await FB.signOut(FB.auth)}catch(e){console.error(e)}}
async function loadUser(user){const my=++seq;uid=user.uid;cloudOK=false;
 try{const ref=FB.doc(FB.db,'users',user.uid),ss=await FB.getDoc(ref);if(my!=seq)return;
  if(ss.exists()&&ss.data().banned===true){await kick();return true}
  applyDoc(ss.exists()?ss.data():null,user,!ss.exists());cloudOK=true;if(pendFix){pendFix=false;save()}if(ss.exists())setTimeout(()=>publishPage(),0)
  if(!ss.exists()){justCreated=true;await FB.setDoc(ref,{...snap(),createdAt:FB.serverTimestamp(),updatedAt:FB.serverTimestamp()})}}
 catch(e){console.error('Firestore:',e);if(my!=seq)return;applyDoc(null,user,true);cloudOK=false;toast('Não foi possível carregar os seus dados. Tentaremos de novo quando houver ligação.',6000)}
 return false}
addEventListener('online',()=>{if(uid&&!cloudOK&&FB&&FB.auth.currentUser)loadUser(FB.auth.currentUser).then(()=>{if(cloudOK){hdr();if(!pfDirty)pfFill();go(cur)}})});
const PL={free:{n:'Gratuito',p:0,r:0},plus:{n:'Plus',p:250,r:1},pro:{n:'Pro',p:750,r:2}};
const FEAT={free:[['lk2','Página de links com seu @username'],['user','Foto, nome e bio'],['sun','Modo claro e escuro']],
 plus:[['lk2','Links ilimitados na sua página'],['set','Todos os temas prontos'],['sun','Cores e degradê personalizados'],['eq','Botões personalizados: formato, sombra e animação'],['users','Visitantes dos últimos 7 dias'],['shield','Sem a marca Quantum na página']],
 pro:[['cr','Tudo do plano Plus'],['txt','Fontes personalizadas'],['gift','Fundos com imagem e animação'],['goal','Análises completas: cliques por link'],['bag','Venda de produtos na sua página'],['share','Compartilhar com QR Code'],['chat','Suporte prioritário']]};

/* planos */
const plan=()=>PL[S.u.plan];
function checkPremium(){const u=S.u;if(!u||!u.premiumUntil||Date.now()<=u.premiumUntil)return false;
 ntEnd(u.plan,u.premiumUntil);/* v85: avisa que o plano terminou */
 u.plan=PL[u.prevPlan]&&u.prevPlan!='pro'?u.prevPlan:'free';u.premiumUntil=0;u.prevPlan='';save();return true}
let cur='profile';
const PT=['profile','edit','look','xpintro','explore','public','plan','conta'],DK=['profile','public','plan'],DKM={edit:'profile',look:'profile',xpintro:'profile',explore:'profile',conta:'profile'};
function go(t){if(!PT.includes(t))t='profile';cur=t;if(checkPremium())hdr();
 $$('.pf-scr').forEach(x=>{const on=x.dataset.t==t;if(x.hidden==on)x.hidden=!on});
 if(t=='plan')$('#pfpl').textContent=plan().n;
 if(t=='look')lkEnter();if(t=='edit')pfFill();if(t=='conta')cnFill();if(t=='public')pubFill();inboxInit();ntInit();if(t=='explore')xpEnter();else xpLeave();
 if(t=='profile')hmFill();else $('#hmpg').hidden=true;document.body.classList.toggle('ds-on',t=='look');
 dockSync();scrollTo(0,0);$('#dd').hidden=true}

function hdr(){const u=S.u,ini=u.name.trim().slice(0,1).toUpperCase();$('#avb').textContent=ini;$('#av2').textContent=ini;$('#dn').textContent=u.name;$('#de').textContent=u.email;$('#dp').textContent={free:'Free',plus:'Plus',pro:'Pro'}[u.plan]||PL[u.plan].n;}

/* planos (metical MT) — modo claro = Opção A, modo escuro = Opção B */
const PRICE={pro:750,plus:250},PUI={pro:{l:'Pro',i:'cr',s:'Tudo liberado'},plus:{l:'Plus',i:'bolt',s:'Para o dia a dia'}};let SELP='pro';
const mt=n=>{n=Math.round(n*100)/100;return n.toLocaleString('pt-BR',{minimumFractionDigits:Number.isInteger(n)?0:2,maximumFractionDigits:2})+' MT'};
function renderPlans(){
 const cd=k=>{const p=PUI[k];return `<button type="button" class="pcard" data-sel="${k}" aria-pressed="false"><span class="pci">${I(p.i)}</span><span class="pcl">${p.l}</span><strong>${PRICE[k].toLocaleString('pt-BR')}<em>/mês</em></strong><span class="pcs">${p.s}</span><i class="tick">${I('ck')}</i></button>`};
 const body=`<div class="chp">Escolha seu plano</div><div class="pcs2">${cd('pro')}${cd('plus')}</div><div class="chp incl" data-incl></div><ul class="ft" data-ft></ul><button type="button" class="pcta" data-buy></button><div class="pfoot"></div>`;
 $('#pg').innerHTML=`<div class="pv pA" data-v="A"><h3>Sua oferta única</h3><p class="sub">Desbloqueie o cálculo mais poderoso</p>${body}</div><div class="pv pB" data-v="B"><span class="plg">${I('eq')}</span><h3>Sua oferta única</h3><p class="sub">Desbloqueie o cálculo mais poderoso</p>${body}</div>`;
 paintPlans()}
function paintPlans(){const u=S.u,P=PUI[SELP];$$('.pv').forEach(v=>{
  $$('.pcard',v).forEach(c=>c.setAttribute('aria-pressed',c.dataset.sel==SELP));
  $('[data-incl]',v).textContent='Incluído no plano '+P.l;
  $('[data-ft]',v).innerHTML=FEAT[SELP].map(([ic,t])=>`<li><span class="fi">${I(ic)}</span><span>${t}</span></li>`).join('');
  const b=$('.pcta',v),now=!!u&&u.plan==SELP;b.disabled=now;b.textContent=now?'Plano atual':'Continuar';
  $('.pfoot',v).textContent=`Cobrança mensal de ${mt(PRICE[SELP])}. Cancele quando quiser`})}
$('#pg').onclick=e=>{const c=e.target.closest('[data-sel]'),bu=e.target.closest('[data-buy]');
 if(c){SELP=c.dataset.sel;paintPlans();return}
 if(!bu||bu.disabled)return;
 if(!S.u){location.hash='entrar';return}
 askOpen()};
const ask=$('#ask');
function askOpen(){$('#askP').textContent=PUI[SELP].l+', '+PRICE[SELP].toLocaleString('pt-BR')+' MT/mês';$('#askE').textContent=S.u?S.u.email:'';const ai=$('#askI');if(ai)ai.innerHTML=I(SELP=='pro'?'cr':'bolt');ask.hidden=false;document.body.style.overflow='hidden';$('#askx').focus()}
function askClose(){ask.hidden=true;document.body.style.overflow=''}
$('#askx').onclick=askClose;ask.onclick=e=>{if(e.target.closest('[data-close]'))askClose()};
document.addEventListener('keydown',e=>{if(e.key=='Escape'&&!ask.hidden)askClose()});
$('#pa').onclick=()=>{if(pfrom=='app'&&history.length>1)history.back();else if(S.u)location.replace('#app');else location.hash='inicio'};

/* login */
let reg=false;
function lgSync(){const off=reg&&!$('#lck').checked;$('#lb').disabled=off;$('#lgg').disabled=off}
function lgMode(anim){if(!anim){lgDo();return}clearTimeout(lgMode.t);const ks=$$('.lxm .lxr>*,.lxt');ks.forEach(x=>x.classList.add('lxo'));lgMode.t=setTimeout(()=>{lgDo();ks.forEach(x=>{x.classList.remove('lxo');x.style.animation='none';void x.offsetWidth;x.style.animation=''})},280)}
function lgDo(){$('#nl').hidden=!reg;$('#lfg').hidden=reg;$('#at').innerHTML=reg?'Crie<br>sua conta':'Entre na<br>sua conta';$('#lb').textContent=reg?'Criar conta':'Entrar';$('#lgt').textContent=reg?'Criar conta com Google':'Entrar com Google';$('#lt').textContent=reg?'Já tem conta?':'Não tem conta?';$('#lw').textContent=reg?'Entrar':'Cadastre-se';$('#lcs').textContent=reg?'Ao criar a conta você concorda com os termos de serviço e a política de privacidade.':'Lembrar de mim';$('#lck').checked=!reg;$('#lp').type='password';$('#lpe').classList.remove('on');$('#lp').style.paddingRight=reg?'78px':'120px';lgSync();$('#lp').autocomplete='new-password';$('#lf').classList.toggle('rg',reg);qaReset();}
$('#lw').onclick=()=>{location.hash=reg?'entrar':'cadastro'};
$('#lck').onchange=lgSync;
$$('.lxf input').forEach(i=>i.addEventListener('input',()=>i.parentNode.classList.remove('er')));
$('#lpe').onmousedown=e=>e.preventDefault();
$('#lpe').onclick=()=>{const t=$('#lp'),s=t.type=='password';t.type=s?'text':'password';$('#lpe').classList.toggle('on',s);$('#lpe').setAttribute('aria-label',s?'Ocultar senha':'Mostrar senha')};
const lgBusy=(on)=>{['#lb','#lgg','#hbg'].forEach(q=>{const b=$(q);if(b)b.disabled=on&&true});if(!on)lgSync()};
async function lgPersist(){try{await FB.setPersistence(FB.auth,$('#lck').checked||reg?FB.browserLocalPersistence:FB.browserSessionPersistence)}catch(e){}}
$('#lf').onsubmit=async e=>{e.preventDefault();const em=$('#le').value.trim(),pw=$('#lp').value;
 const bad=[];if(!/\S+@\S+\.\S+/.test(em))bad.push($('#le').parentNode);if(pw.length<6)bad.push($('#lp').parentNode);
 if(bad.length){bad.forEach(f=>{f.classList.remove('er');void f.offsetWidth;f.classList.add('er')});bad[0].querySelector('input').focus();if(pw.length<6&&bad.length==1)toast('A senha deve ter pelo menos 6 caracteres.');return}
 if(reg&&!$('#lck').checked){return}
 await fbReady();const b=$('#lb');b.innerHTML='<span class="spin"></span>';lgBusy(true);loginIntent=true;
 try{await lgPersist();
  if(reg){const nm=$('#ln').value.trim()||em.split('@')[0];pendName=nm;const cr=await FB.createUserWithEmailAndPassword(FB.auth,em,pw);
   try{await FB.updateProfile(cr.user,{displayName:nm})}catch(x){}}
  else await FB.signInWithEmailAndPassword(FB.auth,em,pw)}
 catch(err){loginIntent=false;pendName='';b.textContent=reg?'Criar conta':'Entrar';const m=aerr(err);if(m)toast(m);
  $$('#le,#lp').forEach(i=>{const f=i.parentNode;f.classList.remove('er');void f.offsetWidth;f.classList.add('er')})}
 finally{lgBusy(false)}};
async function googleLogin(){await fbReady();loginIntent=true;lgBusy(true);
 try{await lgPersist();const p=new FB.GoogleAuthProvider();p.setCustomParameters({prompt:'select_account'});await FB.signInWithPopup(FB.auth,p)}
 catch(err){if(err&&(err.code=='auth/popup-blocked'||err.code=='auth/operation-not-supported-in-this-environment')){try{await FB.signInWithRedirect(FB.auth,new FB.GoogleAuthProvider());return}catch(x){err=x}}
  loginIntent=false;const m=aerr(err);if(m)toast(m)}
 finally{lgBusy(false)}}
$('#lgg').onclick=()=>{if(reg&&!$('#lck').checked)return;googleLogin()};
$('#hbg').onclick=googleLogin;
function clearLogin(){['#ln','#le','#lp','#re'].forEach(q=>{const i=$(q);if(i){i.value='';i.parentNode.classList.remove('er')}});
 $('#lp').type='password';$('#lpe').classList.remove('on');$('#lpe').setAttribute('aria-label','Mostrar senha');
 const b=$('#lb');b.classList.remove('ok');b.textContent=reg?'Criar conta':'Entrar';lgBusy(false);qaReset()}
/* cadastro: erro animado no e-mail e check na senha (só no modo cadastro, escopo .rg) */
function qaBad(v){return !/\S+@\S+\.\S+/.test(v)}
function qaMail(show){const i=$('#le'),bad=!!show&&qaBad(i.value.trim());i.parentNode.classList.toggle('qbad',bad);
 if(bad){i.setAttribute('aria-invalid','true');i.setAttribute('aria-describedby','qem')}else{i.removeAttribute('aria-invalid');i.removeAttribute('aria-describedby')}}
function qaPass(){$('#lp').parentNode.classList.toggle('qok',!!reg&&$('#lp').value.length>=6)}
function qaReset(){qaMail(false);qaPass()}
$('#le').addEventListener('blur',()=>{if(reg)qaMail($('#le').value.trim()!=='')});
$('#le').addEventListener('input',()=>{if(reg&&$('#le').parentNode.classList.contains('qbad'))qaMail(true)});
$('#lp').addEventListener('input',qaPass);$('#lp').addEventListener('change',qaPass);
$('#lf').addEventListener('submit',()=>{if(reg)qaMail(true)});
/* recuperar senha */
let rcT=0;const rcOk=e=>/\S+@\S+\.\S+/.test(e);
function rcShake(){const f=$('#re').parentNode;f.classList.remove('er');void f.offsetWidth;f.classList.add('er')}
function rcStep(n){$('#rc1').hidden=n!=1;$('#rc2').hidden=n!=2;const e=$(n==1?'#rc1 .lxr':'#rc2 .lxr');e.style.animation='none';void e.offsetWidth;e.style.animation=''}
function rcCount(){clearInterval(rcT);let t=60;const b=$('#rcr');b.disabled=true;const tick=()=>{b.textContent='Reenviar em '+Math.floor(t/60)+':'+String(t%60).padStart(2,'0');if(t--<=0){clearInterval(rcT);b.disabled=false;b.textContent='Reenviar e-mail'}};tick();rcT=setInterval(tick,1000)}
async function rcSend(em,btn,txt){await fbReady();const old=btn.innerHTML;btn.disabled=true;btn.innerHTML='<span class="spin"></span>';
 try{await FB.sendPasswordResetEmail(FB.auth,em);btn.innerHTML=old;return true}
 catch(err){btn.innerHTML=old;btn.disabled=false;const m=err&&err.code=='auth/user-not-found'?'Não encontramos uma conta com este e-mail.':aerr(err);if(m)toast(m);return false}}
$('#lfg').onclick=()=>{$('#re').value=$('#le').value.trim();location.hash='recuperar'};
$('#rc1').onsubmit=async e=>{e.preventDefault();const em=$('#re').value.trim();if(!rcOk(em)){rcShake();$('#re').focus();toast('Digite um e-mail válido.');return}
 if(await rcSend(em,$('#rcs'))){$('#rcm').textContent=em;rcStep(2);rcCount()}};
$('#rcr').onclick=async()=>{const em=$('#rcm').textContent;if(await rcSend(em,$('#rcr'))){toast('E-mail reenviado. Confira também o spam.',4000);rcCount()}};
$('#rca').onclick=()=>{clearInterval(rcT);rcStep(1);$('#re').focus()};
$('#rcx').onclick=()=>{location.hash='entrar'};
$('#rcv').onclick=()=>{if(!$('#rc2').hidden){clearInterval(rcT);rcStep(1);return}location.hash='entrar'};
$('#re').addEventListener('input',()=>$('#re').parentNode.classList.remove('er'));

/* menu e tema */
const dd=$('#dd');$('#avb').onclick=e=>{e.stopPropagation();dd.hidden=!dd.hidden;$('#avb').setAttribute('aria-expanded',!dd.hidden)};
document.addEventListener('click',e=>{if(!dd.contains(e.target))dd.hidden=true});document.addEventListener('keydown',e=>{if(e.key=='Escape')dd.hidden=true});
dd.onclick=e=>{const b=e.target.closest('[data-t]');if(b)go(b.dataset.t);if(e.target.closest('[data-soon]')){dd.hidden=true}};
$('#lo').onclick=async()=>{dd.hidden=true;$('#avb').setAttribute('aria-expanded','false');
 const y=await cfm({t:'Sair da conta?',m:'Você terá de entrar de novo para acessar o seu perfil.',ok:'Sim, sair',no:'Cancelar',i:'out',d:true,
  run:async()=>{try{await Promise.all([flush(),wait(3000)]);await FB.signOut(FB.auth)}catch(e){toast(aerr(e))}}});
 if(y)location.hash='inicio'};
const dk=()=>(document.documentElement.dataset.theme||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'))=='dark';
function syncTheme(){$('#thm').setAttribute('aria-pressed',dk())}
const th=()=>{document.documentElement.dataset.theme=dk()?'light':'dark';syncTheme()};
$('#thm').onclick=th;
document.addEventListener('click',e=>{const g=e.target.closest('[data-go]');if(g&&!g.dataset.pick){let t=g.dataset.go;if(S.u&&t=='inicio')t='app';location.hash=t;if(t=='app'&&!S.u)location.hash='entrar'}});

/* dock: navegação inferior (Perfil · Público · Plano) */
const dock=$('#dock'),dkb=$('#dkbar');
function dockSync(){const dc=DKM[cur]||cur,i=DK.indexOf(dc);dkb.style.setProperty('--i',Math.max(i,0));
 $$('.dk-tab',dkb).forEach(b=>{const on=b.dataset.t==dc;b.setAttribute('aria-selected',on);b.tabIndex=on?0:-1})}
dkb.onclick=e=>{const b=e.target.closest('.dk-tab');if(b)go(b.dataset.t)};
dkb.onkeydown=e=>{const k={ArrowRight:1,ArrowLeft:-1}[e.key];if(!k)return;const j=DK.indexOf(document.activeElement.dataset.t);if(j<0)return;e.preventDefault();const n=DK[(j+k+DK.length)%DK.length];go(n);$(`.dk-tab[data-t=${n}]`).focus()};


/* Perfil: tela inicial estilo Linktree */
function hmFill(){const p=S.profile||blankProfile(),u=S.u||{},nm=(p.name||p.username||u.name||'').replace(/^@/,'');
 $('#hmnm').textContent=nm;$('#hmai').textContent=nm.slice(0,1).toUpperCase();
 const im=$('#hmim');im.hidden=!p.photo;if(p.photo)im.src=p.photo;else im.removeAttribute('src');
 const n=p.links.filter(l=>l.url&&!l.arch).length;$('#hmln').textContent=n+(n==1?' link':' links');
 const ok=[!!p.photo,!!p.bio,n>0,!!p.username].filter(Boolean).length+1,pc=Math.round(ok/5*100);
 hmStat();$('#hmpp').textContent=pc+'%';$('#hmpv').style.strokeDashoffset=String(119.4*(1-pc/100));$('#hmpg').hidden=pc>=100}
$('#hmed').onclick=()=>go('edit');$('#hmdes').onclick=()=>go('look');$('#hmxp').onclick=()=>go('xpintro');$('#xigo').onclick=()=>go('explore');
$('#hmsh').onclick=async()=>{const p=S.profile,url=p&&p.username?pubHost()+'#/'+p.username:'';
 if(!url){toast('Escolha um username para ter o link da sua página.');return}
 try{if(navigator.share){await navigator.share({title:'Quantum',url});return}}catch(e){if(e&&e.name=='AbortError')return}
 try{await navigator.clipboard.writeText(url);toast('Link copiado!',2000)}catch(e){toast(url,5000)}};
document.addEventListener('click',e=>{const b=e.target.closest('.sub-bk');if(b)go(b.dataset.t)});

/* ==========================================================
   EDITAR (estilo Linktree): ícones do topo, links, menus e folhas.
   Dados: users/{uid}.profile = { name, bio, photo, plats[], links:[{name,url,hide?,arch?}], look… }
   Cada ação salva sozinha (sem botão "Salvar Perfil"): pfCommit() atualiza na hora e envia ao Firestore.
   ========================================================== */
let pfDirty=false,pfQ=Promise.resolve();
const ED={tab:'links',arch:false,url:''},ED_IC=['instagram','tiktok','whatsapp'],ED_CONN=['instagram','tiktok','youtube','spotify'];
const soon=()=>toast('Em breve!',2200);
const pfName=()=>{const p=S.profile||blankProfile();return(p.name||p.username||(S.u&&S.u.name)||'').replace(/^@/,'')};
function pfUrl(v){v=v.trim();if(!/^[a-z][a-z0-9+.-]*:/i.test(v))v='https://'+v;
 try{const u=new URL(v);return /^https?:$/.test(u.protocol)&&u.hostname.includes('.')?v:null}catch(e){return null}}
const edOk=u=>/^https?:\/\//i.test(u||'');
const edPlat=l=>{const n=String(l&&l.name||'').toLowerCase();return OBP.find(p=>p[1].toLowerCase()==n)};
const edTile=pl=>`<span class="ed-ti" style="${pl?pl[2]:''}">${pl?obSvg(pl):I('lk2')}</span>`;
function edEnsure(){const p=S.profile;if(!p)return;
 p.plats.map(obP).filter(Boolean).forEach(pl=>{if(!p.links.some(l=>l.name==pl[1])&&p.links.length<PF_MAX)p.links.push({name:pl[1],url:''})})}
function edShare(url){return(async()=>{
 try{if(navigator.share){await navigator.share({url});return}}catch(e){if(e&&e.name=='AbortError')return}
 try{await navigator.clipboard.writeText(url);toast('Link copiado!',2000)}catch(e){toast(url,5000)}})()}

/* salvar: atualiza a tela na hora e envia ao servidor em fila (uma ação por vez) */
let pfDone=Promise.resolve(true);
const SV_CK='<svg class="i sv-ck" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';
function pfSaveEnd(b){b.classList.remove('ld','ok');b.disabled=false;b.style.minWidth='';b.innerHTML=b.dataset.t0}
/* salvar com feedback: spinner do login → check verde → fecha */
function pfSave(b,mut,msg){if(b.disabled)return;b.dataset.t0=b.innerHTML;b.style.minWidth=b.offsetWidth+'px';b.classList.add('ld');b.disabled=true;b.innerHTML='<span class="spin"></span>';
 if(!pfCommit(mut,msg)){pfSaveEnd(b);return}const t0=Date.now();
 pfDone.then(r=>setTimeout(()=>{if(!r){pfSaveEnd(b);return}b.classList.remove('ld');b.classList.add('ok');b.innerHTML=SV_CK;playSound('success');vibrate('success');setTimeout(edClose,520)},Math.max(0,450-(Date.now()-t0))))}
function pfCommit(mut,msg){
 if(!S.profile)return false;
 if(!uid||!cloudOK||!FB){toast('Sem ligação com o servidor. Tente de novo em instantes.');return false}
 const id=uid,prev=S.profile,next={...prev,links:prev.links.map(l=>({...l}))};
 mut(next);S.profile=next;edFill();hmFill();
 pfDone=pfQ=pfQ.then(async()=>{
  if(uid!=id)return false;
  try{let slow=false;
   await Promise.race([FB.setDoc(FB.doc(FB.db,'users',id),{profile:next,updatedAt:FB.serverTimestamp()},{merge:true}),new Promise(ok=>setTimeout(()=>{slow=true;ok()},12000))]);
   if(uid==id){publishPage();if(slow)toast('Sem ligação: a alteração será enviada quando a internet voltar.',4500);else if(msg)toast(msg,2200)}return true}
  catch(err){console.error('Firestore:',err);if(uid==id){S.profile=prev;edFill();hmFill()}toast('Não foi possível salvar. Tente novamente.');return false}});
 return true}

/* tela */
function edFill(){
 const p=S.profile||blankProfile();edEnsure();
 const nm=pfName(),im=$('#edim');
 $('#edai').textContent=nm.slice(0,1).toUpperCase();im.hidden=!p.photo;if(p.photo)im.src=p.photo;else im.removeAttribute('src');
 $('#ednm').textContent=nm||'Seu nome';
 const act=k=>{const pl=obP(k),l=pl&&p.links.find(x=>x.name==pl[1]);return !!(l&&!l.arch&&edOk(l.url)&&p.plats.includes(k))};
 const keys=ED_IC.concat(p.plats.filter(k=>obP(k)&&!ED_IC.includes(k)&&act(k)));
 $('#edso').innerHTML=keys.map(k=>{const pl=obP(k),on=act(k);
  return `<button class="ed-si${on?' on':''}" type="button" data-si="${k}" style="${on?pl[2]:''}" aria-label="${on?'Editar':'Adicionar'} ${pl[1]}">${obSvg(pl)}${on?'':`<i class="ed-pl">${I('plus')}</i>`}</button>`}).join('')
  +`<button class="ed-si" type="button" data-si="email" aria-label="Adicionar e-mail">${I('mail')}<i class="ed-pl">${I('plus')}</i></button>`
  +`<button class="ed-si add" type="button" data-si="more" aria-label="Adicionar mais ícones">${I('plus')}</button>`;
 const vf=$('#edvf');vf.classList.toggle('ok',p.verify=='ok');{const u=$('use',vf);if(u)u.setAttribute('href',p.verify=='ok'?'#vseal':'#verified')}
 $('#edvft').textContent=p.verify=='ok'?'Página verificada':p.verify=='pending'?'Verificação em análise':'Adicione a verificação';
 const act2=[],arc=[];p.links.forEach((l,i)=>(l.arch?arc:act2).push(i));
 $('#edls').innerHTML=act2.map(i=>{const l=p.links[i],pl=edPlat(l),ok=edOk(l.url);
  return `<div class="ed-card${l.hide?' off':''}" data-i="${i}"><span class="ed-tw">${edTile(pl)}</span><div class="ed-ct"><b>${esc(l.name)}</b><small>0 clique</small></div>`
   +(l.hide?`<span class="ed-eye" title="Oculto">${I('eyeoff')}</span>`:ok?'':`<button class="ed-cfg" type="button" data-a="cfg">${I('wrench')}Configurar</button>`)
   +`<button class="ed-kb" type="button" data-a="menu" aria-haspopup="menu" aria-label="Mais opções de ${esc(l.name)}">${I('dotsv')}</button></div>`}).join('');
 $('#edem').hidden=act2.length>0;
 const at=$('#edat');at.hidden=!arc.length;at.setAttribute('aria-expanded',String(ED.arch));at.innerHTML=`${I('arch')}<span>Arquivados (${arc.length})</span><i class="ed-chv${ED.arch?' up':''}">${I('chev')}</i>`;
 const ar=$('#edarc');ar.hidden=!arc.length||!ED.arch;
 ar.innerHTML=arc.map(i=>{const l=p.links[i],pl=edPlat(l);
  return `<div class="ed-card ed-ar" data-i="${i}"><span class="ed-tw">${edTile(pl)}</span><div class="ed-ct"><b>${esc(l.name)}</b><small>Arquivado</small></div><button class="ed-mini" type="button" data-a="rest">Restaurar</button><button class="ed-kb" type="button" data-a="del" aria-label="Excluir ${esc(l.name)}">${I('trash')}</button></div>`}).join('');
 $('#edft').setAttribute('aria-pressed',String(!(p.look&&p.look.hideBrand)));
 $$('.ed-tabs button').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.tab==ED.tab)));
 $$('.ed-pane').forEach(x=>x.hidden=x.dataset.pane!=ED.tab)}
function pfFill(){ED.tab='links';edFill();pfPubLink()}

/* menu flutuante (⋯ do topo e ⋮ de cada link) */
const edM=$('#edm');
function edPop(a,items){
 if(!edM.hidden&&edM._a===a){edPopX();return}
 edM.classList.remove('cmp');
 edM.innerHTML=items.map((it,k)=>`<button class="ed-mi${it.c?' '+it.c:''}" type="button" role="menuitem" data-k="${k}">${I(it.i)}<span>${it.t}</span></button>`).join('');
 edM._it=items;edM._a=a;edM.hidden=false;
 const r=a.getBoundingClientRect(),w=edM.offsetWidth,h=edM.offsetHeight;
 let top=r.bottom+8;if(top+h>innerHeight-12)top=Math.max(12,r.top-h-8);
 edM.style.top=top+'px';edM.style.left=Math.min(Math.max(12,r.right-w),innerWidth-w-12)+'px'}
function edPopX(){edM.hidden=true;edM._a=null}
edM.onclick=e=>{const b=e.target.closest('.ed-mi');if(!b)return;const it=edM._it[+b.dataset.k];edPopX();if(it&&it.f)it.f()};
document.addEventListener('pointerdown',e=>{if(!edM.hidden&&!e.target.closest('#edm')&&!e.target.closest('[data-a="menu"],#edmore'))edPopX()},true);
addEventListener('scroll',()=>{if(!edM.hidden)edPopX()},{passive:true});
addEventListener('resize',edPopX);

/* folha (bottom sheet) */
const eds=$('#eds'),edB=$('#edsB'),edT=$('#edsT'),edBk=$('#edsb');let edBack=null,edFocus=null;
function edOpen(t,html,mount,back){
 edPopX();edT.textContent=t;edB.innerHTML=html;edBack=back||null;edBk.style.visibility=back?'visible':'hidden';edBk.disabled=!back;
 if(eds.hidden){eds.hidden=false;edFocus=document.activeElement}
 $('.ed-sh',eds).scrollTop=0;if(mount)mount(edB)}
function edClose(){eds.hidden=true;edBack=null;if(edFocus&&edFocus.focus){try{edFocus.focus()}catch(e){}}edFocus=null}
$('#edsx').onclick=edClose;$('.shop-bd',eds).onclick=edClose;edBk.onclick=()=>{if(edBack)edBack()};
document.addEventListener('keydown',e=>{if(e.key!='Escape')return;if(!edM.hidden)edPopX();else if(!eds.hidden)edClose()});

/* 1) escolher rede social */
function edPick(back){
 const p=S.profile,have=k=>{const pl=obP(k),l=p.links.find(x=>x.name==pl[1]);return l&&!l.arch&&edOk(l.url)};
 edOpen('Escolha uma rede',`<div class="ed-grid">${OBP.filter(x=>x[0]!='website').map(x=>`<button class="ed-pk${have(x[0])?' has':''}" type="button" data-k="${x[0]}">${edTile(x)}<span>${x[1]}</span></button>`).join('')}<button class="ed-pk" type="button" data-k="email"><span class="ed-ti ed-gy">${I('mail')}</span><span>E-mail</span></button></div>`,
  r=>{r.onclick=e=>{const b=e.target.closest('.ed-pk');if(!b)return;if(b.dataset.k=='email'){soon();return}edPlat2(b.dataset.k,()=>edPick(back))}},back)}

/* 2) usuário / número / link de uma rede (cria ou edita o ícone) */
function edPlat2(key,back){
 const p=S.profile,pl=obP(key),l=p.links.find(x=>x.name==pl[1]),has=!!(l&&edOk(l.url)&&p.plats.includes(key)),ty=pl[6];
 let cur='';if(has)cur=pl[5]&&l.url.startsWith(pl[5])?l.url.slice(pl[5].length):l.url;
 const lab=ty=='phone'?`Digite o número do ${pl[1]} (com DDI)*`:ty=='url'?`Cole o link do ${pl[1]}*`:`Digite o usuário do ${pl[1]}*`,
  ex=ty=='phone'?'Exemplo: 5511912345678':ty=='url'?'Exemplo: https://…':'Exemplo: @seuusuario';
 edOpen(`${has?'Editar':'Adicionar'} ícone do ${pl[1]}`,
  `<input class="ed-in" id="edv" type="${ty=='phone'?'tel':'text'}" inputmode="${ty=='phone'?'tel':ty=='url'?'url':'text'}" placeholder="${lab}" aria-label="${lab}" maxlength="200" autocomplete="off" autocapitalize="off" spellcheck="false"><p class="ed-ex" id="edx">${ex}</p>`
  +`<button class="ed-pri" id="edok" type="button" disabled>${has?'Salvar':'Adicionar'}</button>`
  +(has?`<button class="ed-tx red" id="edrm" type="button">Remover ícone</button>`:'')
  +(ED_CONN.includes(key)&&!has?`<div class="ed-or"><span>OU</span></div><button class="ed-conn" id="edcn" type="button">${edTile(pl)}Conecte ${pl[1]}</button>`:''),
  r=>{const v=$('#edv',r),ok=$('#edok',r),x=$('#edx',r);v.value=cur;ok.disabled=!v.value.trim();
   v.oninput=()=>{ok.disabled=!v.value.trim();v.classList.remove('bad');x.classList.remove('bad');x.textContent=ex};
   const save=()=>{const u=obUrl(pl,v.value);
    if(!u){v.classList.add('bad');x.classList.add('bad');x.textContent=ty=='phone'?'Número inválido. Use o código do país + número.':'Confira o usuário ou o link.';v.focus();return}
    if(!l&&p.links.length>=PF_MAX){toast(`Limite de ${PF_MAX} links atingido.`);return}
    pfSave(ok,q=>{const t=q.links.find(z=>z.name==pl[1]);if(t){t.url=u;delete t.arch}else q.links.unshift({name:pl[1],url:u});if(!q.plats.includes(key))q.plats=q.plats.concat(key).slice(0,20)},`${pl[1]} ${has?'atualizado':'adicionado'}!`)};
   ok.onclick=save;v.onkeydown=e=>{if(e.key=='Enter'){e.preventDefault();if(!ok.disabled)save()}};
   const rm=$('#edrm',r);if(rm)rm.onclick=()=>{pfSave(rm,q=>{q.links=q.links.filter(z=>z.name!=pl[1]);q.plats=q.plats.filter(z=>z!=key)},'Ícone removido.')};
   const cn=$('#edcn',r);if(cn)cn.onclick=soon;if(!has)v.focus()},back)}

/* 3) criar / editar um link */
function edLink(i,focusUrl){
 const p=S.profile,isNew=i==null,l=isNew?{name:'',url:''}:p.links[i];if(!l)return;
 const pl=isNew?null:edPlat(l);let cur=l.url;if(pl&&edOk(l.url)&&pl[5]&&l.url.startsWith(pl[5]))cur=l.url.slice(pl[5].length);
 edOpen(isNew?'Novo link':'Editar link',
  `<label class="ed-lb">Título<input class="ed-in" id="edn" type="text" maxlength="60" placeholder="Ex.: Meu portfólio" autocomplete="off"${pl?' readonly':''}></label>`
  +`<label class="ed-lb">${pl?'Usuário ou link':'URL'}<input class="ed-in" id="edu" type="text" inputmode="url" maxlength="500" placeholder="${pl?(pl[6]=='phone'?'Número com DDI':pl[4]):'https://seusite.com'}" autocomplete="off" autocapitalize="off" spellcheck="false"></label>`
  +`<p class="ed-ex" id="edx"></p><button class="ed-pri" id="edok" type="button">${isNew?'Adicionar link':'Salvar'}</button>`
  +(isNew?'':`<button class="ed-tx red" id="edrm" type="button">Excluir link</button>`),
  r=>{const n=$('#edn',r),u=$('#edu',r),x=$('#edx',r);n.value=l.name;u.value=cur;
   [n,u].forEach(f=>f.oninput=()=>{f.classList.remove('bad');x.textContent=''});
   const save=()=>{const nm=n.value.trim(),raw=u.value.trim();let url;
    if(pl){url=obUrl(pl,raw);if(url===null){u.classList.add('bad');x.textContent='Confira o usuário ou o link.';u.focus();return}}
    else{if(!nm){n.classList.add('bad');x.textContent='Dê um título ao link.';n.focus();return}
     url=raw?pfUrl(raw):null;if(!url){u.classList.add('bad');x.textContent='Cole um endereço válido, como https://seusite.com';u.focus();return}}
    if(isNew&&p.links.length>=PF_MAX){toast(`Limite de ${PF_MAX} links atingido.`);return}
    pfSave($('#edok',r),q=>{if(isNew)q.links.unshift({name:nm,url});else{if(!pl)q.links[i].name=nm;q.links[i].url=url}},isNew?'Link adicionado!':'Link salvo!')};
   $('#edok',r).onclick=save;r.onkeydown=e=>{if(e.key=='Enter'&&e.target.tagName=='INPUT'){e.preventDefault();save()}};
   const rm=$('#edrm',r);if(rm)rm.onclick=()=>{if(!rm.dataset.sure){rm.dataset.sure='1';rm.textContent='Toque de novo para excluir';return}
    pfSave(rm,q=>{const t=q.links[i];if(pl)q.plats=q.plats.filter(z=>z!=pl[0]);q.links.splice(i,1)},'Link excluído.')};
   (isNew||!focusUrl&&!pl?n:u).focus()})}

/* 4) menu "Adicionar" */
function edAdd(){
 const row=(ic,t,s,k,soonb)=>`<button class="ed-row" type="button" data-k="${k}"><span class="ed-ri">${I(ic)}</span><span class="ed-rt"><b>${t}</b><small>${s}</small></span>${soonb?'<em class="ed-soon">Em breve</em>':I('chev')}</button>`;
 edOpen('Adicionar',row('lk2','Link','Um botão que leva para qualquer site','link')+row('users','Rede social','Instagram, WhatsApp, TikTok e outras','soc')+row('grid','Coleção','Agrupe links em um bloco','col',1)+row('txt','Texto','Um título ou aviso na página','txt',1)+row('play','Vídeo','Mostre um vídeo na página','vid',1),
  r=>{r.onclick=e=>{const b=e.target.closest('.ed-row');if(!b)return;const k=b.dataset.k;
   if(k=='link')edLink(null);else if(k=='soc')edPick(edAdd);else soon()}})}

/* 5) editar perfil (foto, nome, bio) */
function edProf(){
 const p=S.profile||blankProfile();let photo=p.photo||'';
 edOpen('Editar perfil',
  `<div class="ed-ph"><span class="ed-av sm"><span id="epai"></span><img id="epim" alt="" hidden></span><div class="ed-pa"><label class="ed-fb">${I('share')}<span>Escolher foto</span><input class="ed-fi" id="epf" type="file" accept="image/*"></label><button class="ed-tx" id="eprm" type="button" hidden>Remover foto</button><small>JPG ou PNG.</small></div></div>`
  +`<label class="ed-lb">Nome<input class="ed-in" id="epn" type="text" maxlength="60" placeholder="Seu nome ou @username" autocomplete="off" autocapitalize="off" spellcheck="false"></label>`
  +`<label class="ed-lb">Bio<textarea class="ed-in ed-ta" id="epb" rows="3" maxlength="160" placeholder="Uma descrição curta sobre você"></textarea><em class="ed-cn" id="epc">0/160</em></label>`
  +`<button class="ed-pri" id="epsv" type="button">Salvar</button>`,
  r=>{const n=$('#epn',r),b=$('#epb',r),c=$('#epc',r),im=$('#epim',r),ini=$('#epai',r),rm=$('#eprm',r);n.value=p.name;b.value=p.bio;
   const av=()=>{const t=(n.value.trim()||(S.u&&S.u.name)||p.username||'').replace(/^@/,'');ini.textContent=t.slice(0,1).toUpperCase();im.hidden=!photo;if(photo)im.src=photo;else im.removeAttribute('src');rm.hidden=!photo};
   const ct=()=>c.textContent=b.value.length+'/160';av();ct();n.oninput=av;b.oninput=ct;
   rm.onclick=()=>{photo='';av()};
   $('#epf',r).onchange=function(){const f=this.files[0];this.value='';if(!f)return;
    if(!/^image\//.test(f.type)||f.size>12e6){toast('Escolha uma imagem (JPG ou PNG) de até 12 MB.');return}
    const rd=new FileReader();rd.onerror=()=>toast('Não foi possível ler a imagem.');
    rd.onload=()=>{const m=new Image();m.onerror=()=>toast('Não foi possível abrir essa imagem.');
     m.onload=()=>{const s=Math.min(m.width,m.height),z=Math.min(1080,s),cv=document.createElement('canvas');cv.width=cv.height=z;const x=cv.getContext('2d');
      x.fillStyle='#fff';x.fillRect(0,0,z,z);x.imageSmoothingQuality='high';x.drawImage(m,(m.width-s)/2,(m.height-s)/2,s,s,0,0,z,z);
      /* v91: sobe para o Cloudinary e guarda só a URL (sem limite de Base64) */
      const sv=$('#epsv',r),ab=$('.ed-av',r);sv.disabled=true;ab.classList.add('upl');
      cldCanvas(cv,'image/jpeg',.92).then(u=>{photo=u;av()}).catch(er=>toast((er&&er.message)||'Não foi possível enviar a foto.',4200)).finally(()=>{sv.disabled=false;ab.classList.remove('upl')})};m.src=rd.result};rd.readAsDataURL(f)};
   $('#epsv',r).onclick=()=>{pfSave($('#epsv',r),q=>{q.name=n.value.trim();q.bio=b.value.trim();q.photo=photo},'Perfil salvo!')}})}

/* ligações da tela */
$('#edback').onclick=()=>go('profile');
$('#edbio').onclick=()=>$('#hmsh').click();
$('#edmore').onclick=function(){edPop(this,[
 {i:'user',t:'Editar perfil',f:edProf},
 {i:'share',t:'Copiar link da página',f:()=>{if(!ED.url){toast('Escolha um username para ter o link da sua página.');return}navigator.clipboard.writeText(ED.url).then(()=>toast('Link copiado!',2000),()=>toast(ED.url,5000))}},
 {i:'arr',t:'Abrir minha página',f:()=>{if(!ED.url){toast('Escolha um username para ter o link da sua página.');return}open(ED.url,'_blank','noopener')}},
 {i:'brush',t:'Visual da página',f:()=>go('look')},
 {i:'set',t:'Configurações da página',f:soon}])};
$('#edav').onclick=edProf;$('#ednm').onclick=edProf;
$('#edadd').onclick=edAdd;$('#edcol').onclick=soon;$('#edfw').onclick=soon;
$('#edvf').onclick=()=>{const v=S.profile&&S.profile.verify;if(v=='ok'){toast('Sua página já é verificada.');return}go('look');vfOpen()};
$('#edso').onclick=e=>{const b=e.target.closest('.ed-si');if(!b)return;const k=b.dataset.si;
 if(k=='email')soon();else if(k=='more')edPick();else edPlat2(k)};
$('.ed-tabs').onclick=e=>{const b=e.target.closest('button[data-tab]');if(!b)return;ED.tab=b.dataset.tab;edFill()};
$('#edls').onclick=e=>{const c=e.target.closest('.ed-card');if(!c)return;const i=+c.dataset.i,b=e.target.closest('[data-a]'),l=S.profile.links[i];if(!l)return;
 if(!b){edLink(i);return}
 if(b.dataset.a=='cfg'){const pl=edPlat(l);pl?edPlat2(pl[0]):edLink(i,true);return}
 if(b.dataset.a=='menu')edPop(b,[
  {i:'pen',t:'Editar',f:()=>edLink(i)},
  {i:'share',t:'Compartilhar',f:()=>{if(!edOk(l.url)){toast('Configure o link antes de compartilhar.');return}edShare(l.url)}},
  {i:l.hide?'eye':'eyeoff',t:l.hide?'Mostrar':'Ocultar',f:()=>pfCommit(q=>{if(q.links[i].hide)delete q.links[i].hide;else q.links[i].hide=true},l.hide?'Link visível na página.':'Link oculto da página.')},
  {i:'arch',t:'Arquivar',f:()=>pfCommit(q=>{q.links[i].arch=true},'Link arquivado.')}])};
$('#edat').onclick=()=>{ED.arch=!ED.arch;edFill()};
$('#edarc').onclick=e=>{const c=e.target.closest('.ed-card'),b=e.target.closest('[data-a]');if(!c||!b)return;const i=+c.dataset.i;
 if(b.dataset.a=='rest')pfCommit(q=>{delete q.links[i].arch},'Link restaurado.');
 else if(b.dataset.a=='del'){if(!b.dataset.sure){b.dataset.sure='1';b.classList.add('red');toast('Toque de novo para excluir de vez.',2200);return}
  pfCommit(q=>{const t=q.links[i],pl=edPlat(t);if(pl)q.plats=q.plats.filter(z=>z!=pl[0]);q.links.splice(i,1)},'Link excluído.')}};
$('#edft').onclick=()=>{
 if(lkRank()<1){toast('Tirar o rodapé está disponível nos planos pagos.',3200);SELP='plus';location.hash='planos';return}
 pfCommit(q=>{q.look={...q.look,hideBrand:!(q.look&&q.look.hideBrand)}})};
$('#edup').onclick=()=>{SELP='plus';location.hash='planos'};
syncTheme();


/* ==========================================================
   PAINEL ADMIN — lê/escreve users/{id}. Só abre para quem tem o documento admins/{uid}.
   Plano (VIP) e banimento são campos do ADMIN: o app do utilizador nunca os grava (ver snap).
   ========================================================== */
window.isAdmin=false;
const esc=v=>String(v==null?'':v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fD=t=>new Date(t).toLocaleString('pt-BR',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit'});
const PLN={free:'Free',plus:'Plus',pro:'Pro'},UNIT={d:['dia','dias'],m:['mês','meses'],y:['ano','anos']};
let AU=[],aq='',af='all';
const adminUI=()=>{$('#adg').hidden=!window.isAdmin};
async function checkAdmin(user){window.isAdmin=false;
 try{const s=await FB.getDoc(FB.doc(FB.db,'admins',user.uid));const cu=FB.auth.currentUser;window.isAdmin=s.exists()&&!!cu&&cu.uid==user.uid}
 catch(e){console.warn('admins:',e)}
 adminUI()}
/* soma dias/meses/anos de calendário (1 mês = mesmo dia do mês seguinte) */
function addDur(from,n,u){const d=new Date(from);if(u=='d')d.setDate(d.getDate()+n);else if(u=='m')d.setMonth(d.getMonth()+n);else d.setFullYear(d.getFullYear()+n);return d.getTime()}
const durTxt=(n,u)=>n?n+' '+UNIT[u][n==1?0:1]:'permanente';
/* plano que vale AGORA (um VIP vencido volta ao plano anterior, igual ao que o app do utilizador mostra) */
const effPlan=(u,now=Date.now())=>u.pu&&u.pu<=now?(PL[u.prev]&&u.prev!='pro'?u.prev:'free'):u.plan;
const adErr=(e,fb)=>{console.error('Admin:',e);return e&&e.code=='permission-denied'?'Sem permissão no Firestore. Publique as regras do ficheiro firestore.rules e confirme que existe admins/{seu UID}.':fb};
const pageUrl=u=>location.href.split('#')[0]+'#/'+u;
async function adLoad(){const l=$('#adl');$('#adc').textContent='';l.innerHTML='<li class="adm-e">A carregar utilizadores...</li>';
 try{const qs=await FB.getDocs(FB.collection(FB.db,'users'));
  AU=qs.docs.map(d=>{const x=d.data(),u=x.u||{},p=x.profile||{};return {id:d.id,name:u.name||'Sem nome',email:u.email||'',plan:PL[u.plan]?u.plan:'free',banned:x.banned===true,pu:+u.premiumUntil||0,prev:u.prevPlan||'',user:/^[a-z0-9_]{3,20}$/.test(p.username||'')?p.username:'',vf:['pending','ok','no'].includes(p.verify)?p.verify:''}});
  AU.sort((a,b)=>a.email.localeCompare(b.email));adRender()}
 catch(e){l.innerHTML='<li class="adm-e">'+esc(adErr(e,'Não foi possível carregar os utilizadores.'))+'</li>'}}
function adRender(){const now=Date.now(),q=aq.trim().toLowerCase().replace(/^@/,'');
 const ep=u=>effPlan(u,now),C={all:AU.length,pro:0,plus:0,free:0,banned:0,nouser:0,vf:0};
 AU.forEach(u=>{C[ep(u)]++;if(u.banned)C.banned++;if(!u.user)C.nouser++;if(u.vf=='pending')C.vf++});
 $('#adst').innerHTML=[['Utilizadores',C.all],['Pro',C.pro],['Plus',C.plus],['Verificação',C.vf],['Banidos',C.banned]].map(([t,n])=>`<div><b>${n}</b><span>${t}</span></div>`).join('');
 $$('#adf button').forEach(b=>{const k=b.dataset.f;b.setAttribute('aria-pressed',k==af);const n=$('i',b);if(n)n.textContent=C[k]});
 const F={all:()=>true,pro:u=>ep(u)=='pro',plus:u=>ep(u)=='plus',free:u=>ep(u)=='free',banned:u=>u.banned,nouser:u=>!u.user,vf:u=>u.vf=='pending'};
 const L=AU.filter(u=>F[af](u)&&(!q||u.email.toLowerCase().includes(q)||u.name.toLowerCase().includes(q)||u.user.includes(q)));
 if(af=='vf')L.sort((a,b)=>a.email.localeCompare(b.email));
 $('#adc').textContent=(q||af!='all')?`${L.length} de ${AU.length} utilizadores`:`${AU.length} utilizadores`;
 $('#adl').innerHTML=L.length?L.map(u=>{const p=ep(u),me=u.id==uid,vip=u.pu>now,exp=u.pu&&u.pu<=now;
  return `<li class="adm-u${u.banned?' bn':''}" data-id="${esc(u.id)}"><div class="adm-i"><b>${esc(u.name)}${me?'<em class="adm-t me">Você</em>':''}${u.banned?'<em class="adm-t">Banido</em>':''}${u.vf=='ok'?'<em class="adm-t vf">Verificado</em>':u.vf=='pending'?'<em class="adm-t pd">Pediu verificação</em>':u.vf=='no'?'<em class="adm-t">Verificação recusada</em>':''}</b><small>${esc(u.email||'sem e-mail')}</small>`
  +(u.user?`<small class="adm-un"><a href="${esc(pageUrl(u.user))}" target="_blank" rel="noopener">@${esc(u.user)}</a><button type="button" class="adm-cp" data-a="copy">Copiar link</button></small>`:'<small class="adm-un no">Sem @username, ainda não tem página pública</small>')
  +`<div class="adm-m"><span class="adm-pl ${esc(p)}">${PLN[p]}</span>${vip?`<span>até ${fD(u.pu)}</span>`:exp?`<span>VIP ${PLN[u.plan]} expirou em ${fD(u.pu)}</span>`:p!='free'?'<span>permanente</span>':''}</div></div>`
  +`<div class="adm-a">${u.vf=='pending'?'<button class="btn ok" type="button" data-a="vfok">Aceitar verificação</button><button class="btn dg" type="button" data-a="vfno">Recusar</button>':u.vf=='ok'?'<button class="btn dg" type="button" data-a="vfrm">Tirar verificação</button>':u.vf=='no'?'<button class="btn ok" type="button" data-a="vfok">Verificar mesmo assim</button>':''}<button class="btn" type="button" data-a="vip">Dar VIP</button><button class="btn" type="button" data-a="unvip"${p=='free'&&!vip?' disabled':''}>Tirar VIP</button><button class="btn${u.banned?'':' dg'}" type="button" data-a="ban"${me?' disabled title="Não pode banir a própria conta"':''}>${u.banned?'Desbanir':'Banir'}</button></div></li>`}).join(''):'<li class="adm-e">Nenhum utilizador encontrado.</li>'}
$('#ads').oninput=e=>{aq=e.target.value;adRender()};
$('#adf').onclick=e=>{const b=e.target.closest('button[data-f]');if(b){af=b.dataset.f;adRender()}};
$('#adr').onclick=adLoad;
$('#adb').addEventListener('click',()=>{dd.hidden=true;$('#avb').setAttribute('aria-expanded','false')});

/* --- Dar VIP: plano + duração (dias, meses, anos ou permanente) --- */
const avm=$('#avm');let AV={id:'',plan:'pro',n:30,u:'d'};
const avU=()=>AU.find(x=>x.id==AV.id);
function avSync(src){const u=avU(),now=Date.now();
 $$('#avp button').forEach(b=>b.setAttribute('aria-pressed',b.dataset.p==AV.plan));
 $$('#avd button').forEach(b=>b.setAttribute('aria-pressed',+b.dataset.n==AV.n&&b.dataset.u==AV.u));
 const perm=AV.n==0;$('#avn').disabled=perm;$('#avu').disabled=perm;
 if(src!='n')$('#avn').value=perm?'':AV.n;if(src!='u')$('#avu').value=AV.u;
 $('#avw').textContent=perm?'Sem data de fim. Fica ativo até você tirar.':'Termina em '+fD(addDur(now,AV.n,AV.u))+'.';
 const cur=u?effPlan(u,now):'free';
 $('#avc').textContent=u?(cur=='free'?'Plano atual: Free.':'Plano atual: '+PLN[cur]+(u.pu>now?' até '+fD(u.pu)+'.':' (permanente).')):'';
 $('#avok').textContent=perm?`Ativar ${PLN[AV.plan]} permanente`:`Ativar ${PLN[AV.plan]} por ${durTxt(AV.n,AV.u)}`}
function avOpen(u){AV={id:u.id,plan:u.plan=='plus'&&!(u.pu&&u.pu<=Date.now())?'plus':'pro',n:30,u:'d'};$('#avU').textContent=u.email||u.name;avSync();avm.hidden=false;document.body.style.overflow='hidden'}
function avClose(){avm.hidden=true;document.body.style.overflow=''}
$('#avx').onclick=avClose;
avm.onclick=e=>{if(e.target.closest('[data-close]')){avClose();return}
 const p=e.target.closest('#avp button'),d=e.target.closest('#avd button');
 if(p){AV.plan=p.dataset.p;avSync()}if(d){AV.n=+d.dataset.n;AV.u=d.dataset.u;avSync()}};
$('#avn').oninput=e=>{const v=Math.floor(+e.target.value);AV.n=Math.min(3650,Math.max(1,v||1));avSync('n')};
$('#avu').onchange=e=>{AV.u=e.target.value;if(!AV.n)AV.n=1;avSync('u')};
document.addEventListener('keydown',e=>{if(e.key=='Escape'&&!avm.hidden)avClose()});
$('#avok').onclick=async()=>{if(!window.isAdmin)return;const u=avU();if(!u)return;
 const b=$('#avok'),now=Date.now(),perm=AV.n==0,until=perm?0:addDur(now,AV.n,AV.u),cur=effPlan(u,now);
 if(cur=='pro'&&!u.pu&&(AV.plan!='pro'||!perm)&&!(await cfm({t:'Trocar o plano?',m:'Este utilizador tem o Pro permanente. O plano atual será substituído.',ok:'Trocar',i:'bolt'})))return;
 /* plano para onde volta quando o VIP termina */
 const prev=perm?'':(u.pu>now?(u.prev||'free'):(cur=='plus'&&AV.plan=='pro'?'plus':'free'));
 b.disabled=true;
 try{await FB.updateDoc(FB.doc(FB.db,'users',u.id),{'u.plan':AV.plan,'u.premiumUntil':until,'u.prevPlan':prev});
  u.plan=AV.plan;u.pu=until;u.prev=prev;ntTo(u.id,{t:'gift',p:AV.plan,d:perm?'permanente':durTxt(AV.n,AV.u)});/* v85 */
  if(u.id==uid){Object.assign(S.u,{plan:AV.plan,premiumUntil:until,prevPlan:prev});hdr();publishPage(true)}
  toast('VIP '+PLN[AV.plan]+' ativado '+(perm?'(permanente).':'por '+durTxt(AV.n,AV.u)+'.'),3200);avClose();adRender()}
 catch(err){toast(adErr(err,'Não foi possível ativar o VIP.'),6000)}
 finally{b.disabled=false}};

/* --- ações na lista --- */
$('#adl').onclick=async e=>{const b=e.target.closest('button[data-a]');if(!b||!window.isAdmin)return;
 const li=b.closest('[data-id]'),u=li&&AU.find(x=>x.id==li.dataset.id);if(!u)return;const a=b.dataset.a,who=u.email||u.name,me=u.id==uid;
 if(a=='copy'){try{await navigator.clipboard.writeText(pageUrl(u.user));toast('Link copiado.',1800)}catch(x){toast(pageUrl(u.user),6000)}return}
 if(a=='vip'){avOpen(u);return}
 if(a=='vfok'||a=='vfno'||a=='vfrm'){const nv=a=='vfok'?'ok':a=='vfno'?'no':'';
  if(a=='vfno'&&!(await cfm({t:'Recusar verificação?',m:'Recusar o pedido de '+who+'. A pessoa poderá enviar de novo.',ok:'Recusar',i:'verified',d:true})))return;
  if(a=='vfrm'&&!(await cfm({t:'Tirar a verificação?',m:'Remover o selo de verificação de '+who+'.',ok:'Tirar',i:'verified',d:true})))return;
  b.disabled=true;
  try{await FB.updateDoc(FB.doc(FB.db,'users',u.id),{'profile.verify':nv});u.vf=nv;ntTo(u.id,{t:'vf',d:a=='vfok'?'ok':a=='vfno'?'no':'rm'});/* v85 */
   /* a página pública guarda a sua própria cópia: atualiza o selo lá também */
   if(u.user){try{await FB.updateDoc(FB.doc(FB.db,'pages',u.user),{verify:nv})}catch(x){console.warn('pages:',x)}}
   if(me&&S.profile){S.profile.verify=nv;publishPage(true)}
   toast(a=='vfok'?'Verificação aceite.':a=='vfno'?'Pedido recusado.':'Verificação removida.',2400)}
  catch(err){toast(adErr(err,'Não foi possível atualizar a verificação.'),6000)}
  adRender();return}
 if(a=='unvip'&&!(await cfm({t:'Tirar o VIP?',m:'A conta de '+who+' volta para o plano Gratuito.',ok:'Tirar VIP',i:'cr',d:true})))return;
 if(a=='ban'){if(me){toast('Não pode banir a própria conta.');return}
  if(!u.banned&&!(await cfm({t:'Banir esta conta?',m:who+' perde o acesso e a página pública sai do ar.',ok:'Banir',i:'shield',d:true})))return}
 b.disabled=true;
 try{const ref=FB.doc(FB.db,'users',u.id);
  if(a=='unvip'){const pp=effPlan(u,Date.now());await FB.updateDoc(ref,{'u.plan':'free','u.premiumUntil':0,'u.prevPlan':''});ntTo(u.id,{t:'end',p:pp,d:'rm'});u.plan='free';u.pu=0;u.prev='';
   if(me){Object.assign(S.u,{plan:'free',premiumUntil:0,prevPlan:''});hdr();publishPage(true)}toast('VIP removido.',2200)}
  else{const nb=!u.banned;await FB.updateDoc(ref,nb?{banned:true,bannedAt:Date.now()}:{banned:false});u.banned=nb;ntTo(u.id,{t:'restrict',d:nb?'on':'off'});/* v85 */
   /* banido: a página pública sai do ar. Ao desbanir, o app da pessoa republica na próxima abertura */
   if(nb&&u.user){try{await FB.deleteDoc(FB.doc(FB.db,'dir',u.user))}catch(x){console.warn('dir:',x)}
    try{await FB.deleteDoc(FB.doc(FB.db,'pages',u.user))}catch(x){console.warn('pages:',x);toast('Conta banida, mas não consegui tirar a página do ar (regras do Firestore).',6000)}}
   toast(nb?'Conta banida.':'Conta desbanida.',2200)}}
 catch(err){toast(adErr(err,'Não foi possível concluir a ação.'),6000)}
 adRender()};

/* --- o app do utilizador percebe sozinho VIP/ban dados pelo admin --- */
let refBusy=false;
async function refreshMe(){if(!uid||!cloudOK||!FB||refBusy||!S.u)return;refBusy=true;
 try{const ss=await FB.getDoc(FB.doc(FB.db,'users',uid));if(!ss.exists())return;const d=ss.data();
  if(d.banned===true){await kick();return}
  {const sv=d.profile&&['pending','ok','no'].includes(d.profile.verify)?d.profile.verify:'',lv=(S.profile&&S.profile.verify)||'';
   /* 'pending' local ainda por gravar não pode ser apagado por um '' antigo do servidor */
   if(S.profile&&sv!=lv&&!(lv=='pending'&&sv=='')){S.profile.verify=sv;publishPage(true);
    if(sv=='ok')toast('O seu perfil foi verificado!',4500);else if(sv=='no')toast('O seu pedido de verificação foi recusado.',4500);
    if(cur!='look'&&cur!='edit')go(cur)}}
  const x=d.u||{},n={plan:PL[x.plan]?x.plan:'free',premiumUntil:+x.premiumUntil||0,prevPlan:PL[x.prevPlan]?x.prevPlan:''};
  if(n.plan!=S.u.plan||n.premiumUntil!=S.u.premiumUntil||n.prevPlan!=S.u.prevPlan){Object.assign(S.u,n);checkPremium();hdr();
   if(cur!='look'&&cur!='edit')go(cur);publishPage(true);toast('O seu plano foi atualizado: '+plan().n+'.',4000)}}
 catch(e){console.warn('refresh:',e)}finally{refBusy=false}}
document.addEventListener('visibilitychange',()=>{if(document.visibilityState=='visible')refreshMe()});
addEventListener('focus',refreshMe);
setInterval(()=>{if(S.u&&checkPremium()){hdr();toast('O seu acesso VIP terminou.',5000);go(cur)}if(document.visibilityState=='visible')refreshMe()},45000);

/* v75: ao sair da conta (ou trocar de conta) a página recomeça do zero: nada da conta anterior (perfil, editor, produtos, mensagens, estatísticas, cache local) sobra para a próxima */
async function acctSwap(has){const b=$('#boot');if(b){b.hidden=false;b.classList.remove('off')}
 try{const m=await import('https://www.gstatic.com/firebasejs/13.2.0/firebase-firestore.js');
  try{await Promise.race([m.waitForPendingWrites(FB.db),wait(2500)])}catch(e){}
  await Promise.race([m.terminate(FB.db).then(()=>m.clearIndexedDbPersistence(FB.db)),wait(3500)])}catch(e){}
 try{history.replaceState(null,'',location.pathname+location.search+(has?'#app':'#inicio'))}catch(e){location.hash=has?'app':'inicio'}
 location.reload()}
/* histórico: com sessão iniciada, "voltar" nunca regressa ao login nem à tela inicial */
const PUBV=['inicio','cadastro','entrar','recuperar'],INAPP=['app','planos','admin','onboarding'];let prevV=null,bkT=0,pfrom=null;
function leaveApp(){clearTimeout(bkT);history.back();
 bkT=setTimeout(()=>{if(S.u&&!INAPP.includes(location.hash.slice(1)))location.replace('#app')},500)}

/* rotas */
function route(){const hh=location.hash;if(hh.startsWith('#/')){pubRoute(hh.slice(2));return}
 if(!authReady)return;if(pubOn)pubLeave();askClose();avClose();const n=(location.hash.slice(1)||'inicio');let v=['inicio','cadastro','entrar','recuperar','planos','app','admin','onboarding'].includes(n)?n:'inicio';
 if(S.u&&PUBV.includes(v)){if(INAPP.includes(prevV)){leaveApp();return}location.replace('#app');return}if(v=='app'&&!S.u){v='entrar'}
 if(v=='onboarding'&&!S.u)v='entrar';
 if(v=='app'&&S.u&&cloudOK&&!(S.profile&&S.profile.username)){location.replace('#onboarding');return}/* conta sem @username (contas antigas): escolhe agora */
 if(v=='admin'){if(!S.u)v='entrar';else if(!window.isAdmin){location.replace('#app');return}}
 if(v=='cadastro'||v=='entrar'){const r=v=='cadastro';v='entrar';if(reg!==r){reg=r;lgMode($('#v-entrar').classList.contains('on'))}}
 if(v=='entrar'&&!['entrar','recuperar'].includes(prevV))clearLogin();
 if(v=='recuperar'&&!$('#v-recuperar').classList.contains('on')){clearInterval(rcT);rcStep(1)}
 if(v=='admin'&&!$('#v-admin').classList.contains('on')){aq='';$('#ads').value='';adLoad()}
 $$('.view').forEach(x=>x.classList.toggle('on',x.id=='v-'+v));adminUI();
 if(S.u){hdr()}
 const onApp=v=='app';document.body.classList.toggle('has-dock',onApp);
 if(onApp&&dock.hidden){dock.hidden=false;dock.classList.remove('in');void dock.offsetWidth;dock.classList.add('in')}if(!onApp)dock.hidden=true
 if(v=='onboarding'&&prevV!='onboarding')obStart();
 if(v=='planos')renderPlans();if(v=='app'){const back=INAPP.includes(prevV);if(!back||!pfDirty)pfFill();go(back?cur:'profile')}if(v=='planos'&&prevV!='planos')pfrom=prevV;prevV=v;scrollTo(0,0)}
addEventListener('hashchange',route);
(async()=>{FB=await fbReady();
 const reset=()=>{seq++;clearTimeout(saveT);uid=null;cloudOK=false;S=blank();loginIntent=false;window.isAdmin=false;adminUI();clearLogin();ntStop();NT.list=[];NT.seen=0;ntBadge()};
 let accId=null;
 FB.onAuthStateChanged(FB.auth,async user=>{
  const nid=user?user.uid:'';
  if(accId&&accId!==nid){acctSwap(!!user);return}
  accId=nid;
  let banned=false;
  if(user){banned=(await Promise.all([loadUser(user),checkAdmin(user)]))[0]===true;
   if(banned){reset();if(/^#(app|admin)$/.test(location.hash))location.hash='entrar'}
   else{clearLogin();if(justCreated){justCreated=false;location.replace('#onboarding')}else if(loginIntent||/^#(entrar|cadastro)$/.test(location.hash))location.replace('#app');loginIntent=false}}
  else reset();
  const first=!authReady;authReady=true;{const t=$('#toast');if(/ligar ao Firebase/.test(t.textContent))t.hidden=true}$('#boot').classList.add('off');setTimeout(()=>$('#boot').hidden=true,350);
  if(user&&!banned)hdr();route();if(first&&(!user||banned)&&location.hash=='#app')location.hash='entrar'})})();
setTimeout(()=>{if(!authReady){authReady=true;$('#boot').classList.add('off');toast('Não foi possível ligar ao Firebase. Verifique a internet.',6000);route()}},25000);

/* ==========================================================
   ONBOARDING pós-cadastro: objetivo · plataformas · links · cores
   ========================================================== */
const OBG=[
 ['creator','Criador','Aumentar meus seguidores e explorar formas de monetizar meu público.','bolt','#FF7AD9','#7B3FE4'],
 ['business','Negócios','Expandir meu negócio e alcançar mais clientes.','bag','#3CCDFF','#1E6BFF'],
 ['personal','Pessoal','Compartilhar links com meus amigos e conhecidos.','user','#FFB36B','#FF5C7A']];
const OBT=(c)=>`<text x="12" y="17.6" text-anchor="middle">${c}</text>`;
/* [chave, nome, estilo do ícone, desenho, placeholder, base da URL, tipo] */
/* logos: caminhos oficiais (Simple Icons, 24x24) — um só lugar para todas as marcas do site */
const OBP=[
 ['instagram','Instagram','background:radial-gradient(circle at 30% 107%,#fdf497 0%,#fdf497 5%,#fd5949 45%,#d6249f 60%,#285AEB 90%);color:#fff','<g fill="currentColor" stroke="none"><path d="M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077"/></g>','@usuario','https://instagram.com/','user'],
 ['whatsapp','WhatsApp','background:#25D366;color:#fff','<g fill="currentColor" stroke="none"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></g>','Número do WhatsApp (com DDI)','','phone'],
 ['tiktok','TikTok','background:#000;color:#fff','<g fill="currentColor" stroke="none"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></g>','@usuario','https://tiktok.com/@','user'],
 ['youtube','YouTube','background:#FF0000;color:#fff','<g fill="currentColor" stroke="none"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></g>','@canal','https://youtube.com/@','user'],
 ['website','Website','background:#0B1220;color:#fff','<g fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><path d="M3.5 12h17M12 3.5c2.7 2.7 2.7 14.3 0 17M12 3.5c-2.7 2.7-2.7 14.3 0 17"/></g>','seusite.com','','url'],
 ['spotify','Spotify','background:#191414;color:#1ED760','<g fill="currentColor" stroke="none"><path d="M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z"/></g>','Link do Spotify','','url'],
 ['threads','Threads','background:#000;color:#fff','<g fill="currentColor" stroke="none"><path d="M12.186 24h-.007c-3.581-.024-6.334-1.205-8.184-3.509C2.35 18.44 1.5 15.586 1.472 12.01v-.017c.03-3.579.879-6.43 2.525-8.482C5.845 1.205 8.6.024 12.18 0h.014c2.746.02 5.043.725 6.826 2.098 1.677 1.29 2.858 3.13 3.509 5.467l-2.04.569c-1.104-3.96-3.898-5.984-8.304-6.015-2.91.022-5.11.936-6.54 2.717C4.307 6.504 3.616 8.914 3.589 12c.027 3.086.718 5.496 2.057 7.164 1.43 1.783 3.631 2.698 6.54 2.717 2.623-.02 4.358-.631 5.8-2.045 1.647-1.613 1.618-3.593 1.09-4.798-.31-.71-.873-1.3-1.634-1.75-.192 1.352-.622 2.446-1.284 3.272-.886 1.102-2.14 1.704-3.73 1.79-1.202.065-2.361-.218-3.259-.801-1.063-.689-1.685-1.74-1.752-2.964-.065-1.19.408-2.285 1.33-3.082.88-.76 2.119-1.207 3.583-1.291a13.853 13.853 0 0 1 3.02.142c-.126-.742-.375-1.332-.75-1.757-.513-.586-1.308-.883-2.359-.89h-.029c-.844 0-1.992.232-2.721 1.32L7.734 7.847c.98-1.454 2.568-2.256 4.478-2.256h.044c3.194.02 5.097 1.975 5.287 5.388.108.046.216.094.321.142 1.49.7 2.58 1.761 3.154 3.07.797 1.82.871 4.79-1.548 7.158-1.85 1.81-4.094 2.628-7.277 2.65Zm1.003-11.69c-.242 0-.487.007-.739.021-1.836.103-2.98.946-2.916 2.143.067 1.256 1.452 1.839 2.784 1.767 1.224-.065 2.818-.543 3.086-3.71a10.5 10.5 0 0 0-2.215-.221z"/></g>','@usuario','https://threads.net/@','user'],
 ['facebook','Facebook','background:#0866FF;color:#fff','<g fill="currentColor" stroke="none"><path d="M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z"/></g>','facebook.com/usuario','https://facebook.com/','user'],
 ['x','X','background:#000;color:#fff','<g fill="currentColor" stroke="none"><path d="M14.234 10.162 22.977 0h-2.072l-7.591 8.824L7.251 0H.258l9.168 13.343L.258 24H2.33l8.016-9.318L16.749 24h6.993zm-2.837 3.299-.929-1.329L3.076 1.56h3.182l5.965 8.532.929 1.329 7.754 11.09h-3.182z"/></g>','@usuario','https://x.com/','user'],
 ['soundcloud','SoundCloud','background:#FF5500;color:#fff','<g fill="currentColor" stroke="none"><path d="M23.999 14.165c-.052 1.796-1.612 3.169-3.4 3.169h-8.18a.68.68 0 0 1-.675-.683V7.862a.747.747 0 0 1 .452-.724s.75-.513 2.333-.513a5.364 5.364 0 0 1 2.763.755 5.433 5.433 0 0 1 2.57 3.54c.282-.08.574-.121.868-.12.884 0 1.73.358 2.347.992s.948 1.49.922 2.373ZM10.721 8.421c.247 2.98.427 5.697 0 8.672a.264.264 0 0 1-.53 0c-.395-2.946-.22-5.718 0-8.672a.264.264 0 0 1 .53 0ZM9.072 9.448c.285 2.659.37 4.986-.006 7.655a.277.277 0 0 1-.55 0c-.331-2.63-.256-5.02 0-7.655a.277.277 0 0 1 .556 0Zm-1.663-.257c.27 2.726.39 5.171 0 7.904a.266.266 0 0 1-.532 0c-.38-2.69-.257-5.21 0-7.904a.266.266 0 0 1 .532 0Zm-1.647.77a26.108 26.108 0 0 1-.008 7.147.272.272 0 0 1-.542 0 27.955 27.955 0 0 1 0-7.147.275.275 0 0 1 .55 0Zm-1.67 1.769c.421 1.865.228 3.5-.029 5.388a.257.257 0 0 1-.514 0c-.21-1.858-.398-3.549 0-5.389a.272.272 0 0 1 .543 0Zm-1.655-.273c.388 1.897.26 3.508-.01 5.412-.026.28-.514.283-.54 0-.244-1.878-.347-3.54-.01-5.412a.283.283 0 0 1 .56 0Zm-1.668.911c.4 1.268.257 2.292-.026 3.572a.257.257 0 0 1-.514 0c-.241-1.262-.354-2.312-.023-3.572a.283.283 0 0 1 .563 0Z"/></g>','soundcloud.com/usuario','https://soundcloud.com/','user'],
 ['snapchat','Snapchat','background:#FFFC00;color:#000','<g fill="currentColor" stroke="none"><path d="M12.206.793c.99 0 4.347.276 5.93 3.821.529 1.193.403 3.219.299 4.847l-.003.06c-.012.18-.022.345-.03.51.075.045.203.09.401.09.3-.016.659-.12 1.033-.301.165-.088.344-.104.464-.104.182 0 .359.029.509.09.45.149.734.479.734.838.015.449-.39.839-1.213 1.168-.089.029-.209.075-.344.119-.45.135-1.139.36-1.333.81-.09.224-.061.524.12.868l.015.015c.06.136 1.526 3.475 4.791 4.014.255.044.435.27.42.509 0 .075-.015.149-.045.225-.24.569-1.273.988-3.146 1.271-.059.091-.12.375-.164.57-.029.179-.074.36-.134.553-.076.271-.27.405-.555.405h-.03c-.135 0-.313-.031-.538-.074-.36-.075-.765-.135-1.273-.135-.3 0-.599.015-.913.074-.6.104-1.123.464-1.723.884-.853.599-1.826 1.288-3.294 1.288-.06 0-.119-.015-.18-.015h-.149c-1.468 0-2.427-.675-3.279-1.288-.599-.42-1.107-.779-1.707-.884-.314-.045-.629-.074-.928-.074-.54 0-.958.089-1.272.149-.211.043-.391.074-.54.074-.374 0-.523-.224-.583-.42-.061-.192-.09-.389-.135-.567-.046-.181-.105-.494-.166-.57-1.918-.222-2.95-.642-3.189-1.226-.031-.063-.052-.15-.055-.225-.015-.243.165-.465.42-.509 3.264-.54 4.73-3.879 4.791-4.02l.016-.029c.18-.345.224-.645.119-.869-.195-.434-.884-.658-1.332-.809-.121-.029-.24-.074-.346-.119-1.107-.435-1.257-.93-1.197-1.273.09-.479.674-.793 1.168-.793.146 0 .27.029.383.074.42.194.789.3 1.104.3.234 0 .384-.06.465-.105l-.046-.569c-.098-1.626-.225-3.651.307-4.837C7.392 1.077 10.739.807 11.727.807l.419-.015h.06z"/></g>','@usuario','https://snapchat.com/add/','user'],
 ['pinterest','Pinterest','background:#E60023;color:#fff','<g fill="currentColor" stroke="none"><path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.92-7.252 4.158 0 7.392 2.967 7.392 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.39 18.592.026 11.985.026L12.017 0z"/></g>','@usuario','https://pinterest.com/','user'],
 ['patreon','Patreon','background:#FF424D;color:#fff','<g fill="currentColor" stroke="none"><path d="M22.957 7.21c-.004-3.064-2.391-5.576-5.191-6.482-3.478-1.125-8.064-.962-11.384.604C2.357 3.231 1.093 7.391 1.046 11.54c-.039 3.411.302 12.396 5.369 12.46 3.765.047 4.326-4.804 6.068-7.141 1.24-1.662 2.836-2.132 4.801-2.618 3.376-.836 5.678-3.501 5.673-7.031Z"/></g>','patreon.com/usuario','https://patreon.com/','user'],
 ['twitch','Twitch','background:#9146FF;color:#fff','<g fill="currentColor" stroke="none"><path d="M11.571 4.714h1.715v5.143H11.57zm4.715 0H18v5.143h-1.714zM6 0L1.714 4.286v15.428h5.143V24l4.286-4.286h3.428L22.286 12V0zm14.571 11.143l-3.428 3.428h-3.429l-3 3v-3H6.857V1.714h13.714Z"/></g>','@canal','https://twitch.tv/','user'],
 ['applemusic','Apple Music','background:linear-gradient(180deg,#FA5C70,#FA243C);color:#fff','<g fill="currentColor" stroke="none"><path d="M23.994 6.124a9.23 9.23 0 00-.24-2.19c-.317-1.31-1.062-2.31-2.18-3.043a5.022 5.022 0 00-1.877-.726 10.496 10.496 0 00-1.564-.15c-.04-.003-.083-.01-.124-.013H5.986c-.152.01-.303.017-.455.026-.747.043-1.49.123-2.193.4-1.336.53-2.3 1.452-2.865 2.78-.192.448-.292.925-.363 1.408-.056.392-.088.785-.1 1.18 0 .032-.007.062-.01.093v12.223c.01.14.017.283.027.424.05.815.154 1.624.497 2.373.65 1.42 1.738 2.353 3.234 2.801.42.127.856.187 1.293.228.555.053 1.11.06 1.667.06h11.03a12.5 12.5 0 001.57-.1c.822-.106 1.596-.35 2.295-.81a5.046 5.046 0 001.88-2.207c.186-.42.293-.87.37-1.324.113-.675.138-1.358.137-2.04-.002-3.8 0-7.595-.003-11.393zm-6.423 3.99v5.712c0 .417-.058.827-.244 1.206-.29.59-.76.962-1.388 1.14-.35.1-.706.157-1.07.173-.95.045-1.773-.6-1.943-1.536a1.88 1.88 0 011.038-2.022c.323-.16.67-.25 1.018-.324.378-.082.758-.153 1.134-.24.274-.063.457-.23.51-.516a.904.904 0 00.02-.193c0-1.815 0-3.63-.002-5.443a.725.725 0 00-.026-.185c-.04-.15-.15-.243-.304-.234-.16.01-.318.035-.475.066-.76.15-1.52.303-2.28.456l-2.325.47-1.374.278c-.016.003-.032.01-.048.013-.277.077-.377.203-.39.49-.002.042 0 .086 0 .13-.002 2.602 0 5.204-.003 7.805 0 .42-.047.836-.215 1.227-.278.64-.77 1.04-1.434 1.233-.35.1-.71.16-1.075.172-.96.036-1.755-.6-1.92-1.544-.14-.812.23-1.685 1.154-2.075.357-.15.73-.232 1.108-.31.287-.06.575-.116.86-.177.383-.083.583-.323.6-.714v-.15c0-2.96 0-5.922.002-8.882 0-.123.013-.25.042-.37.07-.285.273-.448.546-.518.255-.066.515-.112.774-.165.733-.15 1.466-.296 2.2-.444l2.27-.46c.67-.134 1.34-.27 2.01-.403.22-.043.442-.088.663-.106.31-.025.523.17.554.482.008.073.012.148.012.223.002 1.91.002 3.822 0 5.732z"/></g>','Link do Apple Music','','url']];
const OBC=['#1E6BFF','#6B6E73','#1F2626','#2C0F19','#151B00','#F6D3E8','#F9DBC4','#FFFFFF','#000000'];
const OBB=[['pro','Profissional'],['casual','Descontraído'],['modern','Moderno']];
const obs=$('#ob');let OB=null;
const obSvg=p=>`<svg viewBox="0 0 24 24" aria-hidden="true">${p[3]}</svg>`;
const obP=k=>OBP.find(p=>p[0]==k);
const obTx=h=>{const n=parseInt(h.slice(1),16),r=n>>16,g=n>>8&255,b=n&255;return .299*r+.587*g+.114*b>165?'#0B1220':'#FFFFFF'};

function obStart(){const p=S.profile||blankProfile();
 OB={s:0,user:p.username||'',un:p.username?'ok':'',goal:p.goal||'',plats:p.plats.filter(obP),vals:{},extra:['','',''],bg:p.bg||OBC[0],btn:p.btn||'casual',tab:'bg'};
 $('#obgl').innerHTML=OBG.map((g,k)=>`<button class="ob-gc" type="button" role="radio" aria-checked="false" data-g="${g[0]}" style="--k:${k}"><span class="ob-gt"><b>${g[1]}</b><span>${g[2]}</span></span><span class="ob-gi" style="--c1:${g[4]};--c2:${g[5]}">${I(g[3])}</span></button>`).join('');
 $('#obpl').innerHTML=OBP.map((p,k)=>`<button class="ob-pc" type="button" aria-pressed="false" data-p="${p[0]}" style="--k:${k}"><span class="ob-pi" style="${p[2]}">${obSvg(p)}</span>${p[1]}<span class="tk">${I('ck')}</span></button>`).join('');
 obMark();$('#obun').value=OB.user;OB.user?unSet('ok','Este é o seu username.'):unSet('','');unView();obGo(0)}
function obMark(){$$('.ob-gc').forEach(b=>b.setAttribute('aria-checked',b.dataset.g==OB.goal));
 $$('.ob-pc').forEach(b=>b.setAttribute('aria-pressed',OB.plats.includes(b.dataset.p)))}
function obGo(n){clearTimeout(obAT);obAT=0;OB.s=n;obs.dataset.s=n;
 $$('.ob-p',obs).forEach(x=>{x.hidden=+x.dataset.p!=n});
 $('#obpg i').style.width=(n+1)*20+'%';$('#obpg').setAttribute('aria-valuenow',n+1);
 $('#obb').hidden=n==0;$('#obs').hidden=n<2||n==4;$('#obsh').hidden=n!=4;
 if(n==0)unView();if(n==3)obRows();if(n==4){obs.dataset.tab=OB.tab;obs.dataset.btn=OB.btn;obPrev();obSw();obBo()}
 obCan();scrollTo(0,0)}
function obCan(){const n=$('#obn');n.disabled=OB.s==0?!(OB.un=='ok'||OB.un=='unk'):OB.s==1?!OB.goal:OB.s==2?!OB.plats.length:false}

/* escolha única: ao tocar numa opção, avança sozinho (sem botão Continuar). Pausa curta só para ver a seleção. */
let obAT=0;
$('#obgl').onclick=e=>{const b=e.target.closest('.ob-gc');if(!b||obAT)return;OB.goal=b.dataset.g;obMark();obCan();
 const rm=matchMedia('(prefers-reduced-motion:reduce)').matches;
 obAT=setTimeout(()=>{obAT=0;if(OB&&OB.s==1)obGo(2)},rm?0:260)};
$('#obpl').onclick=e=>{const b=e.target.closest('.ob-pc');if(!b)return;const k=b.dataset.p,i=OB.plats.indexOf(k);
 if(i>=0)OB.plats.splice(i,1);else OB.plats.push(k);obMark();obCan()};

function obRows(){const sel=OB.plats.map(obP);$('#obsel').hidden=!sel.length;
 $('#obrs').innerHTML=sel.map((p,k)=>`<label class="ob-r" style="--k:${k}"><span class="ob-ri" style="${p[2]}">${obSvg(p)}</span><input class="ob-in" data-p="${p[0]}" type="${p[6]=='phone'?'tel':'text'}" inputmode="${p[6]=='phone'?'tel':p[6]=='url'?'url':'text'}" placeholder="${p[4]}" aria-label="${p[1]}" maxlength="200" autocomplete="off" autocapitalize="off" spellcheck="false"></label>`).join('');
 $('#obex').innerHTML=OB.extra.map((v,k)=>`<label class="ob-r" style="--k:${k+sel.length}"><span class="ob-ri lnk">${I('lk2')}</span><input class="ob-in" data-x="${k}" type="text" inputmode="url" placeholder="url" aria-label="Link adicional ${k+1}" maxlength="300" autocomplete="off" autocapitalize="off" spellcheck="false"></label>`).join('');
 $$('#obrs .ob-in').forEach(i=>i.value=OB.vals[i.dataset.p]||'');$$('#obex .ob-in').forEach(i=>i.value=OB.extra[+i.dataset.x])}
obs.addEventListener('input',e=>{const i=e.target.closest('.ob-in');if(!i)return;i.parentNode.classList.remove('er');
 if(i.dataset.p)OB.vals[i.dataset.p]=i.value;else OB.extra[+i.dataset.x]=i.value});
obs.addEventListener('keydown',e=>{if(e.key=='Enter'&&e.target.closest('.ob-in,.ob-un')){e.preventDefault();e.target.blur();if(OB.s==0||OB.s==3){if(!$('#obn').disabled)obNext()}}});

function obUrl(p,v){v=v.trim();if(!v||v=='@')return '';
 if(p[6]=='phone'){const d=v.replace(/\D/g,'');return d.length>=7?'https://wa.me/'+d:null}
 if(/^https?:\/\//i.test(v)||p[6]=='url'||/^(www\.)?[\w-]+(\.[\w-]+)+(\/|$)/i.test(v))return pfUrl(v);
 const h=v.replace(/^@/,'').replace(/^\/+/,'');return /^[\w.\-]+$/.test(h)?p[5]+h:null}
function obHost(u){try{return new URL(u).hostname.replace(/^www\./,'').slice(0,60)}catch(e){return u.slice(0,60)}}
function obCollect(){const links=[],bad=[];
 OB.plats.map(obP).forEach(p=>{const r=obUrl(p,OB.vals[p[0]]||'');if(r===null)bad.push('p:'+p[0]);else if(r)links.push({name:p[1],url:r})});
 OB.extra.forEach((v,k)=>{v=v.trim();if(!v)return;const r=pfUrl(v);if(r)links.push({name:obHost(r),url:r});else bad.push('x:'+k)});
 return {links,bad}}

async function obNext(){if(OB.s==0){if(await unClaim())obGo(1);return}
 if(OB.s==1||OB.s==2){obGo(OB.s+1);return}
 if(OB.s==3){const {bad}=obCollect();
  if(bad.length){$$('.ob-r',obs).forEach(r=>{const i=$('.ob-in',r);if(!i)return;const k=i.dataset.p?'p:'+i.dataset.p:'x:'+i.dataset.x;
   if(bad.includes(k)){r.classList.remove('er');void r.offsetWidth;r.classList.add('er')}});
   const f=$$('.ob-r.er .ob-in',obs)[0];if(f)f.focus();toast('Confira os links destacados.');return}
  obGo(4)}}
$('#obn').onclick=obNext;
$('#obb').onclick=()=>{if(OB.s>0)obGo(OB.s-1)};
$('#obs').onclick=()=>{if(OB.s==2)OB.plats=[];if(OB.s>=2&&OB.s<4)obGo(OB.s+1)};

/* passo 4: prévia + cores + estilo de botão */
function obPrev(){const sc=$('.ob-sc'),tx=obTx(OB.bg);sc.style.setProperty('--bg-c',OB.bg);sc.style.setProperty('--tx',tx);
 const p=S.profile||blankProfile(),nm=(p.username||p.name||(S.u&&S.u.name)||'').trim();
 $('#obnm').textContent=nm.replace(/^@/,'');$('#obai').textContent=nm.replace(/^@/,'').slice(0,1).toUpperCase();
 $('#obim').hidden=!p.photo;if(p.photo)$('#obim').src=p.photo;
 $('#obso').innerHTML=OB.plats.slice(0,5).map(k=>{const q=obP(k);return q?obSvg(q):''}).join('');
 const names=obCollect().links.map(l=>l.name);while(names.length<3)names.push('Seu link aqui');
 $('#obbs').innerHTML=names.slice(0,3).map(()=>'<span class="ob-b"></span>').join('');$$('#obbs .ob-b').forEach((b,i)=>b.textContent=names[i])}
function obSw(){const cs=$('#obcs'),isC=!OBC.some(c=>c.toLowerCase()==OB.bg.toLowerCase());
 cs.innerHTML=OBC.map(c=>`<button class="ob-sw" type="button" data-c="${c}" style="--c:${c}" aria-label="Cor ${c}" aria-pressed="${c.toLowerCase()==OB.bg.toLowerCase()}"></button>`).join('')+
  `<label class="ob-sw c" aria-label="Escolher outra cor" aria-pressed="${isC}" style="${isC?'--c:'+OB.bg+';background:'+OB.bg:''}"><svg viewBox="0 0 24 24"><path d="M12 3a9 9 0 100 18c1.300 0 2-.9 2-1.800 0-1.400-1.200-1.700-1.200-3 0-1 .8-1.700 1.900-1.700H17a4 4 0 004-4c0-4-4-7.500-9-7.500z"/><circle cx="7.600" cy="11.400" r="1.100"/><circle cx="10.400" cy="7.400" r="1.100"/><circle cx="15" cy="7.600" r="1.100"/></svg><input type="color" value="${OB.bg.toLowerCase()}" aria-label="Escolher outra cor"></label>`}
function obBo(){$('#obbsel').innerHTML=OBB.map(b=>`<button class="ob-bo ${b[0]}" type="button" data-b="${b[0]}" aria-pressed="${b[0]==OB.btn}"><span>${b[1]}</span></button>`).join('')}
$('#obcs').addEventListener('click',e=>{const b=e.target.closest('button.ob-sw');if(!b)return;OB.bg=b.dataset.c;obPrev();obSw()});
$('#obcs').addEventListener('input',e=>{if(e.target.type!='color')return;OB.bg=e.target.value;obPrev();const l=e.target.parentNode;l.style.background=OB.bg;
 $$('#obcs button.ob-sw').forEach(x=>x.setAttribute('aria-pressed','false'));l.setAttribute('aria-pressed','true');l.style.setProperty('--c',OB.bg)});
$('#obbsel').onclick=e=>{const b=e.target.closest('.ob-bo');if(!b)return;OB.btn=b.dataset.b;obs.dataset.btn=OB.btn;obBo()};
$('#obtb').onclick=e=>{const b=e.target.closest('button[data-k]');if(!b)return;OB.tab=b.dataset.k;obs.dataset.tab=OB.tab;
 $$('#obtb button').forEach(x=>x.setAttribute('aria-selected',x==b));$('#obbsel').hidden=OB.tab!='btn';$('#obcs').hidden=OB.tab!='bg'};

/* concluir: grava no perfil (Firestore) e segue para os planos */
$('#obdone').onclick=()=>{const {links}=obCollect(),p=S.profile=cleanProfile(S.profile);
 const seen=new Set(links.map(l=>l.url));
 p.links=links.concat(p.links.filter(l=>!seen.has(l.url))).slice(0,PF_MAX);
 p.goal=OB.goal;p.plats=OB.plats.slice();p.bg=OB.bg;p.btn=OB.btn;p.onboarded=true;
 if(!p.name)p.name=p.username||(S.u&&S.u.name)||'';
 pfDirty=false;save();flush();location.hash='planos'};


/* ---------- username: validar, checar disponibilidade e reservar (coleção "usernames") ---------- */
const UN_RES=['admin','administrador','app','api','entrar','cadastro','login','logout','planos','plano','onboarding','inicio','recuperar','quantum','suporte','support','ajuda','help','perfil','settings','config','root','null','undefined'];
let unT=0,unSeq=0;
function unSet(st,msg){OB.un=st;const e=$('#obus');e.dataset.st=st;e.textContent=msg;$('.ob-un').dataset.st=st;obCan()}
function unView(){const v=OB.user||'',l=$('#obul');
 if(v.length>=3){l.hidden=false;l.innerHTML='Sua página: <b></b>';$('b',l).textContent=(location.host||'quantum.app')+'/#/'+v}else l.hidden=true}
function unInput(){const i=$('#obun'),v=i.value.toLowerCase().replace(/[^a-z0-9_]/g,'');if(i.value!==v)i.value=v;
 OB.user=v;clearTimeout(unT);const my=++unSeq;unView();
 if(!v){unSet('','');return}
 if(v.length<3){unSet('bad','Use pelo menos 3 caracteres.');return}
 if(UN_RES.includes(v)){unSet('bad','Este nome não está disponível.');return}
 if(S.profile&&S.profile.username==v){unSet('ok','Este é o seu username.');return}
 unSet('chk','Verificando…');
 unT=setTimeout(async()=>{
  try{await fbReady();const s=await FB.getDoc(FB.doc(FB.db,'usernames',v));if(my!=unSeq)return;
   if(s.exists()&&(s.data()||{}).uid!==(uid||FB.auth.currentUser&&FB.auth.currentUser.uid))unSet('bad','Já está em uso. Tente outro.');
   else unSet('ok','Disponível!')}
  catch(e){if(my!=unSeq)return;console.error('username:',e);unSet('unk','Não foi possível verificar agora. Vamos tentar ao continuar.')}},450)}
$('#obun').addEventListener('input',unInput);
async function unClaim(){const v=OB.user,p=S.profile=cleanProfile(S.profile);
 if(!/^[a-z0-9_]{3,20}$/.test(v)||UN_RES.includes(v)){const f=$('.ob-un');f.classList.remove('er');void f.offsetWidth;f.classList.add('er');return false}
 if(p.username==v)return true;
 const b=$('#obn');b.disabled=true;b.innerHTML='<span class="spin"></span>';let ok=false;
 try{await fbReady();const id=uid||FB.auth.currentUser.uid;
  await Promise.race([FB.setDoc(FB.doc(FB.db,'usernames',v),{uid:id,createdAt:FB.serverTimestamp()}),new Promise((_,j)=>setTimeout(()=>j({code:'timeout'}),12000))]);
  const old=p.username;p.username=v;save();ok=true;
  if(old&&old!==v){try{await FB.deleteDoc(FB.doc(FB.db,'dir',old))}catch(e){console.warn('dir antigo:',e)}dirLast='';
   try{await FB.deleteDoc(FB.doc(FB.db,'usernames',old))}catch(e){console.warn('username antigo:',e)}}}
 catch(e){console.error('claim:',e);
  if(e&&e.code=='permission-denied'){unSet('bad','Já está em uso. Tente outro.');const f=$('.ob-un');f.classList.remove('er');void f.offsetWidth;f.classList.add('er')}
  else toast(e&&e.code=='timeout'?'Sem resposta do servidor. Verifique a internet.':'Não foi possível reservar o username. Tente novamente.')}
 b.textContent='Continuar';obCan();return ok}


/* ==========================================================
   PÁGINA PÚBLICA  (#/username)  — lê pages/{username}, sem login
   ========================================================== */
let pubLast='';
async function publishPage(force){const p=S.profile;if(!uid||!cloudOK||!FB||!p||!p.username)return;
 const pr=PL[S.u&&S.u.plan],d={name:p.name,bio:p.bio,text:p.text,photo:p.photo,links:p.links.filter(l=>!l.hide&&!l.arch),bg:p.bg,btn:p.btn,plats:p.plats,look:p.look,verify:p.verify||'',pcv:p.pcv||'',r:pr?pr.r:0,pu:+(S.u&&S.u.premiumUntil)||0},j=p.username+JSON.stringify(d);
 if(!force&&j===pubLast)return;
 try{await FB.setDoc(FB.doc(FB.db,'pages',p.username),{...d,updatedAt:FB.serverTimestamp()});pubLast=j}
 catch(e){console.error('pages:',e);if(e&&e.code=='permission-denied')toast('Não foi possível publicar a sua página. Falta a regra "pages" no Firestore.',6000);return}
 dirPub(p)}
const pubV=$('#v-pub'),PUBR=/^[a-z0-9_]{3,20}$/;let pubSeq=0,pubOn=false,pubCur='';
const pubHost=()=>location.href.split('#')[0];
function pubLeave(){pubOn=false;pubCur='';document.title='Quantum';document.body.style.background='';
 {const m=document.querySelector('meta[name=theme-color]');m&&(m.content='#05080F')}}
function pubShow(){pubOn=true;$$('.view').forEach(x=>x.classList.toggle('on',x.id=='v-pub'));
 dock.hidden=true;document.body.classList.remove('has-dock');$('#boot').classList.add('off');setTimeout(()=>$('#boot').hidden=true,350);prevV='pub';scrollTo(0,0)}
function pubMiss(u,err){pubV.dataset.st=err?'err':'miss';document.body.style.background='';document.title='Quantum';pubCur='';
 $('#pubmt').textContent=err?'Não foi possível carregar':'Página não encontrada';
 const t=$('#pubmp');t.textContent=err?'Verifique a internet e tente de novo.':(u?'@'+u+' ainda não existe.':'Esse endereço não é válido.')}
async function pubRoute(raw){let u;try{u=decodeURIComponent(raw)}catch(e){u=''}
 u=u.replace(/^@/,'').toLowerCase().split(/[/?]/)[0];const my=++pubSeq;pubShow();
 if(u&&u==pubCur&&pubV.dataset.st=='ok')return;
 pubV.dataset.st='load';
 if(!PUBR.test(u)){pubMiss(u);return}
 try{await fbReady();const s=await FB.getDoc(FB.doc(FB.db,'pages',u));if(my!=pubSeq)return;
  if(!s.exists()){pubMiss(u);return}
  pubRender(u,cleanProfile(s.data()),s.data());stVisit(u)}
 catch(e){if(my!=pubSeq)return;console.error('pública:',e);pubMiss(u,true)}}
function pubRender(u,p,raw){pubCur=u;raw=raw||{};const pu=+raw.pu||0,rk=(+raw.r||0)>=1&&(!pu||pu>Date.now())?(+raw.r||0):0;p.look=lkEnforce(p.look,rk);
 const nm=(p.name||u).trim(),A=lkApply(pubV,p.look);
 pubV.dataset.st='ok';document.body.style.background=A.solid;document.title=nm+' | Quantum';
 let m=document.querySelector('meta[name=theme-color]');if(!m){m=document.createElement('meta');m.name='theme-color';document.head.append(m)}m.content=A.solid;
 lkPaint($('#pubin'),p,u,true)}



/* perfil: link da página pública */
function pfPubLink(){const u=S.profile&&S.profile.username;ED.url=u?pubHost()+'#/'+u:''}

/* ===== v38: aparência — renderizador (página pública + prévia) e editor ===== */
/* [pilha de fontes, família no Google Fonts, peso do nome, peso do botão] */
const LK_FF={
 inter:["Inter,system-ui,-apple-system,sans-serif",'Inter:wght@400;600;700',700,600],
 poppins:["Poppins,system-ui,sans-serif",'Poppins:wght@400;600;700',700,600],
 dmsans:['"DM Sans",system-ui,sans-serif','DM+Sans:wght@400;600;700',700,600],
 montserrat:["Montserrat,system-ui,sans-serif",'Montserrat:wght@300;400;600;700',700,600],
 lora:["Lora,Georgia,serif",'Lora:wght@400;600;700',700,600],
 playfair:['"Playfair Display",Georgia,serif','Playfair+Display:wght@400;600;700',700,600],
 sourceserif:['"Source Serif 4","Source Serif Pro",Georgia,serif','Source+Serif+4:wght@400;600;700',700,600],
 bebas:['"Bebas Neue",Impact,sans-serif','Bebas+Neue',400,400],
 oswald:["Oswald,Impact,sans-serif",'Oswald:wght@400;600;700',600,500],
 abril:['"Abril Fatface",Georgia,serif','Abril+Fatface',400,400],
 pacifico:["Pacifico,cursive",'Pacifico',400,400],
 caveat:["Caveat,cursive",'Caveat:wght@400;600;700',700,600],
 dancing:['"Dancing Script",cursive','Dancing+Script:wght@400;600;700',700,600],
 spacemono:['"Space Mono",ui-monospace,monospace','Space+Mono:wght@400;700',700,700],
 jetbrains:['"JetBrains Mono",ui-monospace,monospace','JetBrains+Mono:wght@400;600;700',700,600],
 archivo:['"Archivo Black",sans-serif','Archivo+Black',400,400],
 anton:['Anton,Impact,sans-serif','Anton',400,400],
 lexend:['"Lexend Zetta",sans-serif','Lexend+Zetta:wght@400;700',700,600],
 orbitron:['Orbitron,sans-serif','Orbitron:wght@400;800',800,700],
 baskerville:['Baskervville,serif','Baskervville:wght@400;700',700,600],
 spectral:['Spectral,serif','Spectral:wght@400;700',700,600],
 eczar:['Eczar,serif','Eczar:wght@400;700',700,600],
 cambo:['Cambo,serif','Cambo',400,400],
 croissant:['"Croissant One",cursive','Croissant+One',400,400],
 limelight:['Limelight,cursive','Limelight',400,400],
 monoton:['Monoton,cursive','Monoton',400,400],
 piedra:['Piedra,cursive','Piedra',400,400],
 tradewinds:['"Trade Winds",cursive','Trade+Winds',400,400],
 chewy:['Chewy,cursive','Chewy',400,400],
 shortstack:['"Short Stack",cursive','Short+Stack',400,400],
 molle:['Molle,cursive','Molle:ital@1',400,400],
 oleo:['"Oleo Script",cursive','Oleo+Script:wght@400;700',700,700],
 lobster:['Lobster,cursive','Lobster',400,400],
 righteous:['Righteous,cursive','Righteous',400,400],
 permanentmarker:['"Permanent Marker",cursive','Permanent+Marker',400,400],
 gloria:['"Gloria Hallelujah",cursive','Gloria+Hallelujah',400,400],
 sacramento:['Sacramento,cursive','Sacramento',400,400],
 parisienne:['Parisienne,cursive','Parisienne',400,400],
 greatvibes:['"Great Vibes",cursive','Great+Vibes',400,400],
 pinyon:['"Pinyon Script",cursive','Pinyon+Script',400,400],
 allura:['Allura,cursive','Allura',400,400],
 satisfy:['Satisfy,cursive','Satisfy',400,400],
 yellowtail:['Yellowtail,cursive','Yellowtail',400,400],
 tangerine:['Tangerine,cursive','Tangerine:wght@400;700',700,700],
 albert:['"Albert Sans",system-ui,sans-serif','Albert+Sans:wght@400;600;700',700,600],
 belanosima:['Belanosima,system-ui,sans-serif','Belanosima:wght@400;600;700',700,600],
 bricolage:['"Bricolage Grotesque",system-ui,sans-serif','Bricolage+Grotesque:wght@400;600;700',700,600],
 epilogue:['Epilogue,system-ui,sans-serif','Epilogue:wght@400;600;700',700,600],
 plex:['"IBM Plex Sans",system-ui,sans-serif','IBM+Plex+Sans:wght@400;600;700',700,600],
 lato:['Lato,system-ui,sans-serif','Lato:wght@400;700',700,700],
 mplus:['"M PLUS Rounded 1c",system-ui,sans-serif','M+PLUS+Rounded+1c:wght@400;700',700,700],
 manrope:['Manrope,system-ui,sans-serif','Manrope:wght@400;600;700',700,600],
 nunito:['Nunito,system-ui,sans-serif','Nunito:wght@400;600;700',700,600],
 opensans:['"Open Sans",system-ui,sans-serif','Open+Sans:wght@400;600;700',700,600],
 roboto:['Roboto,system-ui,sans-serif','Roboto:wght@400;500;700',700,500],
 worksans:['"Work Sans",system-ui,sans-serif','Work+Sans:wght@400;600;700',700,600],
 quicksand:['Quicksand,system-ui,sans-serif','Quicksand:wght@400;600;700',700,600],
 raleway:['Raleway,system-ui,sans-serif','Raleway:wght@400;600;700',700,600],
 spacegrotesk:['"Space Grotesk",system-ui,sans-serif','Space+Grotesk:wght@400;600;700',700,600],
 rubik:['Rubik,system-ui,sans-serif','Rubik:wght@400;600;700',700,600],
 outfit:['Outfit,system-ui,sans-serif','Outfit:wght@400;600;700',700,600],
 sora:['Sora,system-ui,sans-serif','Sora:wght@400;600;700',700,600],
 jakarta:['"Plus Jakarta Sans",system-ui,sans-serif','Plus+Jakarta+Sans:wght@400;600;700',700,600],
 fraunces:['Fraunces,Georgia,serif','Fraunces:wght@400;600;700',700,600]};
const lkFonts=new Set(['inter']);
function lkLoadFonts(L){[L.font.name,L.font.bio,L.font.btn,L.head&&L.head.altFont?L.head.font:L.font.name].forEach(id=>{if(lkFonts.has(id))return;lkFonts.add(id);
 const a=document.createElement('link');a.rel='stylesheet';a.href='https://fonts.googleapis.com/css2?family='+LK_FF[id][1]+'&display=swap';document.head.append(a)})}
const lkMix=(a,b)=>{const f=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)),x=f(a),y=f(b);return '#'+x.map((v,i)=>Math.round((v+y[i])/2).toString(16).padStart(2,'0')).join('')};
const lkShade=(h,t)=>{t=+t||0;if(!t)return h;const k=Math.abs(t)/100,m=t<0?0:255;return '#'+[1,3,5].map(i=>Math.round(parseInt(h.slice(i,i+2),16)*(1-k)+m*k).toString(16).padStart(2,'0')).join('')};
/* ===== v46: camada do fundo — ÚNICO ponto que desenha imagem, vídeo, desfoque, estampa, degradê animado e granulado.
   Fundo preenchido e degradê simples continuam só na variável --bg-c (nada muda para eles). ===== */
function lkBgSrc(el,src){if(src){if(el.getAttribute('src')!==src){el.setAttribute('src',src);if(el.play){el.muted=true;const pr=el.play();if(pr&&pr.catch)pr.catch(()=>{})}}}
 else if(el.getAttribute('src')){if(el.pause)el.pause();el.removeAttribute('src');if(el.load)el.load()}}
function lkBg(el,L){const b=L.bg,gr=b.type=='gradient',md=b.type=='image'||b.type=='video',
 need=md||b.type=='blur'||b.type=='pattern'||(gr&&(b.animate||b.grain));
 let ly=el.querySelector(':scope>.lk-bgl');
 if(!need){if(ly)ly.remove();return}
 if(!ly){ly=document.createElement('div');ly.className='lk-bgl';ly.setAttribute('aria-hidden','true');
  ly.innerHTML='<div class="lk-bgm"><img alt=""><video muted loop playsinline autoplay></video></div><i class="lk-bgt"></i>';el.prepend(ly)}
 const im=ly.querySelector('img'),vd=ly.querySelector('video'),was=ly.dataset.t;
 ly.dataset.t=b.type;ly.dataset.fx=md?b.fx:'none';ly.dataset.pt=b.pattern;ly.dataset.g=b.grain&&(gr||b.type=='image')?'1':'';
 ly.classList.toggle('an',gr&&b.animate);
 ly.style.setProperty('--lk-gd',gr?`linear-gradient(${b.g.angle}deg,${b.g.c1},${b.g.c2}${b.animate?','+b.g.c1:''})`:'none');
 ly.style.setProperty('--lk-gz',b.animate?'300% 300%':'100% 100%');
 ly.style.setProperty('--lk-tn',md&&b.tone?(b.tone<0?`rgba(0,0,0,${-b.tone/100})`:`rgba(255,255,255,${b.tone/100})`):'transparent');
 lkBgSrc(vd,b.type=='video'?b.video:'');
 if(b.type=='image')lkBgSrc(im,b.img);else if(b.type!='blur'||was!='blur')lkBgSrc(im,'')}
/* desfoque: usa a foto de perfil (vem do lkPaint, que é quem conhece a foto) */
function lkBgPhoto(host,photo){const ly=host&&host.querySelector(':scope>.lk-bgl');if(ly&&ly.dataset.t=='blur')lkBgSrc(ly.querySelector('img'),photo||'')}
const LK_PX={s:80,m:96,l:124};
/* aplica o look num elemento (página pública, prévia ou cartão de tema): só variáveis CSS e atributos */
function lkApply(el,L,noFonts){const b=L.bg,t=L.btn,gr=b.type=='gradient';
 const md=b.type=='image'||b.type=='video',base=gr?lkMix(b.g.c1,b.g.c2):md?lkShade(b.fx=='halftone'?'#000000':b.color,b.tone):b.color,css=gr?`linear-gradient(${b.g.angle}deg,${b.g.c1},${b.g.c2})`:base,tx=obTx(base);
 const ac=t.color||tx,op=t.op==null?100:t.op,mx=c=>op<100?`color-mix(in srgb,${c} ${op}%,transparent)`:c;let bb,bd,bt;
 if(t.fill=='outline'){bb='transparent';bd=`2px solid ${mx(ac)}`;bt=t.text||tx}
 else if(!t.color){bb=mx('color-mix(in srgb,var(--tx) 16%,transparent)');bd='1px solid color-mix(in srgb,var(--tx) 30%,transparent)';bt=t.text||tx}
 else{bb=mx(t.color);bd='1px solid transparent';bt=t.text||obTx(t.color)}
 if(t.shadow=='hard')bd=`2px solid ${t.fill=='outline'?mx(ac):tx}`;
 if(t.bw>=0)bd=t.bw?`${t.bw}px solid ${mx(ac)}`:'0 solid transparent';
 const soft='0 12px 24px -12px rgba(0,0,0,.5)',v=(k,x)=>el.style.setProperty(k,x);
 v('--bg-c',css);v('--tx',tx);v('--lk-r',t.rad>=0?t.rad+'px':{square:'4px',round:'16px',pill:'999px'}[t.shape]);v('--lk-bh',(t.bh||56)+'px');v('--lk-bwd',(t.wd||100)+'%');
 v('--lk-bb',bb);v('--lk-bd',bd);v('--lk-bt',bt);
 v('--lk-sh',{none:'none',soft,hard:`4px 4px 0 ${tx}`}[t.shadow]);
 v('--lk-shh',t.shadow=='hard'?`6px 6px 0 ${tx}`:'0 14px 26px -14px rgba(0,0,0,.45)');
 v('--lk-bgh',t.fill=='outline'?`color-mix(in srgb,${ac} 12%,transparent)`:(!t.color?'color-mix(in srgb,var(--tx) 24%,transparent)':bb));
 v('--lk-gl',`0 0 0 3px color-mix(in srgb,${ac} 35%,transparent),0 0 26px color-mix(in srgb,${ac} 65%,transparent)`);
 const H=L.head;el.dataset.layout=H.layout;el.dataset.fa=H.fa;el.dataset.fp=H.fp;el.dataset.bs=t.rad>=0?'custom':t.shape;v('--lk-fo',(H.fo/100).toFixed(2));v('--lk-fz',(H.fz/100).toFixed(2));v('--lk-fx',H.fx+'%');v('--lk-fy',H.fy+'%');v('--lk-fxn',(H.fx/100).toFixed(4));v('--lk-fyn',(H.fy/100).toFixed(4));[['nx',H.nx],['ny',H.ny],['bx',H.bx],['by',H.by],['lx',H.lx],['ly',H.ly]].forEach(a=>v('--lk-'+a[0],a[1]||0));v('--lk-nz',H.nz+'px');v('--lk-bz',H.bz+'px');if(H.bc){el.dataset.bc='1';v('--lk-bc',H.bc)}else delete el.dataset.bc;v('--lk-sm',lkShapeUrl(H.shape));if(L.hideBrand)el.dataset.nb='1';else delete el.dataset.nb;if(H.color){el.dataset.tc='1';v('--lk-tc',H.color)}else delete el.dataset.tc;if(L.tx){el.dataset.pt='1';v('--lk-pt',L.tx)}else delete el.dataset.pt;
 const fn=LK_FF[H.altFont?H.font:L.font.name],fb=LK_FF[L.font.bio],ft=LK_FF[L.font.btn];
 v('--lk-fn',fn[0]);v('--lk-nw',fn[2]);v('--lk-fb',fb[0]);v('--lk-fbt',ft[0]);v('--lk-bw',ft[3]);
 v('--lk-ps',LK_PX[L.photo.size]+'px');v('--lk-pr',L.photo.shape=='circle'?'50%':'28%');
 el.dataset.hover=t.hover;el.dataset.soc=L.social;
 if(!noFonts)lkLoadFonts(L);
 lkBg(el,L);return {css,solid:gr?b.g.c1:base,tx}}
/* escreve nome, bio, foto, ícones e links dentro de uma raiz (.pub-in ou .lk-in); live=false → só prévia */
function lkPaint(root,p,u,live){const q=s=>$(s,root),nm=(p.name||u).trim();
 q('h1').textContent=nm;q('h1').toggleAttribute('data-vf',p.verify=='ok');{const L=p.look,lg=q('.pub-logo'),on=!!(L&&L.head&&L.head.titleStyle=='logo'&&L.head.logo);if(lg){lg.hidden=!on;if(on)lg.src=L.head.logo;else lg.removeAttribute('src');q('h1').hidden=on}}q('.pub-u').textContent='@'+u;q('.pub-av span').textContent=nm.replace(/^@/,'').slice(0,1).toUpperCase();
 const im=q('.pub-av img');im.hidden=!p.photo;if(p.photo)im.src=p.photo;else im.removeAttribute('src');
 {const host=root.closest('.lkroot');if(host){if(p.photo){const set=()=>{if(im.naturalWidth){host.style.setProperty('--lk-ia',(im.naturalWidth/im.naturalHeight).toFixed(4));host.dataset.ia='1'}};if(im.complete&&im.naturalWidth)set();else im.onload=set}else{host.style.removeProperty('--lk-ia');delete host.dataset.ia}}}
 const b=q('.pub-bio');b.textContent=p.text||'';b.hidden=!p.text;
 const links=p.links.filter(l=>/^https?:\/\//i.test(l.url)&&!l.hide&&!l.arch);
 const so=q('.pub-so');so.textContent='';
 p.plats.map(obP).filter(Boolean).forEach(pl=>{const l=links.find(x=>x.name==pl[1]);if(!l)return;
  const a=document.createElement(live?'a':'span');a.className='pub-s';
  if(live){a.href=l.url;a.target='_blank';a.rel='noopener noreferrer nofollow'}
  a.setAttribute('aria-label',pl[1]);a.innerHTML=obSvg(pl);so.append(a)});
 so.hidden=!so.children.length;
 const ls=q('.pub-ls');ls.textContent='';
 links.forEach((l,k)=>{const a=document.createElement(live?'a':'span');a.className='pub-b';
  if(live){a.href=l.url;a.target='_blank';a.rel='noopener noreferrer nofollow'}
  a.style.setProperty('--k',k);a.textContent=l.name;if(live)a.addEventListener('click',()=>stHit(u,i=>({k:i(1),l:{[stKey(l.name)]:i(1)}})));ls.append(a)});
 {const H=p.look&&p.look.head,C=(H&&H.cover)||{},cv=q('.pub-cv');
  if(cv){const ci=$('img',cv),cd=$('video',cv),vid=C.type=='video'&&C.video,img=!vid&&C.img;
   ci.hidden=!img;if(img){if(ci.getAttribute('src')!==img)ci.src=img}else if(ci.getAttribute('src'))ci.removeAttribute('src');
   cd.hidden=!vid;if(vid){if(cd.getAttribute('src')!==vid){cd.src=vid;cd.muted=true;const pr=cd.play&&cd.play();if(pr&&pr.catch)pr.catch(()=>{})}}else if(cd.getAttribute('src')){cd.pause&&cd.pause();cd.removeAttribute('src');cd.load&&cd.load()}
   cv.classList.toggle('has',!!(img||vid))}}
 lkBgPhoto(root.closest('.lkroot'),p.photo);shPaint(root,p,live)}

/* temas prontos */
const lkT=(id,n,bg,btn,font)=>({id,n,look:{bg:bg.length?{type:'gradient',color:bg[0],g:{c1:bg[0],c2:bg[1],angle:bg[2]}}:bg,btn,font}});
const LK_THEMES=[
 lkT('quantum','Quantum',['#1e6bff','#3ccdff',160],{shape:'pill',fill:'solid',shadow:'none',color:'',text:'',hover:'lift'},{name:'inter',bio:'inter',btn:'inter'}),
 {...lkT('fashion','Fashion',['#0d0d0d','#1d5a52',180],{shape:'square',fill:'solid',shadow:'none',color:'#2b2b2b',text:'#ffffff',hover:'lift'},{name:'montserrat',bio:'montserrat',btn:'montserrat'}),vip:1,head:{layout:'fashion',fo:55,fa:'center',fp:'bottom',fz:100,fx:50,fy:0,nz:46,bc:'',nx:0,ny:0,bx:0,by:0,lx:0,ly:0}},
 {...lkT('editorial','Editorial',{type:'solid',color:'#efe8da'},{shape:'pill',fill:'solid',shadow:'none',color:'#0d0d0d',text:'#ffffff',hover:'lift'},{name:'montserrat',bio:'montserrat',btn:'montserrat'}),vip:1,head:{layout:'sheet'}},
 lkT('noite','Noite',{type:'solid',color:'#0b1220'},{shape:'round',fill:'solid',shadow:'soft',color:'#1e6bff',text:'#ffffff',hover:'grow'},{name:'poppins',bio:'poppins',btn:'poppins'}),
 lkT('minimal','Minimalista',{type:'solid',color:'#f5f3ee'},{shape:'square',fill:'outline',shadow:'none',color:'#111111',text:'#111111',hover:'lift'},{name:'dmsans',bio:'dmsans',btn:'dmsans'}),
 lkT('sunset','Pôr do sol',['#ff7e5f','#feb47b',160],{shape:'pill',fill:'solid',shadow:'soft',color:'#ffffff',text:'#4a1d0e',hover:'lift'},{name:'montserrat',bio:'montserrat',btn:'montserrat'}),
 lkT('oceano','Oceano',['#0f2027','#2c5364',180],{shape:'pill',fill:'solid',shadow:'none',color:'#3ccdff',text:'#06202a',hover:'glow'},{name:'poppins',bio:'dmsans',btn:'poppins'}),
 lkT('algodao','Algodão-doce',['#fbc2eb','#a6c1ee',135],{shape:'pill',fill:'solid',shadow:'soft',color:'#ffffff',text:'#5b3a8c',hover:'grow'},{name:'pacifico',bio:'dmsans',btn:'dmsans'}),
 lkT('brutal','Neo-brutalista',{type:'solid',color:'#ffe14d'},{shape:'square',fill:'solid',shadow:'hard',color:'#ffffff',text:'#111111',hover:'lift'},{name:'spacemono',bio:'spacemono',btn:'spacemono'}),
 lkT('luxo','Luxo',{type:'solid',color:'#111111'},{shape:'square',fill:'outline',shadow:'none',color:'#d4af37',text:'#d4af37',hover:'glow'},{name:'playfair',bio:'lora',btn:'playfair'}),
 lkT('rose','Rosé',{type:'solid',color:'#ffe4ec'},{shape:'pill',fill:'solid',shadow:'soft',color:'#e11d74',text:'#ffffff',hover:'lift'},{name:'dancing',bio:'dmsans',btn:'dmsans'}),
 lkT('terminal','Terminal',{type:'solid',color:'#0d1117'},{shape:'square',fill:'outline',shadow:'none',color:'#39ff14',text:'#39ff14',hover:'glow'},{name:'jetbrains',bio:'jetbrains',btn:'jetbrains'})];
const LK_GP=[['#1e6bff','#3ccdff'],['#ff7e5f','#feb47b'],['#7f00ff','#e100ff'],['#0f2027','#2c5364'],['#fbc2eb','#a6c1ee'],['#11998e','#38ef7d'],
 ['#f12711','#f5af19'],['#232526','#414345'],['#654ea3','#eaafc8'],['#00c6ff','#0072ff'],['#ff512f','#dd2476'],['#134e5e','#71b280']];

/* editor */
let LK=null,LKuid='',lkDirty=false,lkBusy=false,lkBuilt=false,lkH=[],lkHi=0,lkHt=0,lkSaved='';
const LKP={name:'',text:'',photo:''};let lkPBase='';
function lkPInit(){const p=S.profile||{};LKP.name=p.name||'';LKP.text=p.text||'';LKP.photo=p.photo||'';lkPBase=JSON.stringify(LKP)}
const lkPChanged=()=>JSON.stringify(LKP)!==lkPBase,lkIsDirty=()=>lkDirty||lkPChanged();
const lkRank=()=>{try{return plan().r}catch(e){return 0}},lkPlus=()=>lkRank()>=1,lkPro=()=>lkRank()>=2;
const LK_LAY=[['classic','Clássico'],['hero','Hero'],['banner','Banner'],['crop','Recorte'],['shape','Forma']];
const LK_FN={inter:'Inter',poppins:'Poppins',dmsans:'DM Sans',montserrat:'Montserrat',lora:'Lora',playfair:'Playfair Display',sourceserif:'Source Serif',bebas:'Bebas Neue',oswald:'Oswald',abril:'Abril Fatface',pacifico:'Pacifico',caveat:'Caveat',dancing:'Dancing Script',spacemono:'Space Mono',jetbrains:'JetBrains Mono',archivo:'Archivo Black',anton:'Anton',lexend:'Lexend Zetta',orbitron:'Orbitron',baskerville:'Baskerville',spectral:'Spectral',eczar:'Eczar',cambo:'Cambo',croissant:'Croissant One',limelight:'Limelight',monoton:'Monoton',piedra:'Piedra',tradewinds:'Trade Winds',chewy:'Chewy',shortstack:'Short Stack',molle:'Molle',oleo:'Oleo Script',lobster:'Lobster',righteous:'Righteous',permanentmarker:'Permanent Marker',gloria:'Gloria Hallelujah',sacramento:'Sacramento',parisienne:'Parisienne',greatvibes:'Great Vibes',pinyon:'Pinyon Script',allura:'Allura',satisfy:'Satisfy',yellowtail:'Yellowtail',tangerine:'Tangerine',albert:'Albert Sans',belanosima:'Belanosima',bricolage:'Bricolage Grotesque',epilogue:'Epilogue',plex:'IBM Plex Sans',lato:'Lato',mplus:'M Plus Rounded',manrope:'Manrope',nunito:'Nunito',opensans:'Open Sans',roboto:'Roboto',worksans:'Work Sans',quicksand:'Quicksand',raleway:'Raleway',spacegrotesk:'Space Grotesk',rubik:'Rubik',outfit:'Outfit',sora:'Sora',jakarta:'Plus Jakarta Sans',fraunces:'Fraunces'};
function lkRepaint(){const p=S.profile;if(!p)return;const smp=[['Meu site'],['Instagram'],['Fale comigo']].map(x=>({name:x[0],url:'https://quantum.app'}));
 lkPaint($('.lk-in',LKE.ph),{...p,name:LKP.name||'Seu nome',text:LKP.text,photo:LKP.photo,look:LK,links:p.links.some(l=>/^https?:\/\//i.test(l.url))?p.links:smp},p.username||'seunome',false)}
function lkHeadFill(){$('#dstt').value=LKP.name;$('#dsbio').value=LKP.text;lkCnt()}
function lkCnt(){$('#dstc').textContent=LKP.name.length+'/30';$('#dsbc').textContent=LKP.text.length+'/160'}
function lkImg(file,o,cb){if(!file)return;if(!/^image\//.test(file.type)||file.size>12e6){toast('Escolha uma imagem de até 12 MB.');return}
 const rd=new FileReader();rd.onerror=()=>toast('Não foi possível ler a imagem.');
 rd.onload=()=>{const im=new Image();im.onerror=()=>toast('Não foi possível abrir essa imagem.');
  im.onload=()=>{const c=document.createElement('canvas'),x=c.getContext('2d');
   if(o.square){const z=o.max,m=Math.min(im.width,im.height);c.width=c.height=z;x.fillStyle='#fff';x.fillRect(0,0,z,z);x.drawImage(im,(im.width-m)/2,(im.height-m)/2,m,m,0,0,z,z);cb(c.toDataURL('image/jpeg',.82))}
   else{const r=Math.min(1,o.max/im.width,o.max/im.height);c.width=Math.max(1,Math.round(im.width*r));c.height=Math.max(1,Math.round(im.height*r));x.drawImage(im,0,0,c.width,c.height);cb(c.toDataURL('image/webp',.85))}};
  im.src=rd.result};rd.readAsDataURL(file)}
function lkHReset(){lkSaved=JSON.stringify(LK);lkH=[lkSaved];lkHi=0}
function lkCommit(co){lkDirty=true;const s=JSON.stringify(LK);
 if(co&&Date.now()-lkHt<700&&lkHi>0&&lkHi==lkH.length-1)lkH[lkHi]=s;
 else{lkH=lkH.slice(0,lkHi+1);lkH.push(s);lkHi=lkH.length-1;if(lkH.length>80){lkH.shift();lkHi--}}
 lkHt=Date.now()}
function lkJump(d){const n=lkHi+d;if(n<0||n>=lkH.length||lkBusy)return;lkHi=n;LK=JSON.parse(lkH[n]);lkDirty=lkH[n]!==lkSaved;lkFill()}
function lkMode(m){LKE.ed.dataset.m=m;if(m!='edit')fpReset();$('#dssheet').hidden=m!='edit';if(m!='edit')lkFill()}
/* ===== v61: aba Texto — seletor de fontes em folha própria ===== */
const FP={on:false,mode:'page'};
const fpReset=()=>{FP.on=false;const sh=$('#dssheet');if(sh)sh.removeAttribute('data-sub')};
function fpBuild(){
 const g=$('#fpg');if(!g||g.childElementCount)return;
 g.innerHTML=LK_FONTS.slice().sort((a,b)=>(LK_FN[a]||a).localeCompare(LK_FN[b]||b)).map(f=>{const pl=LK_FONT_PL[f];
  return `<button type="button" class="fp-c" data-fc="${f}"${pl?` data-pl="${pl}"`:''} role="option" aria-selected="false" aria-pressed="false"><i class="ds-cr" aria-hidden="true"><svg class="i"><use href="#bolt"/></svg></i><span>${LK_FN[f]||f}</span></button>`}).join('');
 $$('.fp-c',g).forEach(b=>{const ff=LK_FF[b.dataset.fc];b.style.fontFamily=ff[0];b.style.fontWeight=ff[3]>500?500:400})}
function fpLoad(){LK_FONTS.forEach(f=>{if(lkFonts.has(f)||!LK_FF[f])return;lkFonts.add(f);const a=document.createElement('link');a.rel='stylesheet';a.href='https://fonts.googleapis.com/css2?family='+LK_FF[f][1]+'&display=swap';document.head.append(a)})}
function fpPaint(hc,pc){
 const pg=$('#fpnm'),tt=$('#fptnm');
 pg.textContent=LK_FN[LK.font.name]||LK.font.name;pg.style.fontFamily=LK_FF[LK.font.name][0];
 tt.textContent=LK_FN[LK.head.font]||LK.head.font;tt.style.fontFamily=LK_FF[LK.head.font][0];
 $('#dstcol').value=hc;$('#dstch').textContent=hc.toLowerCase();
 $('#dspcol').value=pc;$('#dspch').textContent=pc.toLowerCase();
 const cur=FP.mode=='title'?LK.head.font:LK.font.name;
 $$('.fp-c',LKE.ed).forEach(b=>{const on=b.dataset.fc==cur;b.setAttribute('aria-pressed',String(on));b.setAttribute('aria-selected',String(on))})}
function fpOpen(mode){FP.on=true;FP.mode=mode;fpBuild();fpLoad();
 $('#dsst').textContent=mode=='title'?'Fonte do título':'Fonte da página';
 $$('.ds-pn',LKE.ed).forEach(x=>x.hidden=x.dataset.p!='fonts');
 $('#dssheet').dataset.sub='fonts';lkFill();
 const sb=$('.ds-sb',LKE.ed);sb.scrollTop=0;const on=$('.fp-c[aria-pressed="true"]',sb);if(on)requestAnimationFrame(()=>on.scrollIntoView({block:'center'}))}
function fpChoose(f){if(!LK_FF[f])return;
 if(FP.mode=='title'){if(LK.head.font!=f)lkSet('head.font',f);return}
 if(LK.font.name==f&&LK.font.bio==f&&LK.font.btn==f)return;
 lkPut('font.name',f);lkPut('font.bio',f);lkSet('font.btn',f)}
function lkOpen(k){lkBuild();fpReset();$('#dsst').textContent=LK_TTL[k]||'';$$('.ds-pn',LKE.ed).forEach(p=>p.hidden=p.dataset.p!=k);$('.ds-sb',LKE.ed).scrollTop=0;lkMode('edit')}
const lkClone=o=>JSON.parse(JSON.stringify(o));
const LKE={ph:$('#lkph'),ed:$('#lked'),st:$('#lkst'),sv:$('#lksv'),sv2:$('#lksv2'),rs:$('#lkrs'),ths:$('#lkths'),gps:$('#lkgps'),ao:$('#lkao')};
if(window.ResizeObserver)new ResizeObserver(()=>{const w=LKE.ph.clientWidth;if(w)LKE.ph.style.setProperty('--s',(w/360).toFixed(4))}).observe(LKE.ph);
function lkGet(path){return path.split('.').reduce((o,k)=>o[k],LK)}
function lkPut(path,val){const k=path.split('.'),last=k.pop();k.reduce((o,x)=>o[x],LK)[last]=val}
const LK_FEAT=['quantum','noite','sunset','oceano','luxo','rose','fashion','editorial'],LK_TTL={fashion:'Editar Fashion',tema:'Tema',head:'Cabeçalho',bg:'Fundo',text:'Texto',btn:'Botões',colors:'Cores'};
function lkBuild(){if(lkBuilt)return;lkBuilt=true;
 LKE.ths.innerHTML='<button type="button" class="ds-tc" data-th="custom" aria-pressed="false"><span class="ds-tp cu"><svg class="i"><use href="#brush"/></svg></span><small>Personalizado</small></button>'+LK_THEMES.map(t=>`<button type="button" class="ds-tc" data-th="${t.id}" data-f="${LK_FEAT.includes(t.id)?1:0}"${t.vip?' data-pl':''} aria-pressed="false">${t.vip?'<i class="ds-cr"><svg class="i"><use href="#cr"/></svg></i><span class="ds-pen2" aria-hidden="true"><svg class="i"><use href="#pen"/></svg></span>':''}<span class="ds-tp lkroot${t.head?' fx':''}"><img class="ds-tpi" src="theme-demo.jpg" alt=""><i class="pub-b"></i></span><small>${t.n}</small></button>`).join('');
 $$('.ds-tp.lkroot',LKE.ths).forEach((el,i)=>lkApply(el,cleanLook(LK_THEMES[i].look,{})));
 $('#dslay').innerHTML=LK_LAY.map(([id,n])=>`<button type="button" class="ds-lc" data-ly="${id}"${id=='classic'?'':' data-pl'} aria-pressed="false"><i class="ds-cr"><svg class="i"><use href="#cr"/></svg></i><span class="ds-lm ${id}"><span class="ds-la"></span></span><small>${n}</small></button>`).join('');
 $('#dsshp').innerHTML=LK_SHPN.map(([id,n])=>`<button type="button" class="ds-sc" data-sh="${id}" aria-pressed="false"><svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">${LK_SHP[id]}</svg>${n}</button>`).join('');
 fpBuild();
 LKE.gps.innerHTML=LK_GP.map((g,i)=>`<button type="button" class="lk-gp" data-gp="${i}" aria-label="Degradê ${i+1}" aria-pressed="false" style="background:linear-gradient(135deg,${g[0]},${g[1]})"></button>`).join('')}
function lkEnter(){if(!S.profile)return;lkBuild();
 if(!LK||LKuid!=uid||!lkIsDirty()){LK=lkClone(S.profile.look||cleanLook({},S.profile));LKuid=uid;lkDirty=false;lkHReset();lkPInit()}else if(!lkPChanged())lkPInit();
 lkMode('opts');lkHeadFill();lkFill()}
function lkFill(){const A=lkApply(LKE.ph,LK);lkRepaint();{const o=$('#lkbwo');if(o)o.textContent=LK.btn.wd+'%'}
 LKE.ed.style.setProperty('--ph',LKP.photo?`url("${LKP.photo}")`:'none');
 {const H=LK.head,pi=$('#dspim');pi.hidden=!LKP.photo;if(LKP.photo)pi.src=LKP.photo;else pi.removeAttribute('src');$('#dspii').textContent=(LKP.name||(S.profile&&S.profile.username)||'?').slice(0,1).toUpperCase();
  $$('.ds-lc',LKE.ed).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.ly==H.layout)));
  $$('.ds-ts',LKE.ed).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.ts==H.titleStyle)));
  $('#dslogo').hidden=H.titleStyle!='logo';$('#dslt').textContent=H.logo?'Trocar logo':'Enviar logo';$('#dslx').hidden=!H.logo;
  const sw=$('#dsalt');sw.setAttribute('aria-pressed',String(H.altFont));sw.setAttribute('aria-checked',String(H.altFont));$('#dsfw').hidden=!H.altFont;
  const hc=H.color||(/^#[0-9a-f]{6}$/i.test(A.tx)?A.tx:'#000000'),pc=LK.tx||(/^#[0-9a-f]{6}$/i.test(A.tx)?A.tx:'#000000');fpPaint(hc,pc);
  $$('[data-pl]',LKE.ed).forEach(e=>e.classList.toggle('lk-l',lkRank()<(+e.dataset.pl||1)));
  $('#dsshw').hidden=H.layout!='shape';$('#dscvw').hidden=H.layout!='banner';
  $$('.ds-sc',LKE.ed).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.sh==H.shape)));
  {const C=H.cover,ci=$('#dscim'),cd=$('#dscvd'),vid=C.type=='video'&&C.video,img=!vid&&C.img;
   ci.hidden=!img;if(img){if(ci.getAttribute('src')!==img)ci.src=img}else if(ci.getAttribute('src'))ci.removeAttribute('src');
   cd.hidden=!vid;if(vid){if(cd.getAttribute('src')!==vid){cd.src=vid;const pr=cd.play&&cd.play();if(pr&&pr.catch)pr.catch(()=>{})}}else if(cd.getAttribute('src')){cd.removeAttribute('src');cd.load&&cd.load()}
   $('#dscpv').classList.toggle('has',!!(img||vid));$('#dsmrm').hidden=!(C.img||C.video)}
  {const br=$('#dsbr');br.setAttribute('aria-pressed',String(!!LK.hideBrand));br.setAttribute('aria-checked',String(!!LK.hideBrand))}}
 $$('[data-k]',LKE.ed).forEach(el=>{const v=lkGet(el.dataset.k);
  if(el.classList.contains('lk-seg'))$$('button',el).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.v==v)));
  else if(el.tagName=='SELECT')el.value=v;
  else if(el.type=='color')el.value=v||'#ffffff';
  else if(el.type=='range')el.value=v});
 $$('[data-auto]',LKE.ed).forEach(b=>b.setAttribute('aria-pressed',String(!lkGet(b.dataset.auto))));
 $$('.lk-pn',LKE.ed).forEach(x=>x.hidden=!x.dataset.pn.split(' ').includes(LK.bg.type));
 {const B=LK.bg;
  $$('[data-tg]',LKE.ed).forEach(b=>{const v=String(!!lkGet(b.dataset.tg));b.setAttribute('aria-pressed',v);b.setAttribute('aria-checked',v)});
  $$('.lk-pat',LKE.ed).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.pt==B.pattern)));
  const bi=$('#dsbgim'),bv=$('#dsbgvd');
  bi.hidden=!B.img;if(B.img){if(bi.getAttribute('src')!==B.img)bi.src=B.img}else if(bi.getAttribute('src'))bi.removeAttribute('src');
  bv.hidden=!B.video;if(B.video){if(bv.getAttribute('src')!==B.video){bv.src=B.video;const pr=bv.play&&bv.play();if(pr&&pr.catch)pr.catch(()=>{})}}else if(bv.getAttribute('src')){bv.removeAttribute('src');bv.load&&bv.load()}
  $('#dsbgip').classList.toggle('has',!!B.img);$('#dsbgvp').classList.toggle('has',!!B.video)}
 LKE.ao.textContent=LK.bg.g.angle+'°';
 $$('.lk-gp',LKE.gps).forEach(b=>{const g=LK_GP[b.dataset.gp];b.setAttribute('aria-pressed',String(g[0]==LK.bg.g.c1&&g[1]==LK.bg.g.c2))});
 $$('.ds-tc',LKE.ths).forEach(b=>{b.setAttribute('aria-pressed',String(b.dataset.th=='custom'?!LK.theme:b.dataset.th==LK.theme));b.classList.toggle('ed',(b.dataset.th=='fashion'&&LK.head.layout=='fashion')||(b.dataset.th=='editorial'&&LK.head.layout=='sheet'))});
 {const im=$('#dsth'),ph=S.profile&&S.profile.photo;im.hidden=!ph;if(ph)im.src=ph;$('.ds-t.round svg').style.display=ph?'none':''}
 $('#dsun').disabled=lkBusy||lkHi<=0;$('#dsre').disabled=lkBusy||lkHi>=lkH.length-1;LKE.sv2.hidden=!lkIsDirty();LKE.sv2.disabled=lkBusy;
 LKE.st.textContent=lkIsDirty()?'Alterações não salvas':'Prévia ao vivo';LKE.st.classList.toggle('on',lkIsDirty());
 LKE.sv.disabled=!lkIsDirty()||lkBusy;LKE.rs.disabled=lkBusy;fxSync();if(bsOn)bsDraw()}
function lkTheme(id){const t=LK_THEMES.find(x=>x.id==id);if(!t)return;
 const hd=t.head?{...LK.head,...t.head}:(LK.head.layout=='fashion'||LK.head.layout=='sheet')?{...LK.head,layout:'classic'}:LK.head;
 LK=cleanLook({...lkClone(t.look),theme:t.id,photo:LK.photo,head:hd,social:LK.social,hideBrand:LK.hideBrand},S.profile);
 if(t.id=='fashion'&&LKP.photo){lkFill();fxAuto();return}
 lkCommit();lkFill()}
function lkSet(path,val,co){lkPut(path,val);if(LK.head.layout!='fashion'&&LK.head.layout!='sheet')LK.theme='';lkCommit(co);lkFill()}
LKE.ed.addEventListener('click',e=>{if(lkBusy)return;if(e.target.closest('.ds-pen2')){if(LK.head.layout=='fashion'){fxOpen();return}if(LK.head.layout=='sheet'){bsOpen();return}}
 const b=e.target.closest('button');if(!b)return;
 if(b.dataset.th=='custom'){if(LK.theme){LK.theme='';lkCommit();lkFill()}return}
 if(b.dataset.th){lkTheme(b.dataset.th);return}
 if(b.dataset.gp){const g=LK_GP[b.dataset.gp];LK.bg.g.c1=g[0];LK.bg.g.c2=g[1];LK.theme='';lkCommit();lkFill();return}
 if(b.dataset.pt){if(b.dataset.pt!=LK.bg.pattern)lkSet('bg.pattern',b.dataset.pt);return}
 if(b.dataset.tg){lkSet(b.dataset.tg,!lkGet(b.dataset.tg));return}
 if(b.dataset.auto){lkSet(b.dataset.auto,'');return}
 const seg=b.closest('.lk-seg');if(seg&&lkGet(seg.dataset.k)!==b.dataset.v)lkSet(seg.dataset.k,b.dataset.v)});
LKE.ed.addEventListener('input',e=>{const el=e.target;if(!el.dataset.k||lkBusy)return;
 lkSet(el.dataset.k,el.type=='range'?+el.value:el.value,true)});
$('#dstcol').addEventListener('input',e=>{if(!lkBusy)lkSet('head.color',e.target.value,true)});
$('#dspcol').addEventListener('input',e=>{if(!lkBusy)lkSet('tx',e.target.value,true)});
$('#dstt').addEventListener('input',e=>{LKP.name=e.target.value;lkCnt();lkFill()});
$('#dsbio').addEventListener('input',e=>{LKP.text=e.target.value;lkCnt();lkFill()});
$('#dslf').onchange=e=>{const f=e.target.files[0];e.target.value='';
 lkImg(f,{max:420},d=>{if(d.length>LK_LOGO_MAX){toast('Essa logo ficou pesada. Use uma imagem mais simples.');return}LK.head.logo=d;LK.head.titleStyle='logo';LK.theme='';lkCommit();lkFill()})};
LKE.rs.onclick=()=>{if(lkBusy||!S.profile)return;LK=lkClone(S.profile.look);lkDirty=false;lkHReset();lkPInit();lkHeadFill();lkMode('opts')};
LKE.ed.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;
 if(b.dataset.open){lkOpen(b.dataset.open);return}
 if(b.dataset.fp){fpOpen(b.dataset.fp);return}
 if(b.dataset.fc){fpChoose(b.dataset.fc);return}
 if(b.dataset.tab){$$('[data-tab]',LKE.ed).forEach(x=>x.setAttribute('aria-selected',String(x==b)));const f=b.dataset.tab=='feat';$$('.ds-tc',LKE.ths).forEach(x=>x.hidden=f&&x.dataset.f!='1');return}
 if(b.dataset.ly){if(b.dataset.ly!=LK.head.layout)lkSet('head.layout',b.dataset.ly);return}
 if(b.dataset.sh){if(b.dataset.sh!=LK.head.shape)lkSet('head.shape',b.dataset.sh);return}
 if(b.dataset.ts){if(LK.head.titleStyle!=b.dataset.ts)lkSet('head.titleStyle',b.dataset.ts);return}
 const id=b.id;if(id=='dsalt')lkSet('head.altFont',!LK.head.altFont);
 else if(id=='dsbr'){LK.hideBrand=!LK.hideBrand;lkCommit();lkFill()}
 else if(id=='dslx'){LK.head.logo='';LK.head.titleStyle='text';LK.theme='';lkCommit();lkFill()}
 else if(id=='dsver')vfOpen();
 else if(id=='dsx'&&FP.on)lkOpen('text');
 else if(id=='dsx'||id=='dsbk2')lkMode('opts');
 else if(id=='dsbk')go('profile');
 else if(id=='dssh')$('#hmsh').click();
 else if(id=='dsun')lkJump(-1);else if(id=='dsre')lkJump(1);
 else if(id=='dsshuf'&&!lkBusy){const l=LK_THEMES.filter(t=>t.id!=LK.theme);lkTheme(l[Math.floor(Math.random()*l.length)].id)}});
const lkSave=async()=>{if(lkBusy||!lkIsDirty())return;
 if(!uid||!cloudOK||!FB){toast('Sem ligação com o servidor. Tente de novo em instantes.');return}
 const id=uid,prev=S.profile,look=cleanLook(LK,prev);
 const vl=lkVip(look);if(vl.length){vipOpen(vl);return}
 const profile={...prev,look,name:LKP.name.trim(),text:LKP.text.trim(),photo:LKP.photo,bg:look.bg.type=='gradient'?look.bg.g.c1:look.bg.color};
 if(JSON.stringify(profile).length>900000){toast('O design ficou pesado demais para salvar. Use uma capa ou um vídeo menor.',5500);return}
 lkBusy=true;[LKE.sv,LKE.sv2].forEach(b=>{b.style.minWidth=b.offsetWidth+'px';b.innerHTML='<span class="spin"></span>'});lkFill();S.profile=profile;
 try{let slow=false;
  await Promise.race([FB.setDoc(FB.doc(FB.db,'users',id),{profile,updatedAt:FB.serverTimestamp()},{merge:true}),new Promise(ok=>setTimeout(()=>{slow=true;ok()},12000))]);
  if(uid==id){publishPage();lkDirty=false;LK=lkClone(look);lkHReset();lkPInit();if(!pfDirty)pfFill();lkMode('opts');if(!slow){playSound('success');vibrate('success')}toast(slow?'Sem ligação: o design será enviado quando a internet voltar.':'Design salvo!',slow?4500:2500,slow?'quiet':undefined)}}
 catch(err){console.error('Firestore:',err);if(uid==id){S.profile=prev;toast('Não foi possível salvar o design. Tente novamente.')}}
 lkBusy=false;[LKE.sv,LKE.sv2].forEach(b=>{b.textContent='Salvar';b.style.minWidth=''});lkFill()};
LKE.sv.onclick=lkSave;LKE.sv2.onclick=lkSave;

/* ===== v44: recorte de imagem, capa, porta VIP e verificação ===== */
const LAYN=Object.fromEntries(LK_LAY.concat([['fashion','Fashion'],['sheet','Editorial']]));
function lkVip(look){const r=lkRank(),H=look.head,L=[];
 if(r<1){if(H.layout!='classic')L.push([(H.layout=='fashion'||H.layout=='sheet'?'Tema ':'Layout ')+LAYN[H.layout],1]);if(H.titleStyle=='logo')L.push(['Logo no lugar do título',1]);if(H.altFont)L.push(['Fonte alternativa do título',1]);if(look.hideBrand)L.push(['Remover logo do Quantum',1]);
  const fu=new Set([look.font.name,look.font.bio,look.font.btn]);if(H.altFont)fu.add(H.font);fu.forEach(f=>{if(LK_FONT_PL[f])L.push(['Fonte '+(LK_FN[f]||f),1])})}
 if(r<2&&H.layout=='banner'&&H.cover.type=='video'&&H.cover.video)L.push(['Vídeo na capa',2]);
 if(r<2){const B=look.bg;if(B.type=='image')L.push(['Imagem de fundo',2]);if(B.type=='video')L.push(['Vídeo de fundo',2]);if(B.type=='gradient'&&B.animate)L.push(['Degradê animado',2])}
 return L}
const vipM=$('#dsvip');
function vipOpen(L){const need=Math.max(...L.map(x=>x[1])),nm=need>=2?'Pro':'Plus';
 $('#dsvipP').textContent=`Para salvar o design com esses recursos você precisa do plano ${nm}. Você também pode descartar as seleções VIP e salvar o restante.`;
 $('#dsvipL').innerHTML=L.map(x=>`<li><span>${esc(x[0])}</span><em>${x[1]>=2?'Pro':'Plus'}</em></li>`).join('');
 $('#dsvipUp').textContent='Fazer upgrade para o '+nm;vipM.dataset.need=need;vipM.hidden=false}
const vipClose=()=>{vipM.hidden=true};
$('#dsvipCl').onclick=vipClose;vipM.onclick=e=>{if(e.target===vipM)vipClose()};
$('#dsvipUp').onclick=()=>{SELP=+vipM.dataset.need>=2?'pro':'plus';vipClose();location.hash='planos'};
$('#dsvipDc').onclick=()=>{const r=lkRank();vipClose();
 if(r<1){LK.head.layout='classic';LK.head.titleStyle='text';LK.head.altFont=false;LK.hideBrand=false;['name','bio','btn'].forEach(k=>{if(LK_FONT_PL[LK.font[k]])LK.font[k]='inter'});if(LK_FONT_PL[LK.head.font])LK.head.font='inter'}
 if(r<2&&LK.head.cover.type=='video')LK.head.cover={type:'image',img:'',video:''};
 if(r<2){if(LK.bg.type=='image'||LK.bg.type=='video')LK.bg.type='solid';LK.bg.animate=false}
 lkCommit();lkFill();
 if(JSON.stringify(LK)==lkSaved&&!lkPChanged()){lkDirty=false;lkFill();toast('Seleções VIP descartadas.',2500);return}
 lkSave()};

/* recorte (Enviar media) */
const CP={md:$('#dscp'),st:$('#dscpst'),im:$('#dscpim'),bx:$('#dscpbx'),ok:$('#dscpok'),o:null,ir:null,b:null,d:null,url:'',nw:0,nh:0};
const cpClose=()=>{CP.md.hidden=true;CP.d=null;if(CP.url){URL.revokeObjectURL(CP.url);CP.url=''}CP.im.removeAttribute('src')};
function cpOpen(file,o){if(!file)return;
 if(!/^image\//.test(file.type)||file.size>12e6){toast('Escolha uma imagem de até 12 MB.');return}
 const url=URL.createObjectURL(file),im=new Image();
 im.onerror=()=>{URL.revokeObjectURL(url);toast('Não foi possível abrir essa imagem.')};
 im.onload=()=>{CP.o=o;$('#dscpT').textContent=o.title||'Enviar media';$('#dscpok').textContent=o.ok||'Upload';{const rt=$('#dscprt');rt.hidden=!o.ratios;rt.innerHTML=o.ratios?o.ratios.map((r,i)=>`<button type="button" data-r="${r[0]}" aria-pressed="${r[0]==o.ratio}">${r[1]}</button>`).join(''):''}CP.url=url;CP.nw=im.naturalWidth;CP.nh=im.naturalHeight;CP.im.src=url;CP.md.hidden=false;requestAnimationFrame(cpLayout)};
 im.src=url}
function cpRender(){const b=CP.b,s=CP.bx.style;s.left=b.x+'px';s.top=b.y+'px';s.width=b.w+'px';s.height=b.h+'px'}
function cpLayout(){const W=CP.st.clientWidth,H=CP.st.clientHeight,k=Math.min(W/CP.nw,H/CP.nh),w=CP.nw*k,h=CP.nh*k,r=CP.o.ratio;
 CP.ir={x:(W-w)/2,y:(H-h)/2,w,h};const s=CP.im.style;s.left=CP.ir.x+'px';s.top=CP.ir.y+'px';s.width=w+'px';s.height=h+'px';
 let bw=w,bh=bw/r;if(bh>h){bh=h;bw=bh*r}
 CP.b={x:CP.ir.x+(w-bw)/2,y:CP.ir.y+(h-bh)/2,w:bw,h:bh};cpRender()}
const cpClamp=(v,a,b)=>Math.min(b,Math.max(a,v));
CP.st.addEventListener('pointerdown',e=>{const h=e.target.closest('.cp-h'),inb=e.target.closest('.cp-box');if(!h&&!inb)return;
 e.preventDefault();try{CP.st.setPointerCapture(e.pointerId)}catch(x){}
 CP.d={m:h?h.className.replace('cp-h ',''):'move',x:e.clientX,y:e.clientY,b:{...CP.b}}});
CP.st.addEventListener('pointermove',e=>{const d=CP.d;if(!d)return;const dx=e.clientX-d.x,dy=e.clientY-d.y,r=CP.o.ratio,ir=CP.ir,b0=d.b;
 if(d.m=='move'){CP.b={...b0,x:cpClamp(b0.x+dx,ir.x,ir.x+ir.w-b0.w),y:cpClamp(b0.y+dy,ir.y,ir.y+ir.h-b0.h)}}
 else{const L=d.m[1]=='l',T=d.m[0]=='t',ax=L?b0.x+b0.w:b0.x,ay=T?b0.y+b0.h:b0.y;
  const w1=L?b0.w-dx:b0.w+dx,w2=(T?b0.h-dy:b0.h+dy)*r;let w=Math.abs(w1-b0.w)>=Math.abs(w2-b0.w)?w1:w2;
  const mx=Math.min(L?ax-ir.x:ir.x+ir.w-ax,(T?ay-ir.y:ir.y+ir.h-ay)*r),mn=Math.min(mx,Math.max(48,48*r));
  w=cpClamp(w,mn,mx);const h=w/r;CP.b={x:L?ax-w:ax,y:T?ay-h:ay,w,h}}
 cpRender()});
['pointerup','pointercancel'].forEach(n=>CP.st.addEventListener(n,()=>{CP.d=null}));
$('#dscpok').onclick=async function(){if(!CP.o||!CP.ir)return;const btn=this,o=CP.o,ir=CP.ir,b=CP.b,k=CP.nw/ir.w,cw=Math.min(o.w,Math.round(b.w*k)),ch=Math.round(cw/o.ratio),c=document.createElement('canvas');
 c.width=cw;c.height=ch;const x=c.getContext('2d');if(o.mime=='image/jpeg'){x.fillStyle='#fff';x.fillRect(0,0,cw,ch)}
 x.imageSmoothingQuality='high';x.drawImage(CP.im,(b.x-ir.x)*k,(b.y-ir.y)*k,b.w*k,b.h*k,0,0,cw,ch);
 const cb=o.cb;
 if(o.cld===false){/* usos pequenos (capas de música, foto de grupo) continuam em data: */
  const d=qEnc(c,o.mime,o.q,o.max);
  if(o.max&&d.length>o.max){toast('Essa imagem ficou pesada. Escolha outra ou recorte uma área menor.',4500);return}
  cpClose();cb(d);return}
 /* v91: foto de perfil / capa / fundo → Cloudinary, salva só a URL */
 try{const u=await withSpin(btn,()=>cldCanvas(c,o.mime,o.q),300);if(!u)return;cpClose();cb(u)}
 catch(er){toast((er&&er.message)||'Não foi possível enviar a imagem. Tente de novo.',4500)}};
$('#dscpx').onclick=cpClose;
$('#dscprt').onclick=e=>{const b=e.target.closest('button[data-r]');if(!b||!CP.o)return;CP.o.ratio=+b.dataset.r;$$('#dscprt button').forEach(x=>x.setAttribute('aria-pressed',x==b));cpLayout()};
document.body.appendChild(CP.md);
$('#dscpbk').onclick=()=>{const a=CP.o&&CP.o.again;cpClose();if(a)a()};
CP.md.onclick=e=>{if(e.target===CP.md)cpClose()};

/* imagem de perfil */
$('#dspbtn').onclick=()=>$('#dsfile').click();
$('#dsfile').onchange=e=>{const f=e.target.files[0];e.target.value='';
 cpOpen(f,{ratio:1,w:1080,mime:'image/jpeg',q:.92,max:LK_PHOTO_MAX,again:()=>$('#dsfile').click(),cb:d=>{LKP.photo=d;lkFill();if(LK.head.layout=='fashion')fxAuto()}})};

/* capa: escolher Vídeo ou Fotos */
const mdM=$('#dsmd'),mdClose=()=>{mdM.hidden=true};
$('#dscbtn').onclick=()=>{lkFill();mdM.hidden=false};
mdM.onclick=e=>{if(e.target===mdM||e.target.closest('[data-mdx]'))mdClose()};
$('#dsmfoto').onclick=()=>{mdClose();$('#dscfile').click()};
$('#dsmvid').onclick=()=>{mdClose();$('#dsvfile').click()};
$('#dsmrm').onclick=()=>{mdClose();LK.head.cover={type:'image',img:'',video:''};LK.theme='';lkCommit();lkFill()};
$('#dscfile').onchange=e=>{const f=e.target.files[0];e.target.value='';
 cpOpen(f,{ratio:9/4,w:1440,mime:'image/webp',q:.9,max:LK_COVER_MAX,again:()=>$('#dscfile').click(),cb:d=>{LK.head.cover={type:'image',img:d,video:''};LK.theme='';lkCommit();lkFill()}})};
$('#dsvfile').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;
 if(!/^video\/(mp4|webm)$/.test(f.type)){toast('Use um vídeo MP4 ou WebM.',3500);return}
 if(f.size>CLD.maxVid){toast('Esse vídeo passa de 100 MB.',5000);return}
 cldBusy(true,'Enviando vídeo…');
 uploadToCloudinary(f).then(u=>{LK.head.cover={type:'video',img:'',video:u};LK.theme='';lkCommit();lkFill()})
  .catch(er=>toast((er&&er.message)||'Não foi possível enviar o vídeo.',4500)).finally(()=>cldBusy(false))};

/* fundo: imagem e vídeo (mesmo recortador e mesmos limites da capa). A cor média vira a cor-base: texto legível + carregamento sem flash */
const lkAvgOf=el=>{try{const c=document.createElement('canvas');c.width=c.height=8;const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(el,0,0,8,8);const d=x.getImageData(0,0,8,8).data;let r=0,g=0,b=0;
 for(let i=0;i<d.length;i+=4){r+=d[i];g+=d[i+1];b+=d[i+2]}const n=d.length/4;return '#'+[r,g,b].map(v=>Math.round(v/n).toString(16).padStart(2,'0')).join('')}catch(e){return ''}};
function lkBgTint(src,vid,ok){const el=document.createElement(vid?'video':'img');let done=false;
 const fin=h=>{if(done)return;done=true;if(vid){el.pause();el.removeAttribute('src')}ok(/^#[0-9a-f]{6}$/i.test(h)?h:'')};
 if(vid){el.muted=true;el.preload='auto';el.onloadeddata=()=>{try{el.currentTime=Math.min(.1,(el.duration||.2)/2)}catch(e){fin('')}};el.onseeked=()=>fin(lkAvgOf(el));el.onerror=()=>fin('');setTimeout(()=>fin(''),4000)}
 else{el.onload=()=>fin(lkAvgOf(el));el.onerror=()=>fin('')}
 if(/^https?:/i.test(src))el.crossOrigin='anonymous';el.src=src}
$('#dsbgib').onclick=()=>$('#dsbgf').click();
$('#dsbgf').onchange=e=>{const f=e.target.files[0];e.target.value='';
 cpOpen(f,{ratio:9/16,w:1080,mime:'image/webp',q:.88,max:LK_IMG_MAX,again:()=>$('#dsbgf').click(),cb:d=>{
  LK.bg.img=d;LK.bg.type='image';LK.theme='';lkCommit();lkFill();
  lkBgTint(d,false,h=>{if(h&&LK.bg.img==d){LK.bg.color=h;lkCommit(true);lkFill()}})}})};
$('#dsbgvb').onclick=()=>$('#dsbgvf').click();
$('#dsbgvf').onchange=e=>{const f=e.target.files[0];e.target.value='';if(!f)return;
 if(!/^video\/(mp4|webm)$/.test(f.type)){toast('Use um vídeo MP4 ou WebM.',3500);return}
 if(f.size>CLD.maxVid){toast('Esse vídeo passa de 100 MB.',5000);return}
 cldBusy(true,'Enviando vídeo…');
 uploadToCloudinary(f).then(d=>{LK.bg.video=d;LK.bg.type='video';LK.theme='';lkCommit();lkFill();
  const u=URL.createObjectURL(f);lkBgTint(u,true,h=>{URL.revokeObjectURL(u);if(h&&LK.bg.video==d){LK.bg.color=h;lkCommit(true);lkFill()}})})
  .catch(er=>toast((er&&er.message)||'Não foi possível enviar o vídeo.',4500)).finally(()=>cldBusy(false))};

/* verificação */
const vfM=$('#dsvf');
function vfOpen(){const r=lkRank(),st=S.profile&&S.profile.verify,paid=r>=1,btn=$('#dsvfgo');
 $('#dsvfTx').textContent=paid?'O seu plano já inclui a verificação. Envie a solicitação e vamos analisar o seu perfil.':'Faça upgrade para o Plus para ser verificado e desbloquear vantagens de design, ferramentas de crescimento e limites de uso maiores.';
 $('#dsvfgot').textContent=!paid?`Faça upgrade por ${mt(PRICE.plus)}/mês`:st=='ok'?'Você já é verificado':st=='pending'?'Solicitação enviada':st=='no'?'Recusada, enviar de novo':'Enviar solicitação';
 btn.disabled=paid&&(st=='ok'||st=='pending');$('#dsvfall').hidden=paid;vfM.hidden=false;$('.vf-bd',vfM).scrollTop=0}
const vfClose=()=>{vfM.hidden=true};
$('#dsvfx').onclick=vfClose;
$('#dsvfall').onclick=()=>{vfClose();location.hash='planos'};
$('#dsvfgo').onclick=()=>{if(lkRank()<1){SELP='plus';vfClose();location.hash='planos';return}
 if(!S.profile||S.profile.verify=='ok'||S.profile.verify=='pending')return;S.profile.verify='pending';save();vfClose();toast('Solicitação enviada. Vamos analisar o seu perfil.',4000)};
document.addEventListener('keydown',e=>{if(e.key!='Escape')return;
 if(!vfM.hidden)vfClose();else if(!vipM.hidden)vipClose();else if(!CP.md.hidden)cpClose();else if(!mdM.hidden)mdClose()});

/* abrir direto uma página pública, sem esperar o login */
if(location.hash.startsWith('#/'))route();

/* ===== v54: Estúdio Fashion — modos por aba (imagem / textos / botões / cores), seletor de cor próprio ===== */
var fxOn=false;
const FXE={m:$('#fxs'),st:$('#fxstage'),ct:$('#fxcts'),pal:$('#fxpal'),sel:$('#fxsel'),pad:$('#fxpad'),hint:$('#fxhint')};
const FX={hi:0,photo:'',tab:'img',tg:'name',ct:0,built:false,hide:false};
const FX_PAL=['#ffffff','#f4efe6','#000000','#d4af37','#ffb703','#ff7a00','#ff4d6d','#e11d74','#7c3aed','#1e6bff','#3ccdff','#2ee6a6','#39ff14'];
const FX_CT=[['Nome','head.color','#ffffff'],['Bio','head.bc','#ffffff'],['Botão','btn.color',''],['Texto do botão','btn.text','']];
const FX_HINT={img:'Arraste para mover · pince para dar zoom',txt:'Arraste o texto para mover',btn:'Arraste os botões ou use as setas',col:''};
const FX_OFF={name:['head.nx','head.ny'],bio:['head.bx','head.by'],btn:['head.lx','head.ly']};
const fxP=new Map();let fxG=null;
const fxFont=k=>k=='name'&&LK.head.altFont?LK.head.font:LK.font[k];
const fxTarget=()=>FX.tab=='txt'?FX.tg:FX.tab=='btn'?'btn':null;
function fxPick(k,id){if(k=='name'&&LK.head.altFont)lkSet('head.font',id);else lkSet('font.'+k,id)}
const fxRadEff=()=>LK.btn.rad>=0?LK.btn.rad:{square:4,round:16,pill:32}[LK.btn.shape];
const fxBwEff=()=>LK.btn.bw>=0?LK.btn.bw:(LK.btn.fill=='outline'||LK.btn.shadow=='hard'?2:0);
function fxBuild(){if(FX.built)return;FX.built=true;
 const crown='<i class="ds-cr"><svg class="i"><use href="#cr"/></svg></i>';
 const strip=LK_FONT_ORDER.filter(f=>LK_FF[f]).map(f=>{const pl=LK_FONT_PL[f],ff=`font-family:${LK_FF[f][0]};font-weight:${LK_FF[f][2]}`;
  return `<button type="button" class="fx-fc" data-fc="${f}"${pl?` data-pl="${pl}"`:''} role="option" aria-selected="false" aria-pressed="false">${pl?crown:''}<span class="fx-fs" style="${ff}">Aa</span><small style="${ff};font-weight:400">${LK_FN[f]||f}</small></button>`}).join('');
 $$('.fx-fonts',FXE.m).forEach(x=>x.innerHTML=strip);
 FXE.ct.innerHTML=FX_CT.map((c,i)=>`<button type="button" class="fx-ct" data-ct="${i}" aria-pressed="false"><i class="fx-dot"></i><small>${c[0]}</small></button>`).join('');
 FXE.pal.innerHTML='<button type="button" class="fx-sw au" data-pc="" aria-label="Automática" title="Automática" aria-pressed="false"><svg class="i" viewBox="0 0 24 24"><circle cx="12" cy="12" r="8"/><path d="M6.5 17.5l11-11"/></svg></button>'
  +'<button type="button" class="fx-sw cu" data-pc="__c" aria-label="Escolher outra cor" aria-pressed="false"></button>'
  +FX_PAL.map(c=>`<button type="button" class="fx-sw" data-pc="${c}" aria-label="Cor ${c}" aria-pressed="false" style="--c:${c}"></button>`).join('');
 LK_FONTS.forEach(f=>{if(lkFonts.has(f)||!LK_FF[f])return;lkFonts.add(f);const a=document.createElement('link');a.rel='stylesheet';a.href='https://fonts.googleapis.com/css2?family='+LK_FF[f][1]+'&display=swap';document.head.append(a)});
 LKE.ph.append($('.fx-grid',FXE.st));
 FXE.m.addEventListener('click',fxClick);
 FXE.m.addEventListener('input',e=>{const el=e.target;if(lkBusy||!el.dataset.fxr)return;const v=+el.value;
  if(el.dataset.fxr=='rad')lkSet('btn.rad',v,true);else lkSet('btn.bw',v,true)});
 /* menu de setas: toque = 4 px; segurar repete */
 let ti=0,tt=0;const stop=()=>{clearTimeout(tt);clearInterval(ti)};
 const step=d=>{if(d=='x'){FX.hide=true;fxSelPos();return}const tg=fxTarget();if(!tg||lkBusy)return;const [kx,ky]=FX_OFF[tg];
  if(d=='0'){LK=LK;lkPut(kx,0);lkPut(ky,0);lkCommit();lkFill();return}
  const dx=d=='l'?-4:d=='r'?4:0,dy=d=='u'?-4:d=='d'?4:0;lkSet(kx,Math.max(-300,Math.min(300,lkGet(kx)+dx)),true);lkSet(ky,Math.max(-400,Math.min(400,lkGet(ky)+dy)),true)};
 FXE.pad.addEventListener('pointerdown',e=>{const b=e.target.closest('button');if(!b)return;e.preventDefault();e.stopPropagation();step(b.dataset.nd);
  if(b.dataset.nd!='0'&&b.dataset.nd!='x'){tt=setTimeout(()=>{ti=setInterval(()=>step(b.dataset.nd),70)},380)}});
 ['pointerup','pointercancel','pointerleave'].forEach(t=>FXE.pad.addEventListener(t,stop));
 window.addEventListener('resize',()=>{if(fxOn)fxSelPos()})}
/* seleção (contorno tracejado) e menu de setas sobre o elemento ativo */
function fxSelEl(){return FX.tab=='txt'?(FX.tg=='bio'?$('.pub-bio',LKE.ph):$('h1',LKE.ph)):FX.tab=='btn'?$('.pub-ls',LKE.ph):null}
function fxBox(e){if(e.classList.contains('pub-ls')){const k=[...e.children].filter(x=>x.getClientRects().length);if(k.length){const q=k.map(x=>x.getBoundingClientRect()),l=Math.min(...q.map(a=>a.left)),t=Math.min(...q.map(a=>a.top)),rr=Math.max(...q.map(a=>a.right)),bb=Math.max(...q.map(a=>a.bottom));return{left:l,top:t,right:rr,bottom:bb,width:rr-l,height:bb-t}}}return e.getBoundingClientRect()}
function fxSelPos(){const e=fxOn&&!FX.hide?fxSelEl():null,s=FXE.sel,pd=FXE.pad;
 if(!e||e.hidden||!e.getClientRects().length){s.hidden=true;pd.hidden=true;return}
 const r=fxBox(e),b=FXE.st.getBoundingClientRect(),pad=6;
 s.hidden=false;pd.hidden=false;s.style.left=(r.left-b.left-pad)+'px';s.style.top=(r.top-b.top-pad)+'px';s.style.width=(r.width+pad*2)+'px';s.style.height=(r.height+pad*2)+'px';
 const pw=pd.offsetWidth||230,ph=pd.offsetHeight||46;let x=r.left-b.left+r.width/2-pw/2,y=r.bottom-b.top+pad+10;
 if(y+ph>b.height-4)y=r.top-b.top-pad-10-ph;if(y<4)y=4;x=Math.max(4,Math.min(b.width-pw-4,x));pd.style.left=x+'px';pd.style.top=y+'px'}
function fxSync(){if(!fxOn)return;
 $('#fxun').disabled=lkBusy||lkHi<=0;$('#fxre').disabled=lkBusy||lkHi>=lkH.length-1;$('#fxok').disabled=lkBusy;$('#fxx').disabled=lkBusy;
 const zr=$('input[data-k="head.fz"]',FXE.m);if(zr&&$('.pub-av img',LKE.ph).naturalWidth){const m=fxMet();zr.min=Math.round(m.smin*100)}
 $$('[data-o]',FXE.m).forEach(o=>{const k=o.dataset.o,v=+lkGet(k);o.textContent=k=='head.fz'?(v/100).toFixed(1)+'×':Math.round(v)+(o.dataset.u||'')});
 $$('[data-fxr]',FXE.m).forEach(r=>{const v=r.dataset.fxr=='rad'?fxRadEff():fxBwEff();r.value=v;const o=$(`[data-fo="${r.dataset.fxr}"]`,FXE.m);if(o)o.textContent=v+(o.dataset.u||'')});
 $$('input[type=range]',FXE.m).forEach(r=>r.style.setProperty('--p',((r.value-r.min)/(r.max-r.min)*100).toFixed(1)+'%'));
 $$('.fx-fonts',FXE.m).forEach(x=>{const cur=fxFont(x.dataset.ft);$$('.fx-fc',x).forEach(b=>{const on=b.dataset.fc==cur;b.setAttribute('aria-pressed',String(on));b.setAttribute('aria-selected',String(on))})});
 FXE.m.style.setProperty('--fxaa',LK_FF[fxFont('name')][0]);
 FX_CT.forEach((c,i)=>{const b=FXE.ct.children[i];if(!b)return;const v=lkGet(c[1]);b.setAttribute('aria-pressed',String(i==FX.ct));b.firstChild.style.setProperty('--c',v||c[2]||'#fff');b.firstChild.classList.toggle('au',!v)});
 const cur=(lkGet(FX_CT[FX.ct][1])||'').toLowerCase();
 $$('.fx-sw[data-pc]',FXE.pal).forEach(b=>{if(b.dataset.pc!='__c')b.setAttribute('aria-pressed',String(b.dataset.pc==cur))});
 const cu=$('.fx-sw.cu',FXE.pal),inP=!cur||FX_PAL.includes(cur);cu.setAttribute('aria-pressed',String(!inP));cu.classList.toggle('has',!inP);cu.style.setProperty('--c',inP?'#fff':cur);
 fxSelPos()}
function fxTg(k){FX.tg=k;FX.hide=false;{const r=$('#fxsz'),o=$('#fxszo'),bio=k=='bio',key=bio?'head.bz':'head.nz';r.min=bio?12:28;r.max=bio?32:72;r.dataset.k=key;o.dataset.o=key;r.setAttribute('aria-label',bio?'Tamanho da bio':'Tamanho do nome');$('#fxszl').textContent=bio?'Tamanho da bio':'Tamanho do nome';r.value=lkGet(key);fxSync()}$$('[data-ftg]',FXE.m).forEach(x=>x.setAttribute('aria-pressed',String(x.dataset.ftg==k)));$$('.fx-fonts[data-ft="name"],.fx-fonts[data-ft="bio"]',FXE.m).forEach(x=>x.hidden=x.dataset.ft!=k);fxScroll();fxSelPos()}
function fxTab(t){FX.tab=t;$$('[data-ftab]',FXE.m).forEach(b=>b.setAttribute('aria-selected',String(b.dataset.ftab==t)));$$('.fx-pn',FXE.m).forEach(p=>p.hidden=p.dataset.fp!=t);
 FXE.hint.textContent=FX_HINT[t]||'';FXE.st.classList.toggle('seen',!FX_HINT[t]);if(FX_HINT[t])FXE.st.classList.remove('seen');
 LKE.ph.style.cursor=t=='col'?'default':'grab';fxScroll();fxSelPos()}
function fxScroll(){requestAnimationFrame(()=>$$('.fx-fonts:not([hidden])',FXE.m).forEach(x=>{const b=$('.fx-fc[aria-pressed="true"]',x);if(b)x.scrollLeft=b.offsetLeft-x.clientWidth/2+b.offsetWidth/2}))}
function fxOpen(){if(!LK||fxOn||lkBusy)return;fxBuild();FX.hide=false;FX.hi=lkHi;FX.photo=LKP.photo;fxOn=true;
 FXE.m.hidden=false;FXE.st.classList.remove('seen');FXE.st.append(LKE.ph);lkMode('studio');fxTab('img');fxTg('name')}
function fxClose(apply){if(!fxOn||lkBusy)return;
 if(!apply){lkH=lkH.slice(0,FX.hi+1);lkHi=FX.hi;LK=JSON.parse(lkH[lkHi]);lkDirty=lkH[lkHi]!==lkSaved;LKP.photo=FX.photo}
 fxOn=false;fxP.clear();fxG=null;FXE.m.hidden=true;FXE.sel.hidden=true;FXE.pad.hidden=true;LKE.ph.classList.remove('fx-drag');LKE.ph.style.cursor='';$('.ds-pv',LKE.ed).append(LKE.ph);lkMode('opts')}
function fxClick(e){const b=e.target.closest('button');if(!b||lkBusy)return;
 if(b.dataset.ftab){fxTab(b.dataset.ftab);return}
 if(b.dataset.ftg){fxTg(b.dataset.ftg);return}
 if(b.dataset.fc){fxPick(b.closest('.fx-fonts').dataset.ft,b.dataset.fc);return}
 if(b.dataset.ct){FX.ct=+b.dataset.ct;fxSync();return}
 if(b.closest('[data-k="btn.shape"]')&&LK.btn.rad>=0)LK.btn.rad=-1;
 if(b.dataset.pc!==undefined&&b.closest('#fxpal')){const path=FX_CT[FX.ct][1];
  if(b.dataset.pc=='__c'){const was=lkGet(path)||'';pkOpen(was||FX_CT[FX.ct][2]||'#ffffff',['Cor do nome','Cor da bio','Cor do botão','Cor do texto do botão'][FX.ct],h=>lkSet(path,h,true),()=>lkSet(path,was));return}
  lkSet(path,b.dataset.pc);return}
 switch(b.id){case'fxx':fxClose(false);break;case'fxok':fxClose(true);break;case'fxun':lkJump(-1);break;case'fxre':lkJump(1);break;
  case'fxph':$('#dsfile').click();break;
  case'fxcen':fxAuto();break;
  case'fxrs':Object.assign(LK.head,{fz:100,fx:50,fy:0});LKE.ph.classList.add('fx-anim');setTimeout(()=>LKE.ph.classList.remove('fx-anim'),1000);lkCommit();lkFill();break}}
window.addEventListener('hashchange',()=>{if(fxOn)fxClose(true)});

/* --- gestos conforme a aba: Imagem = mover/zoom da foto · Textos = mover o texto · Botões = mover os botões · Cores = nada --- */
function fxMet(){const av=$('.pub-av',LKE.ph),im=$('img',av),r=av.getBoundingClientRect(),nw=im.naturalWidth||1,nh=im.naturalHeight||1,W=r.width||1,H=r.height||1,c=Math.max(W/nw,.62*H/nh),w=nw*c;return{r,W,H,w,h:nh*c,smin:Math.max(.5,W/w)}}
function fxG0(){const pts=[...fxP.values()];if(!pts.length){fxG=null;return}
 const m=fxMet(),cx=pts.reduce((a,p)=>a+p.x,0)/pts.length,cy=pts.reduce((a,p)=>a+p.y,0)/pts.length,H=LK.head,s=H.fz/100,fx=H.fx/100,fy=H.fy/100;
 fxG={m,s,d:pts.length>1?Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y):0,uc:((cx-m.r.left)-fx*(m.W-s*m.w))/s,vc:((cy-m.r.top)-fy*(m.H-s*m.h))/s,moved:fxG?fxG.moved:false}}
function fxG1(cx,cy,k){const g=fxG,m=g.m,s=Math.min(3,Math.max(m.smin,g.s*k)),
 ax=(c,u,len,sz)=>{const rg=s*sz-len;return Math.abs(rg)<1?.5:Math.min(1,Math.max(0,(s*u-c)/rg))},
 fx=ax(cx-m.r.left,g.uc,m.W,m.w),fy=ax(cy-m.r.top,g.vc,m.H,m.h),H=LK.head;
 H.fz=Math.round(s*1000)/10;H.fx=Math.round(fx*1000)/10;H.fy=Math.round(fy*1000)/10;
 const st=LKE.ph.style;st.setProperty('--lk-fz',(H.fz/100).toFixed(3));st.setProperty('--lk-fxn',(H.fx/100).toFixed(4));st.setProperty('--lk-fyn',(H.fy/100).toFixed(4))}
const fxCen=()=>{const p=[...fxP.values()];return[p.reduce((a,q)=>a+q.x,0)/p.length,p.reduce((a,q)=>a+q.y,0)/p.length]};
/* arrastar texto/botões: deslocamento em unidades lógicas (a prévia tem 360 de largura) */
let fxD=null;
function fxHit(x,y){const pad=26,hit=el=>{if(!el||el.hidden)return false;const r=fxBox(el);return x>=r.left-pad&&x<=r.right+pad&&y>=r.top-pad&&y<=r.bottom+pad};
 if(FX.tab=='txt'){const nm=hit($('h1',LKE.ph)),bi=hit($('.pub-bio',LKE.ph));if(nm&&!bi)return'name';if(bi&&!nm)return'bio';if(nm&&bi){const a=$('h1',LKE.ph).getBoundingClientRect(),b=$('.pub-bio',LKE.ph).getBoundingClientRect();return Math.abs(y-(a.top+a.bottom)/2)<=Math.abs(y-(b.top+b.bottom)/2)?'name':'bio'}}
 if(FX.tab=='btn'&&hit($('.pub-ls',LKE.ph)))return'btn';return null}
LKE.ph.addEventListener('pointerdown',e=>{if(!fxOn||lkBusy||FX.tab=='col')return;e.preventDefault();try{LKE.ph.setPointerCapture(e.pointerId)}catch(_){}
 FXE.st.classList.add('seen');
 if(FX.tab=='img'){fxP.set(e.pointerId,{x:e.clientX,y:e.clientY});fxG0();LKE.ph.classList.add('fx-drag');return}
 if(FX.tab=='txt'||FX.tab=='btn'){const h=fxHit(e.clientX,e.clientY);if(h){const was=FX.hide;if(h!=FX.tg&&FX.tab=='txt')fxTg(h);FX.hide=false;if(was)fxSelPos()}else if(FX.hide)return}
 const tg=fxTarget(),[kx,ky]=FX_OFF[tg];fxD={id:e.pointerId,x:e.clientX,y:e.clientY,ox:lkGet(kx),oy:lkGet(ky),kx,ky,k:LKE.ph.getBoundingClientRect().width/360,moved:false};LKE.ph.classList.add('fx-drag')});
LKE.ph.addEventListener('pointermove',e=>{if(!fxOn)return;
 if(fxD&&e.pointerId==fxD.id){const d=fxD,nx=Math.max(-300,Math.min(300,Math.round(d.ox+(e.clientX-d.x)/d.k))),ny=Math.max(-400,Math.min(400,Math.round(d.oy+(e.clientY-d.y)/d.k)));d.moved=true;
  lkPut(d.kx,nx);lkPut(d.ky,ny);LKE.ph.style.setProperty('--lk-'+d.kx.split('.')[1],nx);LKE.ph.style.setProperty('--lk-'+d.ky.split('.')[1],ny);fxSelPos();return}
 if(!fxG||!fxP.has(e.pointerId))return;fxP.set(e.pointerId,{x:e.clientX,y:e.clientY});
 const p=[...fxP.values()],d=p.length>1?Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y):0,[cx,cy]=fxCen();fxG.moved=true;fxG1(cx,cy,fxG.d>0&&d>0?d/fxG.d:1)});
const fxUp=e=>{if(fxD&&e.pointerId==fxD.id){const mv=fxD.moved;fxD=null;LKE.ph.classList.remove('fx-drag');if(mv&&fxOn){lkCommit();lkFill()}return}
 if(!fxP.has(e.pointerId))return;fxP.delete(e.pointerId);if(fxP.size){fxG0();return}
 const mv=fxG&&fxG.moved;fxG=null;LKE.ph.classList.remove('fx-drag');if(mv&&fxOn){lkCommit();lkFill()}};
LKE.ph.addEventListener('pointerup',fxUp);LKE.ph.addEventListener('pointercancel',fxUp);
LKE.ph.addEventListener('wheel',e=>{if(!fxOn||lkBusy||FX.tab!='img')return;e.preventDefault();fxP.clear();fxP.set(-1,{x:e.clientX,y:e.clientY});fxG0();fxG1(e.clientX,e.clientY,Math.exp(-e.deltaY*.0015));fxP.clear();fxG=null;FXE.st.classList.add('seen');lkCommit(true);lkFill()},{passive:false});

/* --- processar e centralizar: detecta o rosto (FaceDetector quando existe; senão tom de pele/contraste) --- */
const fxImg=src=>new Promise((ok,no)=>{const im=new Image();if(/^https?:/i.test(src))im.crossOrigin='anonymous';im.onload=()=>ok(im);im.onerror=no;im.src=src});
const fxWait=ms=>new Promise(r=>setTimeout(r,ms));
async function fxAnalyze(src){const im=await fxImg(src),nw=im.naturalWidth,nh=im.naturalHeight,k=Math.min(1,192/Math.max(nw,nh)),cw=Math.max(8,Math.round(nw*k)),ch=Math.max(8,Math.round(nh*k)),c=document.createElement('canvas');
 c.width=cw;c.height=ch;const x=c.getContext('2d',{willReadFrequently:true});x.drawImage(im,0,0,cw,ch);const nat={w:nw,h:nh};
 if(window.FaceDetector){try{const fd=new FaceDetector({fastMode:true,maxDetectedFaces:4}),fs=await Promise.race([fd.detect(c),new Promise((_,no)=>setTimeout(no,1200))]);
  if(fs&&fs.length){const b=fs.map(f=>f.boundingBox).sort((a,b)=>b.width*b.height-a.width*a.height)[0];return{nat,F:{cx:(b.x+b.width/2)/cw,cy:(b.y+b.height/2)/ch,fh:b.height/ch}}}}catch(e){}}
 const d=x.getImageData(0,0,cw,ch).data;let sw=0,sx=0,sy=0,syy=0,n=0;
 for(let j=0;j<ch;j++)for(let i=0;i<cw;i++){const o=(j*cw+i)*4,r=d[o],g=d[o+1],b=d[o+2],Y=.299*r+.587*g+.114*b,cb=128-.168736*r-.331264*g+.5*b,cr=128+.5*r-.418688*g-.081312*b;
  if(Y>35&&cb>77&&cb<127&&cr>133&&cr<173){const u=i/cw-.5,v=j/ch-.45,w=Math.exp(-(u*u+v*v)/.18);sw+=w;sx+=w*i/cw;sy+=w*j/ch;syy+=w*(j/ch)*(j/ch);n++}}
 if(n/(cw*ch)>.03&&sw>0){const cx=sx/sw,cy=sy/sw,fh=Math.min(.75,Math.max(.14,Math.sqrt(Math.max(1e-5,syy/sw-cy*cy))*3.2));return{nat,F:{cx,cy:cy-fh*.1,fh}}}
 const L=(i,j)=>{const o=(j*cw+i)*4;return .299*d[o]+.587*d[o+1]+.114*d[o+2]};let gw=0,gx=0,gy=0;
 for(let j=1;j<ch-1;j++)for(let i=1;i<cw-1;i++){const g=Math.abs(L(i+1,j)-L(i-1,j))+Math.abs(L(i,j+1)-L(i,j-1)),u=i/cw-.5,v=j/ch-.45,w=g*Math.exp(-(u*u+v*v)/.12);gw+=w;gx+=w*i/cw;gy+=w*j/ch}
 return{nat,F:gw>0?{cx:gx/gw,cy:gy/gw,fh:.35}:null}}
/* enquadramento: rosto menor (a pessoa vê a foto quase inteira), um pouco acima do meio; se a foto não preenche a altura,
   fica encostada no topo e o resto some num degradê escuro */
function fxFit(F,nat){const W=360,H=640;if(!nat)return{fz:100,fx:50,fy:0};
 const c=Math.max(W/nat.w,.62*H/nat.h),w=nat.w*c,h=nat.h*c,smin=Math.max(.5,W/w),R=v=>Math.round(v*1000)/10;
 if(!F)return{fz:R(smin),fx:50,fy:0};/* rosto menor = foto mais livre */
 const ax=(len,sz,s,pos,t)=>{const u=pos*sz,rg=s*sz-len;if(rg<1)return{f:0,e:0};const f=Math.min(1,Math.max(0,(s*u-t*len)/rg));return{f,e:Math.abs(s*u+f*(len-s*sz)-t*len)/len}};
 const s0=Math.min(2.4,Math.max(smin,.24*H/(F.fh*h)));let best=null;
 for(let s=s0;s<=Math.min(3,s0+.7);s+=.05){const a=ax(W,w,s,F.cx,.5),b=ax(H,h,s,F.cy,.36),e=a.e+b.e+(s-s0)*.05;if(!best||e<best.e)best={s,fx:a.f,fy:b.f,e};if(a.e<.02&&b.e<.02){best={s,fx:a.f,fy:b.f,e};break}}
 return{fz:R(best.s),fx:R(best.fx),fy:R(best.fy)}}
function fxProcEl(){let el=$('#fxproc');if(el)return el;el=document.createElement('div');el.id='fxproc';el.className='fx-proc';el.hidden=true;el.setAttribute('role','status');el.setAttribute('aria-live','polite');
 el.innerHTML='<div class="fx-orb"><i></i><i></i><svg class="i" viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/></svg></div><b></b><span class="fx-bar"><i></i></span>';LKE.ph.append(el);return el}
const FX_MSG=['Analisando a foto…','Encontrando o rosto…','Centralizando a imagem…','Aplicando o estilo…'];
async function fxAuto(){if(fxAuto.run)return;if(!LKP.photo){toast('Adicione uma foto de perfil para centralizar.');return}
 fxAuto.run=1;const was=lkBusy,el=fxProcEl(),t=$('b',el),bar=$('.fx-bar i',el),MIN=1800;lkBusy=true;lkFill();
 let i=0;const tick=()=>{t.textContent=FX_MSG[Math.min(i,3)];bar.style.width=Math.min(94,(i+1)*24)+'%';i++};tick();el.hidden=false;void el.offsetWidth;el.classList.add('on');
 const iv=setInterval(()=>{if(i<4)tick()},MIN/4),t0=performance.now();let r={};
 try{try{r=await fxAnalyze(LKP.photo)}catch(e){r={}}
  const rest=MIN-(performance.now()-t0);if(rest>0)await fxWait(rest);bar.style.width='100%';t.textContent='Pronto';await fxWait(280);
  Object.assign(LK.head,fxFit(r.F,r.nat));LKE.ph.classList.add('fx-anim');lkBusy=was;lkCommit()}
 finally{clearInterval(iv);lkBusy=was;lkFill();el.classList.remove('on');
  setTimeout(()=>{el.hidden=true},480);setTimeout(()=>LKE.ph.classList.remove('fx-anim'),1000);fxAuto.run=0}}

/* ===== seletor de cor próprio (substitui o diálogo nativo do Android em TODO o editor) ===== */
const PK={el:$('#pk'),sv:$('#pksv'),sh:$('#pkhue'),h:0,s:0,v:1,cb:null,undo:null,init:''};
const pkHex=(h,s,v)=>{const f=n=>{const k=(n+h/60)%6;return v-v*s*Math.max(0,Math.min(k,4-k,1))};return'#'+[f(5),f(3),f(1)].map(x=>Math.round(x*255).toString(16).padStart(2,'0')).join('')};
function pkHsv(hex){const r=parseInt(hex.slice(1,3),16)/255,g=parseInt(hex.slice(3,5),16)/255,b=parseInt(hex.slice(5,7),16)/255,mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;
 if(d){h=mx==r?((g-b)/d)%6:mx==g?(b-r)/d+2:(r-g)/d+4;h*=60;if(h<0)h+=360}return{h,s:mx?d/mx:0,v:mx}}
function pkUI(fromHex){const hex=pkHex(PK.h,PK.s,PK.v);PK.el.style.setProperty('--pkh',PK.h);
 $('#pksvt').style.cssText=`left:${PK.s*100}%;top:${(1-PK.v)*100}%;--c:${hex}`;$('#pkht').style.left=(PK.h/360*100)+'%';$('#pkprev').style.setProperty('--c',hex);
 if(!fromHex)$('#pkhex').value=hex.slice(1);return hex}
function pkEmit(fromHex){const hex=pkUI(fromHex);if(PK.cb)PK.cb(hex)}
function pkOpen(hex,title,cb,undo){hex=/^#[0-9a-f]{6}$/i.test(hex||'')?hex.toLowerCase():'#ffffff';const c=pkHsv(hex);Object.assign(PK,{h:c.h,s:c.s,v:c.v,cb,undo,init:hex});
 $('#pkt').textContent=title||'Cor';PK.el.hidden=false;pkUI();
 if(!PK.built){PK.built=true;
  const drag=(box,fn)=>{const mv=e=>{const r=box.getBoundingClientRect();fn(Math.min(1,Math.max(0,(e.clientX-r.left)/r.width)),Math.min(1,Math.max(0,(e.clientY-r.top)/r.height)))};
   box.addEventListener('pointerdown',e=>{e.preventDefault();box.setPointerCapture(e.pointerId);mv(e);const up=()=>{box.removeEventListener('pointermove',mv);box.removeEventListener('pointerup',up);box.removeEventListener('pointercancel',up)};box.addEventListener('pointermove',mv);box.addEventListener('pointerup',up);box.addEventListener('pointercancel',up)})};
  drag(PK.sv,(x,y)=>{PK.s=x;PK.v=1-y;pkEmit()});drag(PK.sh,x=>{PK.h=x*359.99;pkEmit()});
  $('#pkhex').addEventListener('input',e=>{let v=e.target.value.replace(/[^0-9a-f]/gi,'').slice(0,6);e.target.value=v;if(v.length==6){const c=pkHsv('#'+v.toLowerCase());Object.assign(PK,c);pkEmit(true)}});
  $('#pkpre').innerHTML=FX_PAL.concat(['#ff3b3b','#ffd23b','#3bff6e','#7a5cff','#8b93a3']).map(c=>`<button type="button" style="--c:${c}" data-c="${c}" aria-label="${c}"></button>`).join('');
  $('#pkpre').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;Object.assign(PK,pkHsv(b.dataset.c));pkEmit()});
  $('#pkok').onclick=()=>{PK.el.hidden=true;PK.cb=PK.undo=null};
  $('#pkcancel').onclick=()=>{PK.el.hidden=true;if(PK.undo)PK.undo();else if(PK.cb)PK.cb(PK.init);PK.cb=PK.undo=null};
  PK.el.addEventListener('click',e=>{if(e.target===PK.el)$('#pkok').click()})}}
/* qualquer <input type="color"> do editor abre o nosso seletor em vez do diálogo nativo */
document.addEventListener('click',e=>{const i=e.target.closest&&e.target.closest('input[type="color"]');if(!i||!i.closest('#lked'))return;e.preventDefault();
 const lab=i.closest('label'),t=(lab&&$('span',lab)&&$('span',lab).textContent)||i.getAttribute('aria-label')||'Cor',was=i.value;
 pkOpen(i.value,t,h=>{i.value=h;i.dispatchEvent(new Event('input',{bubbles:true}))},()=>{i.value=was;i.dispatchEvent(new Event('input',{bubbles:true}))})},true);

/* ===== v57: tema Editorial — gaveta com foto que passa para o canto; editor próprio (Imagem · Etiqueta · Texto · Capas · Perfis) ===== */
var bsOn=false;
const shProfs=p=>{const ls=(p.links||[]).filter(l=>/^https?:\/\//i.test(l.url)&&!l.hide&&!l.arch);return(p.plats||[]).map(obP).filter(Boolean).map(pl=>{const l=ls.find(x=>x.name==pl[1]);return l?{p:pl[0],u:l.url}:null}).filter(Boolean)};
const shUrl=(pl,v)=>{v=v.trim();if(!v)return'';if(/^https?:\/\//i.test(v))return v;return pl[5]?pl[5]+v.replace(/^@/,''):'https://'+v.replace(/^\/+/,'')};
function shT(sh,t){t=Math.max(0,Math.min(1,t));sh._t=t;sh.style.setProperty('--t',t.toFixed(4))}
function shGo(sh,to){if(!sh)return;cancelAnimationFrame(sh._a);const from=sh._t||0,d0=performance.now(),dur=460*Math.max(.35,Math.abs(to-from)),g=sh.querySelector('.sh-gr');
 sh.dataset.o=to?'1':'0';if(g)g.setAttribute('aria-expanded',String(!!to));
 if(matchMedia('(prefers-reduced-motion:reduce)').matches){shT(sh,to);return}
 const f=n=>{const k=Math.min(1,(n-d0)/dur),e=1-Math.pow(1-k,3);shT(sh,from+(to-from)*e);if(k<1)sh._a=requestAnimationFrame(f)};sh._a=requestAnimationFrame(f)}
function shInit(sh){const rng=()=>(sh.clientHeight||600)*.42,ed=()=>!!sh.closest('#bsin');sh._t=0;
 sh.addEventListener('touchstart',e=>{const t=e.touches[0];sh._g={x:t.clientX,y:t.clientY,t0:sh._t,d:'',sc:!!e.target.closest('.sh-sc'),v:0,ly:t.clientY,lt:performance.now(),drag:0};cancelAnimationFrame(sh._a)},{passive:true});
 sh.addEventListener('touchmove',e=>{const g=sh._g;if(!g)return;const t=e.touches[0],dx=t.clientX-g.x,dy=t.clientY-g.y;
  if(!g.d){if(Math.abs(dx)<6&&Math.abs(dy)<6)return;g.d=Math.abs(dx)>Math.abs(dy)?'x':'y'}
  if(g.d=='x')return;const sc=sh.querySelector('.sh-sc');
  if(!g.drag&&g.t0>.99&&g.sc&&(dy<0||sc.scrollTop>1))return;
  g.drag=1;if(e.cancelable)e.preventDefault();const n=performance.now();g.v=(g.ly-t.clientY)/rng()/Math.max(1,n-g.lt);g.ly=t.clientY;g.lt=n;shT(sh,g.t0-dy/rng())},{passive:false});
 const end=()=>{const g=sh._g;sh._g=null;if(!g||!g.drag)return;shGo(sh,Math.abs(g.v)>.0007?(g.v>0?1:0):(sh._t>.5?1:0))};
 sh.addEventListener('touchend',end,{passive:true});sh.addEventListener('touchcancel',end,{passive:true});
 sh.addEventListener('wheel',e=>{if(Math.abs(e.deltaX)>Math.abs(e.deltaY))return;const sc=sh.querySelector('.sh-sc');
  if(sh._t<.5&&e.deltaY>8){e.preventDefault();shGo(sh,1)}else if(sh._t>.5&&e.deltaY<-8&&sc.scrollTop<=0){e.preventDefault();shGo(sh,0)}},{passive:false});
 sh.addEventListener('click',e=>{if(e.target.closest('.sh-gr')){shGo(sh,sh._t>.5?0:1);return}if(!ed()&&sh._t<.5&&e.target.closest('.sh-ph,.sh-sd'))shGo(sh,1)})}
/* escreve a gaveta dentro de uma raiz (.pub-in, .lk-in ou o palco do editor); só existe com o layout "sheet" */
const shIS=H=>{const z=Math.max(1,(+H.fz||100)/100);return`object-position:${H.fx}% ${H.fy}%;transform-origin:${H.fx}% ${H.fy}%;transform:scale(${z})`};
function shPaint(root,p,live){const L=p.look,H=L&&L.head,on=!!H&&H.layout=='sheet';let sh=root.querySelector(':scope>.sh');
 if(!on){if(sh)sh.remove();return}
 const S=H.sh||cleanSh(),ed=root.id=='bsin',nm=(p.name||'').trim()||(ed?'Seu nome':''),ini=esc(nm.replace(/^@/,'').slice(0,1).toUpperCase());
 const ic=SH_IC[S.ic]||SH_IC.star,ft=($('.pub-ft span')||{}).textContent||'';
 let pr=S.profs||shProfs(p);if(!ed)pr=pr.filter(r=>/^https?:\/\//i.test(r.u));
 const key=JSON.stringify([nm,p.text||'',p.photo||'',S,pr,live,ed,H.fx,H.fy,H.fz,p.verify=='ok']);
 if(!sh){sh=document.createElement('div');sh.className='sh';sh.dataset.o='0';root.prepend(sh);shInit(sh)}
 if(sh._k===key)return;sh._k=key;
 const vOk=p.verify=='ok',ph=p.photo?`<img src="${esc(p.photo)}" alt="" style="${shIS(H)}">`:`<span>${ini}</span>`;
 const icons=pr.map(r=>{const pl=obP(r.p);if(!pl)return'';const ok=live&&/^https?:\/\//i.test(r.u);return`<${ok?'a':'span'} class="sh-pi" style="${pl[2]}"${ok?` href="${esc(r.u)}" target="_blank" rel="noopener noreferrer nofollow"`:''} aria-label="${esc(pl[1])}">${obSvg(pl)}</${ok?'a':'span'}>`}).join('');
 const caps=S.songs.map(o=>`<figure><img src="${o.i}" alt="${esc(o.c)}"><figcaption>${esc(o.c)}</figcaption></figure>`).join('');
 sh.innerHTML=`<div class="sh-ph" data-e="ph">${ph}</div><div class="sh-sd"><button type="button" class="sh-gr" aria-expanded="${sh.dataset.o=='1'}" aria-label="Abrir ou fechar o perfil"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 14l6-6 6 6"/></svg></button>`
  +`<span class="sh-av">${p.photo?`<img src="${esc(p.photo)}" alt="" style="${shIS(H)}">`:ini}</span>${vOk?'<span class="sh-vb" aria-hidden="true"><svg viewBox="0 0 24 24"><use href="#vseal"/></svg></span>':''}`
  +`<div class="sh-hd"><div class="sh-nm"><h2 data-e="tx">${esc(nm)}${vOk?'<svg class="sh-vf" viewBox="0 0 24 24" role="img" aria-label="Verificado"><use href="#vseal"/></svg>':''}</h2>${S.chip?`<span class="sh-ch" data-e="ch"><svg viewBox="0 0 24 24" aria-hidden="true">${ic[1]}</svg>${esc(S.chip)}</span>`:(ed?'<span class="sh-ch off" data-e="ch">Etiqueta</span>':'')}</div></div>`
  +`<div class="sh-sc">${p.text||ed?`<p class="sh-bio" data-e="tx">${esc(p.text||(ed?'Escreva o texto da página':''))}</p>`:''}`
  +(S.songs.length||ed?`<section class="sh-sg" data-e="sg"><h3>${esc(S.st)}</h3><div class="sh-rw">${caps||'<figure class="off"><i></i><figcaption>Capas</figcaption></figure>'}</div></section>`:'')
  +(pr.length||ed?`<section class="sh-pf" data-e="pf"><h3>${esc(S.pt)}</h3><div class="sh-ic">${icons||'<span class="sh-pi off"></span>'}</div></section>`:'')
  +`<div class="sh-fo"><small class="pub-ft"><span>${esc(ft)}</span></small></div></div></div>`;
 shT(sh,sh._t||0)}

/* --- editor do tema Editorial (ecrã completo): toque numa parte da prévia ou escolha a aba --- */
const BS={e:'ph',si:-1,sw:-1,hi:0,p:null},bsE=$('#bse');
const bsL=()=>(LK.head.sh.profs||shProfs(S.profile)).map(r=>({...r}));
function bsPut(f,co){f(LK.head.sh);lkCommit(co);lkFill()}
function bsDraw(){const p=S.profile;if(!p||!bsOn)return;const st=$('#bsst');lkApply(st,LK,true);
 shPaint($('#bsin'),{...p,name:LKP.name,text:LKP.text,photo:LKP.photo,look:LK},false);
 $$('[data-e]',st).forEach(n=>n.classList.toggle('bs-sel',n.dataset.e==BS.e));
 $('#bsun').disabled=lkBusy||lkHi<=0;$('#bsre').disabled=lkBusy||lkHi>=lkH.length-1}
function bsPanel(){const s=LK.head.sh,e=BS.e,P=$('#bsp');let h='';bsE.dataset.e=e;
 $$('.bs-tabs button',bsE).forEach(b=>b.setAttribute('aria-selected',String(b.dataset.e==e)));
 if(e=='ph')h=`<p class="bs-d">Esta imagem abre a página e, ao puxar a gaveta, passa para o canto.${LKP.photo?' Arraste para mover e pince para dar zoom.':''}</p>`+(LKP.photo?`<div class="bs-zr"><label class="bs-lb" for="bszm">Zoom</label><input class="bs-zm" id="bszm" type="range" min="100" max="300" step="1" data-i="zm" value="${Math.max(100,Math.round(LK.head.fz||100))}"></div>`:'')+`<div class="bs-ro"><button class="bs-bt" data-a="photo" type="button">${LKP.photo?'Trocar imagem':'Escolher imagem'}</button>${LKP.photo?'<button class="bs-bt sc" data-a="phrs" type="button">Centralizar</button>':''}</div>`;
 if(e=='ch')h=`<label class="bs-lb" for="bsch">Etiqueta</label><input class="bs-in" id="bsch" data-i="chip" maxlength="24" value="${esc(s.chip)}" placeholder="Escreva o que quiser"><span class="bs-lb">Ícone</span><div class="bs-ics">${Object.keys(SH_IC).map(k=>`<button type="button" data-a="ic" data-k="${k}" aria-pressed="${k==s.ic}" aria-label="${SH_IC[k][0]}"><svg viewBox="0 0 24 24">${SH_IC[k][1]}</svg></button>`).join('')}</div>`;
 if(e=='tx')h=`<label class="bs-lb" for="bsnm">Nome</label><input class="bs-in" id="bsnm" data-i="nm" maxlength="30" value="${esc(LKP.name)}"><label class="bs-lb" for="bsbio">Texto da página</label><textarea class="bs-in" id="bsbio" data-i="bio" rows="4" maxlength="160">${esc(LKP.text)}</textarea>`;
 if(e=='sg'){const l=s.songs;h=`<label class="bs-lb" for="bsstt">Título da secção</label><input class="bs-in" id="bsstt" data-i="st" maxlength="24" value="${esc(s.st)}"><span class="bs-lb">Capas (${l.length}/8)</span><div class="bs-gd">${l.map((o,i)=>`<button type="button" class="bs-tl" data-a="song" data-n="${i}" aria-pressed="${i==BS.si}" aria-label="Capa ${i+1}"><img src="${o.i}" alt=""></button>`).join('')}${l.length<8?'<button type="button" class="bs-tl add" data-a="addsong" aria-label="Adicionar capa"><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg></button>':''}</div>`;
  if(l[BS.si])h+=`<label class="bs-lb" for="bscap">Legenda</label><input class="bs-in" id="bscap" data-i="cap" maxlength="24" value="${esc(l[BS.si].c)}"><div class="bs-ro"><button class="bs-bt" data-a="swap" type="button">Trocar imagem</button><button class="bs-bt dg" data-a="delsong" type="button">Remover</button></div>`}
 if(e=='pf'){const l=bsL();h=`<label class="bs-lb" for="bspt">Título da secção</label><input class="bs-in" id="bspt" data-i="pt" maxlength="24" value="${esc(s.pt)}"><span class="bs-lb">Perfis (${l.length}/6)</span>`
  +l.map((r,i)=>{const pl=obP(r.p);return pl?`<div class="bs-pr"><span class="bs-pi" style="${pl[2]}">${obSvg(pl)}</span><input class="bs-in" data-i="pu" data-n="${i}" value="${esc(r.u)}" placeholder="${esc(pl[4])}" inputmode="url" aria-label="${esc(pl[1])}"><button type="button" data-a="delpf" data-n="${i}" aria-label="Remover ${esc(pl[1])}"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>`:''}).join('')
  +(l.length<6?`<select class="bs-in" id="bsadd" aria-label="Adicionar perfil"><option value="">Adicionar perfil</option>${OBP.filter(p=>!l.some(r=>r.p==p[0])).map(p=>`<option value="${p[0]}">${esc(p[1])}</option>`).join('')}</select>`:'')}
 P.innerHTML=h}
function bsSel(e){BS.e=e;BS.si=-1;const sh=$('#bsin .sh');if(sh)shGo(sh,e=='ph'?0:(e=='sg'||e=='pf'||e=='tx')?1:sh._t>.5?1:0);bsDraw();bsPanel()}
function bsOpen(){if(!LK||bsOn||lkBusy)return;LK.head.sh=cleanSh(LK.head.sh);BS.hi=lkHi;BS.p={name:LKP.name,text:LKP.text,photo:LKP.photo};BS.e='ph';BS.si=-1;BS.sw=-1;bsOn=true;bsE.hidden=false;lkMode('studio');bsPanel()}
function bsClose(ap){if(!bsOn||lkBusy)return;
 if(!ap){lkH=lkH.slice(0,BS.hi+1);lkHi=BS.hi;LK=JSON.parse(lkH[lkHi]);lkDirty=lkH[lkHi]!==lkSaved;Object.assign(LKP,BS.p)}
 bsOn=false;bsE.hidden=true;lkHeadFill();lkMode('opts')}
bsE.addEventListener('click',e=>{const b=e.target.closest('button,[data-e]');if(!b||lkBusy)return;
 if(b.closest('.sh-gr'))return;
 if(b.dataset.e&&!b.closest('#bsp')){bsSel(b.dataset.e);return}
 const a=b.dataset.a,n=+b.dataset.n;
 if(b.id=='bsx')bsClose(false);else if(b.id=='bsok')bsClose(true);else if(b.id=='bsun'){lkJump(-1);bsPanel()}else if(b.id=='bsre'){lkJump(1);bsPanel()}
 else if(a=='photo')$('#dsfile').click();
 else if(a=='phrs'){Object.assign(LK.head,{fz:100,fx:50,fy:50});lkCommit();lkFill();bsPanel()}
 else if(a=='ic'){bsPut(s=>s.ic=b.dataset.k);bsPanel()}
 else if(a=='song'){BS.si=n;bsPanel()}
 else if(a=='addsong'){BS.sw=-1;$('#bsfile').click()}
 else if(a=='swap'){BS.sw=BS.si;$('#bsfile').click()}
 else if(a=='delsong'){bsPut(s=>s.songs.splice(BS.si,1));BS.si=-1;bsPanel()}
 else if(a=='delpf'){bsPut(s=>{const l=bsL();l.splice(n,1);s.profs=l});bsPanel()}});
bsE.addEventListener('input',e=>{const t=e.target,k=t.dataset.i;if(!k||lkBusy)return;const v=t.value;
 if(k=='zm'){LK.head.fz=Math.max(100,Math.min(300,+v||100));bsLive();return}
 if(k=='nm'){LKP.name=v;lkFill()}else if(k=='bio'){LKP.text=v;lkFill()}
 else if(k=='chip')bsPut(s=>s.chip=v,true);else if(k=='st')bsPut(s=>s.st=v,true);else if(k=='pt')bsPut(s=>s.pt=v,true);
 else if(k=='cap'&&LK.head.sh.songs[BS.si])bsPut(s=>s.songs[BS.si].c=v,true);
 else if(k=='pu')bsPut(s=>{const l=bsL();if(l[+t.dataset.n]){l[+t.dataset.n].u=v;s.profs=l}},true)});
bsE.addEventListener('change',e=>{const t=e.target;if(lkBusy)return;
 if(t.dataset.i=='zm'){lkCommit();lkFill();return}
 if(t.id=='bsadd'&&t.value){const v=t.value;bsPut(s=>{const l=bsL();l.push({p:v,u:''});s.profs=l});bsPanel();return}
 if(t.dataset.i=='pu'){const n=+t.dataset.n,l=bsL(),r=l[n],pl=r&&obP(r.p);if(!pl)return;const u=shUrl(pl,t.value);t.value=u;r.u=u;bsPut(s=>s.profs=l)}});
$('#bsfile').onchange=e=>{const f=e.target.files[0];e.target.value='';
 cpOpen(f,{cld:false,ratio:1,w:240,mime:'image/jpeg',q:.85,max:SH_SONG_MAX,again:()=>$('#bsfile').click(),cb:d=>{
  bsPut(s=>{if(BS.sw>=0&&s.songs[BS.sw])s.songs[BS.sw].i=d;else if(s.songs.length<8){s.songs.push({i:d,c:''});BS.si=s.songs.length-1}});BS.sw=-1;bsPanel()}})};

/* --- v68: foto do Editorial: arraste para mover · pince (ou use a roda) para dar zoom --- */
const bsIn=$('#bsin'),bsPt=new Map();let bsG=null;
const bsLive=()=>{const H=LK.head,st=shIS(H);$$('#bsin .sh-ph img,#bsin .sh-av img').forEach(i=>{i.style.cssText=st});const z=$('#bszm');if(z&&document.activeElement!==z)z.value=Math.max(100,Math.round(H.fz||100))};
function bsMet(){const ph=$('#bsin .sh-ph'),im=ph&&$('img',ph);if(!im)return null;const r=ph.getBoundingClientRect(),nw=im.naturalWidth||1,nh=im.naturalHeight||1,W=r.width||1,H=r.height||1,c=Math.max(W/nw,H/nh);return{r,W,H,w:nw*c,h:nh*c}}
function bsG0(){const pts=[...bsPt.values()];if(!pts.length){bsG=null;return}const m=bsMet();if(!m){bsG=null;return}
 const cx=pts.reduce((a,p)=>a+p.x,0)/pts.length,cy=pts.reduce((a,p)=>a+p.y,0)/pts.length,H=LK.head,s=Math.max(1,(H.fz||100)/100),fx=H.fx/100,fy=H.fy/100;
 bsG={m,s,d:pts.length>1?Math.hypot(pts[0].x-pts[1].x,pts[0].y-pts[1].y):0,uc:((cx-m.r.left)-fx*(m.W-s*m.w))/s,vc:((cy-m.r.top)-fy*(m.H-s*m.h))/s,moved:bsG?bsG.moved:false}}
function bsG1(cx,cy,k){const g=bsG,m=g.m,s=Math.min(3,Math.max(1,g.s*k)),
 ax=(c,u,len,sz)=>{const rg=s*sz-len;return Math.abs(rg)<1?.5:Math.min(1,Math.max(0,(s*u-c)/rg))},
 H=LK.head;H.fz=Math.round(s*1000)/10;H.fx=Math.round(ax(cx-m.r.left,g.uc,m.W,m.w)*1000)/10;H.fy=Math.round(ax(cy-m.r.top,g.vc,m.H,m.h)*1000)/10;bsLive()}
function bsHit(e){if(!bsOn||lkBusy||BS.e!='ph'||!LKP.photo)return null;const t=e.target,ph=t&&t.closest&&t.closest('.sh-ph');if(!ph||!bsIn.contains(ph))return null;const sh=ph.closest('.sh');return sh&&(sh._t||0)>=.5?null:ph}
/* impede que a gaveta (puxar para abrir) dispute o gesto */
['touchstart','touchmove','touchend','touchcancel'].forEach(n=>bsIn.addEventListener(n,e=>{if(bsHit(e)||bsPt.size)e.stopPropagation()},{capture:true,passive:true}));
bsIn.addEventListener('pointerdown',e=>{if(!bsHit(e)||(e.pointerType=='mouse'&&e.button))return;e.preventDefault();try{bsIn.setPointerCapture(e.pointerId)}catch(_){}
 bsPt.set(e.pointerId,{x:e.clientX,y:e.clientY});bsG0();bsE.classList.add('bs-drag')});
bsIn.addEventListener('pointermove',e=>{if(!bsG||!bsPt.has(e.pointerId))return;bsPt.set(e.pointerId,{x:e.clientX,y:e.clientY});
 const p=[...bsPt.values()],d=p.length>1?Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y):0,cx=p.reduce((a,q)=>a+q.x,0)/p.length,cy=p.reduce((a,q)=>a+q.y,0)/p.length;
 bsG.moved=true;bsG1(cx,cy,bsG.d>0&&d>0?d/bsG.d:1)});
const bsUp=e=>{if(!bsPt.has(e.pointerId))return;bsPt.delete(e.pointerId);if(bsPt.size){bsG0();return}
 const mv=bsG&&bsG.moved;bsG=null;bsE.classList.remove('bs-drag');if(mv&&bsOn){lkCommit();lkFill()}};
bsIn.addEventListener('pointerup',bsUp);bsIn.addEventListener('pointercancel',bsUp);
bsIn.addEventListener('wheel',e=>{if(!bsHit(e))return;e.preventDefault();e.stopPropagation();bsPt.clear();bsPt.set(-1,{x:e.clientX,y:e.clientY});bsG0();if(bsG){bsG1(e.clientX,e.clientY,Math.exp(-e.deltaY*.0015));bsG=null}bsPt.clear();lkCommit(true);lkFill()},{capture:true,passive:false});
window.addEventListener('hashchange',()=>{if(bsOn)bsClose(true)});


/* ===== Público: visitas e cliques (últimos 7 dias) =====
   Firestore: stats/{username}/days/{AAAA-MM-DD} → {v:visitas, k:cliques, s:{origem:n}, l:{link:n}} */
const stDay=o=>new Date(Date.now()-o*864e5).toISOString().slice(0,10),stKey=n=>String(n||'link').replace(/[.~*\/\[\]`]/g,'_').slice(0,40)||'link';
const ST_SRC={explorar:'Explorar',instagram:'Instagram',tiktok:'TikTok',whatsapp:'WhatsApp',facebook:'Facebook',x:'X',youtube:'YouTube',qr:'QR Code',direto:'Direto',outro:'Outros'};
function stSrc(){const q=new URLSearchParams(location.search).get('src');if(q)return q.toLowerCase().replace(/[^a-z]/g,'').slice(0,12)||'direto';
 let h='';try{h=new URL(document.referrer).hostname}catch(e){}
 return!h?'direto':/instagram/.test(h)?'instagram':/tiktok/.test(h)?'tiktok':/wa\.me|whatsapp/.test(h)?'whatsapp':/facebook|fb\./.test(h)?'facebook':/(^|\.)x\.com|twitter|t\.co/.test(h)?'x':/youtube|youtu\.be/.test(h)?'youtube':'outro'}
function stHit(u,f){if(!FB||!u||!FB.increment)return;if(FB.auth.currentUser&&S.profile&&S.profile.username==u)return;/* o dono não conta */
 FB.setDoc(FB.doc(FB.db,'stats',u,'days',stDay(0)),f(FB.increment),{merge:true}).catch(()=>{})}
function stVisit(u){try{if(sessionStorage.getItem('qv:'+u))return;sessionStorage.setItem('qv:'+u,'1')}catch(e){}
 stHit(u,i=>({v:i(1),s:{[stSrc()]:i(1)}}))}
let ST=null,PV=null,stN=7;
async function stLoad(n){const u=S.profile&&S.profile.username;ST=PV=null;if(!u||!FB)return null;
 try{const o=[...Array(2*n).keys()].reverse(),ds=await Promise.all(o.map(k=>FB.getDoc(FB.doc(FB.db,'stats',u,'days',stDay(k)))));
  const a=ds.map((x,i)=>({d:stDay(o[i]),...(x.exists()?x.data():{})}));PV=a.slice(0,n);ST=a.slice(n)}catch(e){console.warn('stats:',e)}
 return ST}
const stTot=(k,a)=>(a||ST).reduce((s,d)=>s+(d[k]||0),0),stMap=(o,a)=>{const r={};(a||ST).forEach(d=>Object.entries(d[o]||{}).forEach(([k,v])=>r[k]=(r[k]||0)+v));return Object.entries(r).sort((a,b)=>b[1]-a[1])};
const stRank=()=>S.u&&PL[S.u.plan]?PL[S.u.plan].r:0;
function hmStat(){if(stRank()<1)return;stLoad(7).then(()=>{const p=$('.hm-stat p');if(!p||!ST)return;const v=stTot('v');p.textContent=v?v+(v==1?' visitante':' visitantes'):'Sem atividade nesse período'})}
function stDemo(n){const a=[...Array(2*n).keys()].map(i=>({d:stDay(2*n-1-i),v:0,k:0,s:{},l:{}}));PV=a.slice(0,n);ST=a.slice(n)}
/* Leis de UX aplicadas: Hick (só 2 períodos) · Fitts (alvos grandes) · Jakob (gráfico de barras e abas conhecidos) · Miller (7 blocos) · Proximidade/região comum (cada tema num cartão)
   · Posição serial e pico-fim (o mais importante no topo, ação no fim) · Von Restorff (melhor dia e 1º item em destaque) · Doherty (esqueleto na hora) · Carga cognitiva/Occam (uma frase-resumo)
   · Gradiente de meta e Zeigarnik (meta de visitas e checklist incompleto) · Tesler (os cálculos ficam com o app) · Semelhança (todas as listas iguais) */
const MS=[10,50,100,500,1000,5000,10000],WD=['domingo','segunda','terça','quarta','quinta','sexta','sábado'];
const stDelta=(a,b)=>{if(!b)return'';const p=Math.round((a-b)/b*100);return`<em class="st-dl ${p>=0?'up':'dn'}">${p>=0?'▲':'▼'} ${Math.abs(p)}% vs. período anterior</em>`};
const stLock=(h,t,s)=>`<div class="st-lk"><div class="st-lkb" aria-hidden="true">${h}</div><div class="st-lkc"><b>${t}</b><span>${s}</span><button class="btn p" data-go="planos" type="button">Fazer upgrade</button></div></div>`;
const stSeg=()=>`<div class="st-seg" role="tablist" aria-label="Período">${[7,30].map(n=>`<button type="button" role="tab" data-n="${n}" aria-selected="${n==stN}">${n} dias</button>`).join('')}</div>`;
function stBody(rk,demo){const n=stN,V=stTot('v'),K=stTot('k'),mx=Math.max(1,...ST.map(d=>d.v||0)),bi=ST.reduce((m,d,i)=>(d.v||0)>(ST[m].v||0)?i:m,0),b=ST[bi],pro=rk>=2;
 let h=''
 +`<p class="st-ins">${V?`Seu melhor dia foi <b>${WD[new Date(b.d).getUTCDay()]}</b>, com <b>${b.v||0}</b> visitas.`:'Ainda sem visitas neste período.'}</p>`
 +`<div class="st-g"><div class="st-c hero"><span>Visitantes</span><b>${V}</b>${stDelta(V,stTot('v',PV))}</div>`
 +(pro?`<div class="st-c"><span>Cliques</span><b>${K}</b>${stDelta(K,stTot('k',PV))}</div><div class="st-c"><span>Taxa de clique</span><b>${V?Math.round(K/V*100):0}%</b></div>`:'')+'</div>'
 +`<h2 class="st-h">Visitantes por dia</h2><div class="st-ch${n>7?' m':''}" role="img" aria-label="Visitantes por dia">${ST.map((d,i)=>`<div class="st-bar${i==bi&&V?' best':''}"><em>${i==bi&&V?d.v:''}</em><i style="height:${Math.max(4,Math.round((d.v||0)/mx*92))}px"></i><small>${n<=7?'DSTQQSS'[new Date(d.d).getUTCDay()]:(i%5==0?d.d.slice(8):'')}</small></div>`).join('')}</div>`;
 const g=MS.find(m=>m>V)||MS[MS.length-1];
 h+=`<div class="st-goal"><div><b>Meta: ${g} visitas</b><span>${V>=g?'Meta batida!':'Faltam '+(g-V)}</span></div><div class="st-pb"><i style="width:${Math.min(100,Math.round(V/g*100))}%"></i></div></div>`;
 const L=pro?stMap('l'):[['Instagram',0],['WhatsApp',0],['Meu site',0]],O=pro?stMap('s'):[['instagram',0],['whatsapp',0],['direto',0]];
 const rows=(a,f)=>{const t=a.reduce((s,x)=>s+x[1],0)||1;return'<ul class="st-ls">'+(a.length?a.slice(0,5).map((x,i)=>`<li class="st-r${i?'':' top'}"><span>${esc(f?f(x[0]):x[0])}</span><b>${x[1]} · ${Math.round(x[1]/t*100)}%</b><i style="width:${Math.round(x[1]/t*100)}%"></i></li>`).join(''):'<li class="st-r"><span>Sem dados ainda</span></li>')+'</ul>'};
 const pb=`<h2 class="st-h">Links mais clicados</h2>${rows(L)}<h2 class="st-h">De onde vêm</h2>${rows(O,k=>ST_SRC[k]||k)}`;
 return h+(pro?pb:stLock(pb,'Cliques por link e origem','Disponível no plano Pro'))}
function stEnd(){const p=S.profile||{},n=(p.links||[]).filter(l=>l.url&&!l.arch).length,it=[['Adicione uma foto',!!p.photo],['Escreva sua bio',!!p.bio],['Tenha 3 links ou mais',n>=3]],ok=it.filter(x=>x[1]).length;
 return(ok<it.length?`<h2 class="st-h">Falta pouco para sua página brilhar</h2><div class="st-ck"><div class="st-pb"><i style="width:${Math.round(ok/it.length*100)}%"></i></div>${it.map(x=>`<button class="st-ci${x[1]?' on':''}" type="button" ${x[1]?'disabled':'data-ck="edit"'}><span aria-hidden="true">${x[1]?'✓':'○'}</span>${x[0]}</button>`).join('')}</div>`:'')
 +'<button class="btn p st-sh" data-ck="share" type="button">Compartilhar minha página</button>'}
let stSeq=0;
async function pubFill(){const el=$('#stb'),rk=stRank(),my=++stSeq;
 el.innerHTML=stSeg()+'<div class="st-sk"><i></i><i></i><i></i></div>';
 let demo=false;if(rk>=1){await stLoad(stN);if(my!=stSeq||cur!='public')return}
 if(rk<1||!ST||(!stTot('v')&&!stTot('k'))){stDemo(stN);demo=true}
 el.innerHTML=stSeg()+(rk<1?stLock(stBody(2,true),'Veja quem visita você','Disponível a partir do plano Plus'):stBody(rk,demo))+stEnd()}
$('#stb').onclick=e=>{const s=e.target.closest('[data-n]');if(s){stN=+s.dataset.n;pubFill();return}const c=e.target.closest('[data-ck]');if(!c)return;if(c.dataset.ck=='edit')go('edit');else $('#hmsh').click()};


/* ===== Perfil em tela cheia: cartão + prévia da página pública =====
   UX: Fitts (alvos de 48px, ação principal larga na base do cartão) · Hick (1 ação principal + 1 secundária) · Jakob (cartão de perfil e seta de voltar conhecidos)
   · Proximidade/região comum (estatísticas juntas numa caixa) · Miller (só 3 números) · Von Restorff (um único botão escuro) · Doherty (entrada em ~300 ms)
   · Pico-fim (o cartão abre forte e termina com "Abrir página") · Postel (aceita perfil incompleto e mostra links de exemplo) */
const pfl=$('#pfull');let pflT=0;
const pflNum=(el,to)=>{if(matchMedia('(prefers-reduced-motion:reduce)').matches||!to){el.textContent=to;return}const t0=performance.now();(function f(t){const k=Math.min(1,(t-t0)/700);el.textContent=Math.round(to*(1-Math.pow(1-k,3)));if(k<1)requestAnimationFrame(f)})(t0)};
function pflOpen(){const p=S.profile;if(!p||!S.u)return;clearTimeout(pflT);const rk=stRank(),u=p.username||'',nm=(p.name||u||S.u.name||'').replace(/^@/,'');
 const links=p.links.filter(l=>l.url&&!l.arch&&!l.hide);
 $('#pflnm').textContent=nm;$('#pflsb').textContent=(p.bio||'').trim().slice(0,160)||(u?'@'+u:'Defina o seu @username');
 $('#pflai').textContent=nm.slice(0,1).toUpperCase();{const im=$('#pflim');im.hidden=!p.photo;if(p.photo)im.src=p.photo;else im.removeAttribute('src')}
 const L0=p.look||{};pflCover();
 $('#pflu').textContent=u?'@'+u:'sem @username';$('#pflpi').setAttribute('href',p.verify=='ok'?'#vseal':'#lk2');$('#pflnm').toggleAttribute('data-vf',p.verify=='ok');
 $('.pfl-on').style.display=u&&cloudOK?'':'none';
 $('#pflv0').textContent='0';$('#pflv1').textContent=rk>=1?'0':'-';$('#pflv2').textContent=plan().n;
 const ph=$('#pfph'),smp=[['Meu site'],['Instagram'],['Fale comigo']].map(x=>({name:x[0],url:'https://quantum.app'})),L=lkEnforce(JSON.parse(JSON.stringify(L0)),rk);
 lkApply(ph,L);lkPaint($('.lk-in',ph),{...p,look:L,links:links.length?links:smp},u||'seunome',false);
 pfl.hidden=false;document.body.style.overflow='hidden';pfl.scrollTop=0;
 requestAnimationFrame(()=>{ph.style.setProperty('--s',(ph.clientWidth/360).toFixed(3));pfl.classList.add('on');$('#pflx').focus({preventScroll:true});pflNum($('#pflv0'),links.length)});
 pflLikes(0);if(FB&&u)FB.getDoc(FB.doc(FB.db,'likes',u)).then(x=>pflLikes(x.exists()?Math.max(0,+x.data().n||0):0)).catch(()=>{});
 if(rk>=1)stLoad(7).then(()=>{if(ST&&!pfl.hidden)pflNum($('#pflv1'),stTot('v'))})}
function pflClose(){pcvClose();pfl.classList.remove('on');document.body.style.overflow='';pflT=setTimeout(()=>{pfl.hidden=true},280)}
$('#pflx').onclick=pflClose;
document.addEventListener('keydown',e=>{if(e.key=='Escape'&&!pfl.hidden){if(!$('#pcv').hidden)pcvClose();else pflClose()}});
$('#pflsh').onclick=()=>$('#hmsh').click();
$('#pflct').onclick=()=>{pflClose();go('edit')};
$('#pflop').onclick=()=>{const u=S.profile&&S.profile.username;if(u)open(pubHost()+'#/'+u,'_blank','noopener');else{pflClose();go('edit');toast('Escolha um @username para ter uma página pública.')}};
document.addEventListener('click',e=>{if(e.target.closest('[data-pfull]')){$('#dd').hidden=true;pflOpen()}});
$('.hm-card').addEventListener('click',e=>{if(!e.target.closest('button'))pflOpen()});


/* ===== Capa do perfil: malha de cores desfocada (8 estilos) ===== */
const PCV=[['sunset','Pôr do sol',['#c9593a','#6e2a1c','#f7c873','#f08a4b','#7fd0ee']],['snow','Neve',['#eef0f3','#ffffff','#dfe3ea','#f7f4ef','#cfd8e6']],['mist','Névoa',['#b8bcc4','#e9ebef','#8e939d','#d4d7de','#a9b4c8']],['graphite','Grafite',['#2a2c31','#0f1013','#5a5f6a','#3b3e46','#6b7890']],
 ['ocean','Oceano',['#2f7fd6','#0f3d8f','#7fe0ff','#3aa6f0','#b6f0ff']],['violet','Lavanda',['#9a6ee0','#3b1f8f','#ffb3e6','#b58cf5','#8fd0ff']],['forest','Floresta',['#2f8f6a','#0f4a38','#c9f0a8','#3fb88a','#8fe0d0']],['rose','Rosé',['#e86f8f','#8f1f4a','#ffd1a8','#f59ab5','#ffe3b8']]];
const pcvBg=c=>`radial-gradient(60% 90% at 8% 18%,${c[1]},transparent 70%),radial-gradient(55% 80% at 88% 22%,${c[2]},transparent 65%),radial-gradient(75% 90% at 55% 78%,${c[3]},transparent 70%),radial-gradient(42% 55% at 6% 100%,${c[4]},transparent 70%),${c[0]}`;
const pcvId=()=>{const i=S.profile&&S.profile.pcv;return PCV.some(x=>x[0]==i)?i:'sunset'};
function pflCover(){const bg=$('#pflbg'),c=PCV.find(x=>x[0]==pcvId())[2];bg.style.background=pcvBg(c);bg.style.animation='none';void bg.offsetWidth;bg.style.animation=''}
function pcvOpen(){const cur=pcvId();$('#pcvgd').innerHTML=PCV.map(x=>`<button class="pcv-sw" type="button" data-c="${x[0]}" aria-pressed="${x[0]==cur}"><span class="pcv-pv pfl-bg" style="background:${pcvBg(x[2])}"><svg class="i pcv-ck" viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></span><small>${x[1]}</small></button>`).join('');
 $('#pcv').hidden=false;requestAnimationFrame(()=>$('#pcv').classList.add('on'))}
function pcvClose(){const e=$('#pcv');if(e.hidden)return;e.classList.remove('on');setTimeout(()=>{e.hidden=true},260)}
$('#pflcv').onclick=pcvOpen;$('#pcvbk').onclick=pcvClose;
$('#pcvgd').onclick=e=>{const b=e.target.closest('.pcv-sw');if(!b||b.getAttribute('aria-pressed')=='true')return;const id=b.dataset.c;
 $$('.pcv-sw',$('#pcvgd')).forEach(x=>x.setAttribute('aria-pressed',x==b));
 if(!pfCommit(q=>{q.pcv=id},'Capa atualizada!'))return;pflCover();const pv=$('.pcv-pv',b);pv.classList.add('ld');pv.insertAdjacentHTML('beforeend','<span class="spin"></span>');
 pfDone.then(()=>{pv.classList.remove('ld');const sp=$('.spin',pv);if(sp)sp.remove();setTimeout(pcvClose,350)})};

/* ===== Curtidas: só aparecem dentro do app (aba Perfil). A página pública não mostra curtidas. ===== */
const lkFmt=n=>n>=1e6?(n/1e6).toFixed(1).replace('.0','')+'M':n>=1e3?(n/1e3).toFixed(1).replace('.0','')+'k':String(n);
function pflLikes(n){const c=$('#pfph .pub-lc'),b=$('#pfph .pub-lk');if(!c||!b)return;c.hidden=false;c.textContent=lkFmt(n);b.classList.toggle('has',n>0);b.setAttribute('aria-label',n==1?'1 curtida na sua página':n+' curtidas na sua página')}


/* ==========================================================
   v69 · EXPLORAR — feed das páginas mais curtidas, busca com sugestões e perfil com curtida
   Firestore:
     dir/{@}            vitrine leve de cada página (nome, miniatura, cores, palavras de busca). Só o dono do @ (ou o admin) escreve.
     likes/{@}.n        contador de curtidas · likes/{@}/by/{uid} marca quem curtiu (1 por pessoa, no mesmo lote).
   O feed junta duas consultas pequenas (top curtidas + páginas recentes); a busca usa array-contains nas palavras do nome/@.
   ========================================================== */
const XP={feed:[],at:0,seq:0,pseq:0,sq:0,sel:-1,res:[],cache:new Map(),L:new Map(),cur:'',busy:'',t:0,pt:0};
const XPS=$('.pf-scr.xp'),xpq=$('#xpq'),xpv=$('#xpv'),xpph=$('#xpph');
const xpNorm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
const xpL=u=>XP.L.get(u)||{},xpSet=(u,o)=>{const x={...xpL(u),...o};XP.L.set(u,x);return x};
const xpOwn=u=>!!(S.profile&&S.profile.username&&S.profile.username==u);
const xpToks=v=>xpNorm(v).replace(/^@/,'').split(/[^a-z0-9_]+/).filter(Boolean).slice(0,4);

/* --- vitrine (dir/{@}): montada a partir do perfil e gravada junto com a página pública --- */
function xpKeys(name,user){const set=new Set(),un=xpNorm(user);
 [...xpNorm(name).split(/[^a-z0-9]+/),...un.split('_'),un].filter(Boolean).forEach(w=>{for(let i=1;i<=Math.min(w.length,12);i++)set.add(w.slice(0,i))});
 return [...set].slice(0,120)}
/* miniatura quadrada 96×96 (~5 KB) da foto de perfil; guarda a última para não recalcular */
let thC={k:'',v:''};
function xpThumb(src){return new Promise(ok=>{if(!src)return ok('');const k=src.length+':'+src.slice(-48);if(thC.k==k)return ok(thC.v);
 const im=new Image();if(/^https?:/i.test(src))im.crossOrigin='anonymous';im.onload=()=>{try{const w=im.naturalWidth,h=im.naturalHeight,m=Math.min(w,h),c=document.createElement('canvas');c.width=c.height=96;
  const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,96,96);x.imageSmoothingQuality='high';x.drawImage(im,(w-m)/2,(h-m)/2,m,m,0,0,96,96);
  const v=c.toDataURL('image/jpeg',.74);thC={k,v:v.length<=16000?v:''};ok(thC.v)}catch(e){ok('')}};
 im.onerror=()=>ok('');im.src=src})}
async function dirBuild(p){const b=(p.look&&p.look.bg)||{},g=b.g||{},sol=lkHex(b.color,'#1e6bff'),
  c1=b.type=='gradient'?lkHex(g.c1,sol):sol,c2=b.type=='gradient'?lkHex(g.c2,sol):lkShade(sol,-32),
  nm=String(p.name||p.username).replace(/^@/,'').trim().slice(0,60)||p.username;
 return {u:p.username,n:nm,t:await xpThumb(p.photo),c1,c2,v:p.verify=='ok'?'ok':'',b:String(p.bio||'').split('\n')[0].slice(0,80),s:xpKeys(nm,p.username)}}
let dirLast='';
async function dirPub(p){try{const d=await dirBuild(p),j=JSON.stringify(d);if(j===dirLast)return;
 await FB.setDoc(FB.doc(FB.db,'dir',p.username),{...d,ts:FB.serverTimestamp()});dirLast=j}
 catch(e){console.warn('dir:',e)}}
/* admin: cria a vitrine das páginas que já existiam antes do Explorar */
$('#adx').onclick=async()=>{if(!window.isAdmin)return;const b=$('#adx'),t0=b.textContent;b.disabled=true;b.textContent='A preencher…';let ok=0,sk=0;
 try{const qs=await FB.getDocs(FB.collection(FB.db,'users'));
  for(const d of qs.docs){const x=d.data(),p=cleanProfile(x.profile);if(x.banned===true||!p.username){sk++;continue}
   try{const pg=await FB.getDoc(FB.doc(FB.db,'pages',p.username));if(!pg.exists()){sk++;continue}
    const dd=await dirBuild(p),up=pg.data().updatedAt;await FB.setDoc(FB.doc(FB.db,'dir',p.username),{...dd,ts:up||FB.serverTimestamp()});ok++}
   catch(e){console.warn('dir:',e);sk++}}
  toast(`Explorar: ${ok} página${ok==1?'':'s'} adicionada${ok==1?'':'s'}`+(sk?`, ${sk} sem página ou banida${sk==1?'':'s'}.`:'.'),5000)}
 catch(e){toast(adErr(e,'Não foi possível preencher o Explorar.'),6000)}
 b.disabled=false;b.textContent=t0};

/* --- leitura --- */
function xpDoc(s){const x=s.data()||{},u=s.id;if(!PUBR.test(u))return null;
 const t=typeof x.t=='string'&&x.t.length<=16000&&/^data:image\/jpeg;base64,[A-Za-z0-9+\/=]+$/.test(x.t)?x.t:'';
 return {u,n:String(x.n||u).slice(0,60),t,c1:lkHex(x.c1,'#1e6bff'),c2:lkHex(x.c2,'#3ccdff'),v:x.v=='ok',b:String(x.b||'').slice(0,80),ts:x.ts&&x.ts.toMillis?x.ts.toMillis():Date.now()}}
const xpIni=d=>esc(String(d.n).replace(/^@/,'').slice(0,1).toUpperCase());
const xpAv=(d,c)=>`<span class="${c}" style="${ncSt(d.u)}">${d.t?`<img src="${d.t}" alt="">`:`<i>${xpIni(d)}</i>`}</span>`;
const xpVf=d=>d.v?'<svg class="i xp-vf" aria-label="Verificado"><use href="#vseal"/></svg>':'';
const xpErr=e=>e&&e.code=='permission-denied'?'Falta publicar as regras do ficheiro firestore.rules no Firebase (coleções dir e likes).':'Verifique a internet e tente de novo.';

async function xpLoad(force){const my=++XP.seq,fd=$('#xpfd'),quiet=XP.feed.length&&!force;
 if(!quiet)fd.innerHTML='<div class="xp-gd">'+'<i class="xp-ski"></i>'.repeat(6)+'</div>';
 try{await fbReady();
  const [lq,dq]=await Promise.all([
   FB.getDocs(FB.query(FB.collection(FB.db,'likes'),FB.where('n','>',0),FB.orderBy('n','desc'),FB.limit(50))),
   FB.getDocs(FB.query(FB.collection(FB.db,'dir'),FB.orderBy('ts','desc'),FB.limit(40)))]);
  if(my!=XP.seq)return;
  const D=new Map(),N=new Map();
  dq.docs.forEach(s=>{const d=xpDoc(s);if(d)D.set(d.u,d)});
  lq.docs.forEach(s=>N.set(s.id,Math.max(0,+s.data().n||0)));
  /* quem tem curtidas mas ficou fora das 40 mais recentes: busca a vitrine dele */
  await Promise.all([...N.keys()].filter(k=>!D.has(k)).map(k=>FB.getDoc(FB.doc(FB.db,'dir',k)).then(s=>{const d=s.exists()&&xpDoc(s);if(d)D.set(k,d)}).catch(()=>{})));
  /* se a lista de curtidas foi cortada em 50, pega a contagem de quem ficou de fora */
  if(lq.size>=50)await Promise.all([...D.keys()].filter(k=>!N.has(k)).map(k=>FB.getDoc(FB.doc(FB.db,'likes',k)).then(s=>N.set(k,s.exists()?Math.max(0,+s.data().n||0):0)).catch(()=>{})));
  if(my!=XP.seq)return;
  XP.feed=[...D.values()];XP.at=Date.now();
  XP.feed.forEach(d=>{const x=xpL(d.u),n=N.get(d.u)||0;xpSet(d.u,{n:XP.busy==d.u&&x.n!=null?x.n:n})});
  xpRender()}
 catch(e){if(my!=XP.seq)return;console.error('explorar:',e);
  if(quiet)return;
  fd.innerHTML=`<div class="xp-em"><svg class="i"><use href="#help"/></svg><b>Não foi possível carregar</b><span>${esc(xpErr(e))}</span><button class="btn" type="button" data-xp="retry">Tentar de novo</button></div>`}}

function xpCard(d,i,rk){const n=xpL(d.u).n||0;
 return `<button class="xp-cd" type="button" data-u="${d.u}" style="--c1:${d.c1};--c2:${d.c2};--i:${i}" aria-label="${esc(d.n)}, @${d.u}${n?', '+n+(n==1?' curtida':' curtidas'):''}"><span class="xp-cv">${rk?`<i class="xp-rk">${rk}</i>`:''}</span>${xpAv(d,'xp-av')}<span class="xp-nm"><b>${esc(d.n)}</b>${xpVf(d)}</span><small class="xp-un">@${d.u}</small><span class="xp-lk${n?' has':''}" data-u="${d.u}"><svg class="i" aria-hidden="true"><use href="#heart"/></svg><em>${lkFmt(n)}</em></span></button>`}
function xpRender(){const fd=$('#xpfd'),n=d=>xpL(d.u).n||0,
 hot=XP.feed.filter(d=>n(d)>0).sort((a,b)=>n(b)-n(a)||b.ts-a.ts),rest=XP.feed.filter(d=>!n(d)).sort((a,b)=>b.ts-a.ts);
 const sec=(t,ic,a,top)=>`<h2 class="xp-h">${ic?`<svg class="i xp-hh"><use href="#heart"/></svg>`:''}${t}</h2><div class="xp-gd">${a.map((d,i)=>xpCard(d,Math.min(i,12),top&&i<3?i+1:0)).join('')}</div>`;
 fd.innerHTML=!XP.feed.length?`<div class="xp-em"><svg class="i"><use href="#users"/></svg><b>Ainda não há páginas por aqui</b><span>Assim que alguém publicar a sua página no Quantum, ela aparece neste feed.</span></div>`
  :(hot.length?sec('Popular',1,hot.slice(0,30),1):'')+(rest.length?sec(hot.length?'Novas páginas':'Páginas no Quantum',0,rest,0):'')}
function xpPaint(){$$('.xp-lk[data-u]').forEach(el=>{const x=xpL(el.dataset.u),n=x.n||0;el.classList.toggle('has',n>0);$('em',el).textContent=lkFmt(n)})}

/* --- entrar/sair da tela --- */
function xpEnter(){xpMode(false);xpq.value='';$('#xpcl').hidden=true;
 if(XP.feed.length){xpRender();if(Date.now()-XP.at>30000)xpLoad()}else xpLoad()}
function xpLeave(){xpMode(false)}
$('#xpbk').onclick=()=>go('profile');
$('#xprf').onclick=e=>{const b=e.currentTarget;b.classList.remove('spin2');void b.offsetWidth;b.classList.add('spin2');XP.cache.clear();xpLoad(true)};
$('#xpfd').onclick=e=>{const c=e.target.closest('.xp-cd');if(c){xpOpen(c.dataset.u);return}if(e.target.closest('[data-xp=retry]'))xpLoad(true)};

/* --- busca: sugestões enquanto digita --- */
function xpMode(on){on=!!on;if((XPS.dataset.m=='s')==on)return;XPS.dataset.m=on?'s':'f';document.body.classList.toggle('xp-s',on);
 $('#xpcn').hidden=!on;$('#xpsg').hidden=!on;xpq.setAttribute('aria-expanded',on);if(on)scrollTo(0,0);else xpq.removeAttribute('aria-activedescendant')}
function xpMatch(d,toks){const w=[...xpNorm(d.n).split(/[^a-z0-9]+/),...d.u.split('_'),d.u];return toks.every(k=>w.some(x=>x.startsWith(k)))}
function xpSort(a,q){const qn=q.join(' '),sc=d=>xpNorm(d.n).startsWith(qn)?0:d.u.startsWith(q[0])?1:2;
 return a.sort((x,y)=>sc(x)-sc(y)||(xpL(y.u).n||0)-(xpL(x.u).n||0)||x.n.localeCompare(y.n))}
function xpHi(t,toks){return String(t).split(/([\p{L}\p{N}_]+)/u).map((w,i)=>{if(i%2==0)return esc(w);const nw=xpNorm(w),k=toks.find(k=>nw.startsWith(k));return k?`<mark>${esc(w.slice(0,k.length))}</mark>${esc(w.slice(k.length))}`:esc(w)}).join('')}
function xpList(r,toks,err){const sg=$('#xpsg');XP.res=r||[];XP.sel=-1;xpq.removeAttribute('aria-activedescendant');
 if(err){sg.innerHTML=`<div class="xp-nr"><b>Não foi possível pesquisar</b><span>${esc(xpErr(err))}</span></div>`;return}
 if(!toks.length){sg.innerHTML='';return}
 sg.innerHTML=XP.res.length?XP.res.map((d,i)=>xpRow(d,i,toks)).join(''):`<div class="xp-nr"><b>Nenhuma página encontrada</b><span>Tente outro nome ou @username.</span></div>`}
const xpRow=(d,i,toks)=>`<button class="xp-sr" type="button" role="option" id="xpo${i}" data-i="${i}" aria-selected="false">${xpAv(d,'xp-sa')}<span class="xp-ss"><b><span class="xp-sn">${xpHi(d.n,toks)}</span>${xpVf(d)}</b><small>@${xpHi(d.u,toks)}</small></span><svg class="i xp-go" aria-hidden="true"><use href="#arr"/></svg></button>`;
function xpPop(){return XP.feed.slice().sort((a,b)=>(xpL(b.u).n||0)-(xpL(a.u).n||0)||b.ts-a.ts).slice(0,6)}
function xpSuggest(){clearTimeout(XP.t);const v=xpq.value,toks=xpToks(v),my=++XP.sq;$('#xpcl').hidden=!v;
 if(!toks.length){xpList([],[]);return}
 const key=toks.join(' '),loc=xpSort(XP.feed.filter(d=>xpMatch(d,toks)),toks);
 if(XP.cache.has(key)){xpList(XP.cache.get(key),toks);return}
 xpList(loc.slice(0,12),toks);/* resposta imediata com o que já está no feed; a rede completa em seguida */
 XP.t=setTimeout(async()=>{try{await fbReady();const tk=toks.reduce((a,b)=>b.length>a.length?b:a).slice(0,12);
  const qs=await FB.getDocs(FB.query(FB.collection(FB.db,'dir'),FB.where('s','array-contains',tk),FB.limit(30)));
  if(my!=XP.sq)return;
  const M=new Map();loc.forEach(d=>M.set(d.u,d));qs.docs.forEach(s=>{const d=xpDoc(s);if(d&&xpMatch(d,toks))M.set(d.u,d)});
  const r=xpSort([...M.values()],toks).slice(0,12);XP.cache.set(key,r);xpList(r,toks)}
  catch(e){if(my!=XP.sq)return;console.warn('busca:',e);if(!loc.length)xpList(null,toks,e)}},150)}
function xpSel(i){const rows=$$('.xp-sr',$('#xpsg'));if(!rows.length)return;XP.sel=(i+rows.length)%rows.length;
 rows.forEach((r,k)=>r.setAttribute('aria-selected',k==XP.sel));xpq.setAttribute('aria-activedescendant','xpo'+XP.sel);rows[XP.sel].scrollIntoView({block:'nearest'})}
function xpPick(i){const d=XP.res[i];if(!d)return;xpq.blur();xpOpen(d.u)}
xpq.addEventListener('focus',()=>{xpMode(true);xpSuggest()});
xpq.addEventListener('input',xpSuggest);
xpq.addEventListener('keydown',e=>{
 if(e.key=='ArrowDown'){e.preventDefault();xpSel(XP.sel+1)}
 else if(e.key=='ArrowUp'){e.preventDefault();xpSel(XP.sel<0?-1:XP.sel-1)}
 else if(e.key=='Enter'){e.preventDefault();if(XP.res.length)xpPick(XP.sel>=0?XP.sel:0);else if(xpToks(xpq.value).length)toast('Nenhuma página encontrada.',2200)}
 else if(e.key=='Escape'){e.preventDefault();$('#xpcn').click()}});
$('#xpsg').addEventListener('click',e=>{const r=e.target.closest('.xp-sr');if(r)xpPick(+r.dataset.i)});
$('#xpsg').addEventListener('mousemove',e=>{const r=e.target.closest('.xp-sr');if(r&&+r.dataset.i!=XP.sel){XP.sel=+r.dataset.i;$$('.xp-sr',$('#xpsg')).forEach((x,k)=>x.setAttribute('aria-selected',k==XP.sel))}});
$('#xpcl').onclick=()=>{xpq.value='';xpq.focus();xpSuggest()};
$('#xpcn').onclick=()=>{xpq.value='';xpq.blur();$('#xpcl').hidden=true;xpMode(false);XP.sq++;clearTimeout(XP.t)};

/* --- perfil de outra pessoa: cartão de perfil (capa · avatar · seguidores · Follow) + prévia da página --- */
const XRK=['Free','Plus','Pro'],XF=new Map(),XFT=['Follow','Following'];
const xfL=u=>XF.get(u)||{},xfSet=(u,o)=>{const x={...xfL(u),...o};XF.set(u,x);return x};
const xpE={bg:$('#xpbg'),nm:$('#xpnm'),sb:$('#xpsb'),ai:$('#xpai'),im:$('#xpim'),v0:$('#xpv0'),v1:$('#xpv1'),v2:$('#xpv2'),fl:$('#xpfl')};
const xpDir=u=>XP.feed.find(d=>d.u==u)||XP.res.find(d=>d.u==u)||null;
/* cartão preenchido na hora com a vitrine (dir); a página completa chega depois (Doherty: resposta < 400 ms) */
function xpHead(u,d){const nm=d?d.n:u,bio=d?String(d.b||'').trim():'';
 xpE.nm.textContent=nm;xpE.nm.toggleAttribute('data-vf',!!(d&&d.v));xpE.sb.textContent=bio;xpE.sb.hidden=!bio;
 xpE.ai.textContent=nm.slice(0,1).toUpperCase();xpE.ai.parentElement.setAttribute('style',ncSt(u));xpE.im.hidden=!(d&&d.t);if(d&&d.t)xpE.im.src=d.t;else xpE.im.removeAttribute('src');
 xpE.bg.style.background=d?`linear-gradient(135deg,${d.c1},${d.c2})`:'';
 xpE.v0.textContent='–';xpE.v2.textContent='–'}
function xpFull(u,p,rk){const d=xpDir(u),nm=String(p.name||(d&&d.n)||u).replace(/^@/,'').trim()||u,bio=String(p.bio||'').trim().slice(0,160),
 c=PCV.find(x=>x[0]==p.pcv),n=p.links.filter(l=>l.url&&!l.arch&&!l.hide).length;
 xpE.nm.textContent=nm;xpE.nm.toggleAttribute('data-vf',p.verify=='ok');xpE.sb.textContent=bio;xpE.sb.hidden=!bio;
 xpE.ai.textContent=nm.slice(0,1).toUpperCase();xpE.ai.parentElement.setAttribute('style',ncSt(u));xpE.im.hidden=!p.photo;if(p.photo)xpE.im.src=p.photo;else xpE.im.removeAttribute('src');
 if(c){xpE.bg.style.background=pcvBg(c[2]);xpE.bg.style.animation='none';void xpE.bg.offsetWidth;xpE.bg.style.animation=''}
 pflNum(xpE.v0,n);xpE.v2.textContent=XRK[rk]||'Free'}
function xpFollowUI(u){if(XP.cur!=u)return;xpMsgUI(u);const x=xfL(u),own=xpOwn(u),on=!!x.on,rd=x.on===undefined&&!own,b=xpE.fl;
 xpE.v1.textContent=x.n==null?'–':lkFmt(x.n);
 b.classList.toggle('ld',rd);b.classList.toggle('on',on&&!own);b.disabled=rd;
 if(own){b.removeAttribute('aria-pressed');b.innerHTML='Editar perfil'}
 else{b.setAttribute('aria-pressed',on);b.innerHTML=`<svg class="i" aria-hidden="true"><use href="#${on?'usercheck':'userplus'}"/></svg><span>${XFT[on?1:0]}</span>`}}
async function xpFollowLoad(u){const me=FB.auth.currentUser;if(!me)return;
 try{const [a,b]=await Promise.all([FB.getDoc(FB.doc(FB.db,'follows',u)),xpOwn(u)?null:FB.getDoc(FB.doc(FB.db,'follows',u,'by',me.uid))]);
  if(XP.fbusy==u)return;
  xfSet(u,{n:a.exists()?Math.max(0,+a.data().n||0):0,on:xpOwn(u)?false:!!(b&&b.exists())});xpFollowUI(u)}
 catch(e){console.warn('seguidores:',e);if(XP.cur==u&&xfL(u).on===undefined){xfSet(u,{n:xfL(u).n||0,on:false});xpFollowUI(u)}}}
async function xpFollow(){const u=XP.cur,me=FB.auth.currentUser,x=xfL(u);if(!u||!me)return;
 if(xpOwn(u)){xpClose();go('edit');return}
 if(XP.fbusy||x.on===undefined)return;
 const was=!!x.on,n0=x.n||0,on=!was;XP.fbusy=u;let ok=false;
 try{ok=await withSpin(xpE.fl,async()=>{const b=FB.writeBatch(FB.db),by=FB.doc(FB.db,'follows',u,'by',me.uid),c=FB.doc(FB.db,'follows',u);
   if(on){b.set(by,{t:FB.serverTimestamp()});b.set(c,{n:FB.increment(1)},{merge:true})}
   else{b.delete(by);b.set(c,{n:FB.increment(-1)},{merge:true})}
   await Promise.race([b.commit(),wait(8000)]);return true},600)}
 catch(e){console.error('seguir:',e);toast(e&&e.code=='permission-denied'?'Sem permissão para seguir. Publique as regras do ficheiro firestore.rules.':'Não foi possível seguir agora. Tente de novo.',5000)}
 finally{XP.fbusy=''}
 if(ok)xfSet(u,{on,n:Math.max(0,n0+(on?1:-1))});if(ok&&on)ntSend('follow',u);/* v85 */
 xpFollowUI(u);if(ok){xpE.fl.classList.remove('pop');void xpE.fl.offsetWidth;xpE.fl.classList.add('pop')}}
/* só aqui o @ aparece: na folha de compartilhar */
async function xpShare(){const u=XP.cur;if(!u)return;const url=pubHost()+'#/'+u,at='@'+u;
 try{if(navigator.share){await navigator.share({title:at+' · Quantum',text:at+' no Quantum',url});return}}catch(e){if(e&&e.name=='AbortError')return}
 try{await navigator.clipboard.writeText(url);toast('Link de '+at+' copiado!',2400)}catch(e){toast(url,5000)}}

function xpLikeUI(u,pop){const x=xpL(u),n=x.n||0,own=xpOwn(u),on=!!x.liked,h=$('#xpphlk');
 h.setAttribute('aria-pressed',on);h.classList.toggle('ro',own);h.classList.toggle('has',own&&n>0);$('.pub-lc',h).textContent=lkFmt(n);
 h.setAttribute('aria-label',own?`Sua página tem ${n} ${n==1?'curtida':'curtidas'}`:on?'Descurtir esta página':'Curtir esta página');
 if(pop){h.classList.remove('pop');void h.offsetWidth;h.classList.add('pop');setTimeout(()=>h.classList.remove('pop'),520)}}
async function xpLikeLoad(u){const me=FB.auth.currentUser;if(!me)return;
 try{const [a,b]=await Promise.all([FB.getDoc(FB.doc(FB.db,'likes',u)),xpOwn(u)?null:FB.getDoc(FB.doc(FB.db,'likes',u,'by',me.uid))]);
  if(XP.busy==u)return;/* uma curtida está sendo gravada: não deixa a leitura antiga sobrescrever */
  xpSet(u,{n:a.exists()?Math.max(0,+a.data().n||0):0,liked:xpOwn(u)?false:!!(b&&b.exists())});xpPaint();if(XP.cur==u)xpLikeUI(u)}
 catch(e){console.warn('curtidas:',e);if(XP.cur==u&&xpL(u).liked===undefined){xpSet(u,{liked:false});xpLikeUI(u)}}}
async function xpToggle(){const u=XP.cur,me=FB.auth.currentUser,x=xpL(u);if(!u||!me)return;
 if(xpOwn(u)){toast('Você não pode curtir a sua própria página.',2400);return}
 if(XP.busy||x.liked===undefined)return;
 const was=!!x.liked,n0=x.n||0,on=!was;XP.busy=u;let ok=false;
 try{ok=await withSpin($('#xpphlk'),async()=>{const b=FB.writeBatch(FB.db),by=FB.doc(FB.db,'likes',u,'by',me.uid),c=FB.doc(FB.db,'likes',u);
   if(on){b.set(by,{t:FB.serverTimestamp()});b.set(c,{n:FB.increment(1)},{merge:true})}
   else{b.delete(by);b.set(c,{n:FB.increment(-1)},{merge:true})}
   await Promise.race([b.commit(),wait(8000)]);return true},450)}
 catch(e){console.error('curtir:',e);toast(e&&e.code=='permission-denied'?'Sem permissão para curtir. Publique as regras do ficheiro firestore.rules.':'Não foi possível curtir agora. Tente de novo.',5000)}
 finally{XP.busy=''}
 if(ok){playSound('tap');vibrate('tap');xpSet(u,{liked:on,n:Math.max(0,n0+(on?1:-1))});xpLikeUI(u,true);xpPaint();if(on)ntSend('like',u)/* v85 */}}
function xpScale(){if(xpv.hidden||xpv.dataset.st!='ok')return;xpph.style.setProperty('--s',(xpph.clientWidth/360).toFixed(3))}
function xpVisit(u){try{if(sessionStorage.getItem('qv:'+u))return;sessionStorage.setItem('qv:'+u,'1')}catch(e){}stHit(u,i=>({v:i(1),s:{explorar:i(1)}}))}
async function xpOpen(u){if(!PUBR.test(u))return;const my=++XP.pseq;clearTimeout(XP.pt);XP.cur=u;
 xpv.dataset.st='load';xpHead(u,xpDir(u));xpLikeUI(u);xpFollowUI(u);
 xpv.hidden=false;document.body.style.overflow='hidden';xpv.scrollTop=0;requestAnimationFrame(()=>{xpv.classList.add('on');$('#xpvx').focus({preventScroll:true})});
 xpLikeLoad(u);xpFollowLoad(u);
 try{await fbReady();const s=await FB.getDoc(FB.doc(FB.db,'pages',u));if(my!=XP.pseq)return;
  if(!s.exists()){xpv.dataset.st='miss';$('#xpvmt').textContent='Página não encontrada';$('#xpvmp').textContent='Esta página não está mais no ar.';$('#xpvre').hidden=true;return}
  const raw=s.data(),p=cleanProfile(raw),pu=+raw.pu||0,rk=(+raw.r||0)>=1&&(!pu||pu>Date.now())?Math.min(2,+raw.r||0):0;p.look=lkEnforce(p.look,rk);
  xpFull(u,p,rk);PRK[u]=rk;xpMsgUI(u);lkApply(xpph,p.look);lkPaint($('.lk-in',xpph),p,u,false);
  xpv.dataset.st='ok';requestAnimationFrame(xpScale);xpVisit(u)}
 catch(e){if(my!=XP.pseq)return;console.error('perfil:',e);xpv.dataset.st='err';$('#xpvmt').textContent='Não foi possível carregar';$('#xpvmp').textContent=xpErr(e);$('#xpvre').hidden=false}}
function xpClose(){if(xpv.hidden)return;XP.pseq++;XP.cur='';xpv.classList.remove('on');document.body.style.overflow='';
 const v=$('video',xpph);if(v&&v.pause)v.pause();
 XP.pt=setTimeout(()=>{xpv.hidden=true;xpv.style.zIndex=''},280);xpPaint()}
$('#xpvx').onclick=xpClose;$('#xpphlk').onclick=xpToggle;$('#xpfl').onclick=xpFollow;$('#xpvre').onclick=()=>xpOpen(XP.cur);
/* Preview: abre a página pública como um visitante a vê */
$('#xpvop').onclick=e=>{const u=XP.cur;if(u)withSpin(e.currentTarget,async()=>{await wait(0)},500).then(()=>open(pubHost()+'#/'+u,'_blank','noopener'))};
$('#xpvsh').onclick=$('#xpvsh2').onclick=xpShare;
document.addEventListener('keydown',e=>{if(e.key=='Escape'&&!xpv.hidden)xpClose()});
addEventListener('resize',xpScale);


/* ===== v71: mensagens (Pro), produtos, processamento visível em todas as ações =====
   UX: Hick (compositor com 3 controles) · Fitts (Follow largo + alvos de 44–56 px) · Jakob (bolhas como WhatsApp/iMessage) · Doherty (spinner imediato)
   · Zeigarnik (rascunho guardado, ponto de não lido) · Von Restorff (Follow escuro, 💬 contornado) · Tesler (foto comprimida sozinha) · Postel (aceita qualquer imagem) */
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function withSpin(b,fn,min=550){if(!b||b.dataset.bz)return;b.dataset.bz='1';const old=b.innerHTML;b.style.minWidth=b.offsetWidth+'px';b.disabled=true;b.classList.add('bz');b.innerHTML='<span class="spin"></span>';const t0=Date.now();
 try{return await fn()}finally{const d=min-(Date.now()-t0);if(d>0)await wait(d);delete b.dataset.bz;b.disabled=false;b.classList.remove('bz');b.style.minWidth='';b.innerHTML=old}}
const PRK={},uidOf=async u=>{await fbReady();const s=await FB.getDoc(FB.doc(FB.db,'usernames',u));return s.exists()?String(s.data().uid||''):''};
const ini=n=>String(n||'?').replace(/^@/,'').trim().slice(0,1).toUpperCase()||'?',hhmm=t=>t?new Date(t).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):'';
const tsOf=v=>v&&v.toMillis?v.toMillis():(+v||Date.now());
function xpMsgUI(u){const b=$('#xpmsg');if(!b||XP.cur!=u)return;b.hidden=xpOwn(u);b.classList.remove('off')}
$('#xpmsg').onclick=e=>{const u=XP.cur;if(!u||xpOwn(u))return;
 if(!cht.hidden&&CH.tu==u){xpClose();return}
 withSpin(e.currentTarget,async()=>{const id=await uidOf(u);if(!id)throw 0;chOpen(id,u,xpE.nm.textContent)},500).catch(()=>toast('Não foi possível abrir a conversa. Tente de novo.'))};

/* ---------- conversa ---------- */
const CH={ps:[],g:false,cid:'',to:'',tu:'',tn:'',un:null,dead:false,ph:'',dr:{}},cht=$('#cht'),chl=$('#chtl'),chin=$('#chtin'),
 EMO={'Rostos':'😀 😃 😄 😁 😆 😅 🤣 😂 🙂 🙃 🫠 😉 😊 😇 🥰 😍 🤩 😘 😗 ☺️ 😚 😙 🥲 😋 😛 😜 🤪 😝 🤑 🤗 🤭 🫢 🫣 🤫 🤔 🫡 🤐 🤨 😐 😑 😶 🫥 😏 😒 🙄 😬 😮‍💨 🤥 😌 😔 😪 🤤 😴 😷 🤒 🤕 🤢 🤮 🤧 🥵 🥶 🥴 😵 😵‍💫 🤯 🤠 🥳 🥸 😎 🤓 🧐 😕 🫤 😟 🙁 ☹️ 😮 😯 😲 😳 🥺 🥹 😦 😧 😨 😰 😥 😢 😭 😱 😖 😣 😞 😓 😩 😫 🥱 😤 😡 😠 🤬 😈 👿 💀 ☠️ 💩 🤡 👹 👺 👻 👽 🤖'.split(' '),
 'Gestos':'👋 🤚 🖐️ ✋ 🖖 🫱 🫲 👌 🤌 🤏 ✌️ 🤞 🫰 🤟 🤘 🤙 👈 👉 👆 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 🫶 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 👀 👁️ 👅 👄 🫦 🧠 🙋 🙆 🙅 🤦 🤷 💁 🙇 🧍 🚶 🏃 💃 🕺'.split(' '),
 'Corações':'❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 ❤️‍🔥 ❤️‍🩹 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💯 💢 💥 💫 💦 💨 🔥 ✨ ⭐ 🌟 🎉 🎊 ✅ ❌ ❓ ❗ ⚡'.split(' '),
 'Natureza':'🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐔 🐧 🐦 🦆 🦅 🦉 🦇 🐺 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🐙 🦀 🐠 🐬 🐳 🦈 🌸 🌹 🌻 🌲 🌴 🍀 🌈 ☀️ 🌙 ☁️ ❄️ 🌊'.split(' '),
 'Comida':'🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍒 🍑 🥭 🍍 🥥 🥑 🍅 🌽 🥕 🍞 🧀 🍳 🥓 🍔 🍟 🍕 🌭 🌮 🌯 🍝 🍜 🍣 🍤 🍦 🍩 🍪 🎂 🍰 🍫 🍬 🍿 ☕ 🍵 🍺 🍻 🥂 🍷 🍹 🥤'.split(' '),
 'Esportes':'⚽ 🏀 🏈 ⚾ 🎾 🏐 🎱 🏓 🥊 🏆 🥇 🎮 🎯 🎲 🎵 🎶 🎤 🎧 🎸 🎹 🎬 🎨 🎁 🎈'.split(' '),
 'Objetos':'📱 💻 ⌚ 📷 📸 🔔 💡 🔑 🔒 💰 💳 💸 🛍️ 📦 📍 ⏰ ✉️ 📝 📌 📎 🔗 🚗 🚕 🚌 🚀 ✈️ 🚢 🏠 🏢 🌍 💼 🏖️'.split(' ')};
/* ===== v77: emojis estilo iPhone (imagens Apple carregadas de um CDN público; se uma imagem falhar, volta ao emoji do aparelho) =====
   Para desligar e usar os emojis do próprio aparelho: EMOJI_STYLE='native'. Para trocar a origem, edite EMOJI_SRC. */
const EMOJI_STYLE='apple';
const EMOJI_SRC=['https://cdn.jsdelivr.net/npm/emoji-datasource-apple@15.1.2/img/apple/64/','https://unpkg.com/emoji-datasource-apple@15.1.2/img/apple/64/','https://cdn.jsdelivr.net/npm/emoji-datasource-apple@15.0.1/img/apple/64/'];
const EMRE=/(?:\p{Regional_Indicator}{2}|[#*0-9]\uFE0F?\u20E3|(?:\p{Emoji_Presentation}|\p{Extended_Pictographic}\uFE0F)\p{Emoji_Modifier}?(?:\u200D(?:\p{Emoji_Presentation}|\p{Extended_Pictographic})\uFE0F?\p{Emoji_Modifier}?)*)/gu;
const emCode=c=>[...c].map(x=>x.codePointAt(0).toString(16).padStart(4,'0')).join('-');
function emUrls(c){const k=emCode(c),n=k.replace(/-fe0f/g,''),o=EMOJI_SRC.map(b=>b+k+'.png');if(n!=k)EMOJI_SRC.forEach(b=>o.push(b+n+'.png'));return o}
/* recebe TEXTO PURO (sem HTML) e devolve HTML com <img> no lugar de cada emoji; o resto é escapado */
function emoT(t){t=String(t==null?'':t);if(EMOJI_STYLE!='apple')return esc(t);let o='',i=0,m;EMRE.lastIndex=0;
 while((m=EMRE.exec(t))){o+=esc(t.slice(i,m.index))+emImg(m[0]);i=m.index+m[0].length}
 return o+esc(t.slice(i))}
function emImg(c){const u=emUrls(c);return`<img class="em" src="${u[0]}" alt="${esc(c)}" data-n="0" data-c="${esc(c)}" draggable="false" decoding="async">`}
document.addEventListener('error',e=>{const t=e.target;if(!t||t.tagName!='IMG'||!t.classList.contains('em'))return;
 const u=emUrls(t.dataset.c||t.alt||''),n=(+t.dataset.n||0)+1;
 if(n<u.length){t.dataset.n=n;t.src=u[n]}else t.replaceWith(document.createTextNode(t.alt||''))},true);
/* só emojis (1 a 3) → aparecem grandes, como no WhatsApp */
const emOnly=t=>{t=String(t||'').replace(/\s+/g,'');if(!t||t.length>40)return false;const r=t.replace(EMRE,'');EMRE.lastIndex=0;return r===''&&(String(t).match(EMRE)||[]).length<=3};
const PEER=new Map();
function peer(u){if(!u)return Promise.resolve({});if(!PEER.has(u))PEER.set(u,fbReady().then(()=>FB.getDoc(FB.doc(FB.db,'dir',u))).then(s=>s.exists()?(xpDoc(s)||{}):{}).catch(()=>({})));return PEER.get(u)}
function avFill(el,u){if(!u||!el)return;peer(u).then(p=>{if(p.t){el.style.backgroundImage=`url("${p.t}")`;el.classList.add('ph');el.textContent=''}})}
function peersPaint(root,sel,nameSel){$$(sel,root).forEach(el=>{const u=el.dataset.pu;if(!u)return;avFill($('.cht-av',el)||el,u);peer(u).then(p=>{const n=$(nameSel,el);if(n&&p.v)n.setAttribute('data-vf','')})})}
/* v74: "digitando…" com 3 pontinhos (sem texto). Vai no próprio documento da conversa: chats/{id}.ty.{uid} = hora; não precisa de regra nova.
   Quem recebe NÃO compara relógios: quando o valor muda, mostra os pontinhos por 5 s (sem depender da hora do outro aparelho). */
const TY=new Map(),TYS=new Set(),TYD='<span class="tyd" role="status" aria-label="Digitando"><i></i><i></i><i></i></span>';
function tyFeed(cid,ty){const me=FB.auth.currentUser&&FB.auth.currentUser.uid,seed=!TYS.has(cid);TYS.add(cid);
 Object.keys(ty||{}).forEach(o=>{if(o==me)return;const v=+ty[o]||0,k=cid+'|'+o,p=TY.get(k);
  if(!p){TY.set(k,{v,u:0});if(!seed&&v>0){TY.get(k).u=Date.now()+5000;tyLater()}return}
  if(p.v!==v){p.v=v;p.u=v>0?Date.now()+5000:0;if(p.u)tyLater()}})}
function tyWho(cid){const t=Date.now(),o=[];TY.forEach((p,k)=>{if(p.u>t&&k.startsWith(cid+'|'))o.push(k.slice(cid.length+1))});return o}
let tyTm=0;function tyLater(){clearTimeout(tyTm);tyTm=setTimeout(()=>{if(CH.cid)chtSeen();msrPaint()},5100)}
function tyName(c,uids){const p=c||{};return uids.map(u=>String((p[u]&&(p[u].n||p[u].u))||'').trim().split(' ')[0]).filter(Boolean).slice(0,2).join(', ')}
function tySend(on){const c=CH.cid;if(!c||!CH.ex||CH.edit)return;const me=FB.auth.currentUser.uid;
 if(on){if(Date.now()-(CH.tyT||0)<3500)return;CH.tyT=Date.now()}else{if(!CH.tyT)return;CH.tyT=0}
 FB.updateDoc(FB.doc(FB.db,'chats',c),{['ty.'+me]:on?Date.now():0}).catch(()=>{})}
/* ===== v75: links azuis, avatar no grupo, ajudantes de grupo ===== */
const URLRE=/\b(?:https?:\/\/|www\.)[^\s<>"']+|\b(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+(?:com|net|org|io|co|app|dev|me|info|xyz|link|site|online|store|shop|ly|gl|tv|ai|br|pt|mz)\b(?:\/[^\s<>"']*)?/gi;
function linkify(t){t=String(t==null?'':t);let o='',i=0,m;URLRE.lastIndex=0;
 while((m=URLRE.exec(t))){let u=m[0];const st=m.index;
  if(st>0&&/[@.\/\w-]/.test(t[st-1]))continue;
  for(;;){const c=u[u.length-1];
   if(c&&'.,;:!?\'"»”’'.includes(c)||c==')'&&u.split('(').length<u.split(')').length||c==']'&&u.split('[').length<u.split(']').length){u=u.slice(0,-1);continue}break}
  if(u.length<4||!/\w\.\w/.test(u))continue;
  const end=st+u.length,href=/^https?:\/\//i.test(u)?u:'https://'+u;
  o+=emoT(t.slice(i,st))+`<a class="lnk" href="${esc(href)}" target="_blank" rel="noopener noreferrer nofollow">${esc(u)}</a>`;i=end;URLRE.lastIndex=end}
 return o+emoT(t.slice(i))}
const okI=v=>/^data:image\/(?:jpeg|png|webp|gif);base64,/i.test(v||'')||cldOk(v),okA=v=>/^data:audio\//i.test(v||'');
/* v91: m.i guarda a URL do Cloudinary (foto OU vídeo). Vídeo = m.video===true (ou URL /video/upload/) */
const isVid=m=>!!m&&cldOk(m.i)&&(m.video===true||m.type=='video'||/\/video\/upload\//.test(m.i));
const meId=()=>(FB&&FB.auth&&FB.auth.currentUser&&FB.auth.currentUser.uid)||'';
const gOwnerId=d=>{d=d||CH.gd||{};if(d.ow)return d.ow;const p=d.p||CH.p||{};return Object.keys(p).find(k=>p[k]&&p[k].u&&p[k].u==d.to)||''};
const gAdmins=d=>{d=d||CH.gd||{};if(Array.isArray(d.ad)&&d.ad.length)return d.ad;const o=gOwnerId(d);return o?[o]:[]};
const gIsAdm=(u,d)=>gAdmins(d).includes(u);
function grpHead(){if(!CH.g)return;const d=CH.gd||{},av=$('#chtav'),gp=okI(d.gp)?d.gp:'';$('#chtnm').textContent=CH.tn;av.classList.toggle('ph',!!gp);av.style.backgroundImage=gp?`url("${gp}")`:'';av.textContent=gp?'':ini(CH.tn)}
function grpGone(msg){if(CH.quit)CH.quit=false;else toast(msg,4500);giClose(true);const m=$('#cmm');if(m&&!m.hidden)prsHide(m);chShut()}
function chSub(){if(CH.un)CH.un();if(CH.dn)CH.dn();CH.dead=false;const cid=CH.cid;
 let snF=false;
 CH.un=FB.onSnapshot(FB.query(FB.collection(FB.db,'chats',cid,'m'),FB.orderBy('at','desc'),FB.limit(60)),
  s=>{if(CH.cid!=cid)return;{const me=FB.auth.currentUser&&FB.auth.currentUser.uid;if(snF){try{if(s.docChanges().some(c=>{if(c.type!='added'||c.doc.metadata.hasPendingWrites)return false;const d=c.doc.data({serverTimestamps:'estimate'});return d.f&&d.f!=me&&Date.now()-tsOf(d.at)<20000})){playSound('receive');vibrate('tap')}}catch(e){}}snF=true}const L=s.docs.map(d=>({id:d.id,...d.data({serverTimestamps:'estimate'}),_p:d.metadata.hasPendingWrites&&d.get('at')==null})).reverse();if(!CH.ml){if(!L.length&&s.metadata.fromCache){CH.msgs=L;return}CH.ml=true}chRender(L);chRead()},
  e=>{if(CH.cid!=cid)return;CH.dead=true;if(CH.g&&CH.had)return;CH.ml=true;chRender([])});
 CH.dn=FB.onSnapshot(FB.doc(FB.db,'chats',cid),s=>{if(CH.cid!=cid)return;const me=FB.auth.currentUser.uid;
   if(CH.g){if(!s.exists()){if((CH.had||CH.iv)&&!s.metadata.fromCache)grpGone('Este grupo foi apagado.');return}
    const g=s.data();CH.had=true;const inn=(g.ps||[]).includes(me);if(inn)CH.iv='';/* v84: aceitou → vira grupo normal */
    if(!inn&&!CH.iv){grpGone('Você não está mais neste grupo.');return}
    CH.gd=g;CH.ps=g.ps;CH.tn=g.gn||CH.tn;grpHead();if(!CH.iv)giPaint()}
   const d=s.exists()?s.data():{};CH.rd=d.rd||{};CH.sc=d.sc||{};CH.rq=CH.g?'':(d.rq||'');CH.p=d.p||{};CH.ex=s.exists();CH.sk=true;CH.mn=Array.isArray((d.mn||{})[me])?d.mn[me]:[];tyFeed(cid,d.ty);chRender(CH.msgs);mnPaint();chLock();chtSeen()},
  e=>{if(CH.cid!=cid)return;if(CH.iv){grpGone(e&&e.code=='permission-denied'?'Link expirado.':'Não foi possível abrir este grupo.');return}if(CH.g&&CH.had)grpGone('Você não está mais neste grupo.')})}
/* v74: ícones de status da mensagem (relógio = enviando · ✓ = enviada · ✓✓ = lida), desenhados em SVG como no Telegram */
const TKS={c:'<svg class="tki" viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="5.8"/><path d="M8 4.8V8l2.3 1.4"/></svg>',
 s:'<svg class="tki" viewBox="0 0 12 10" aria-hidden="true"><path d="M1.2 5.3l3.2 3.2 6.2-6.8"/></svg>',
 r:'<svg class="tki d" viewBox="0 0 18 10" aria-hidden="true"><path d="M1.2 5.3l3.2 3.2 6.2-6.8M7.2 5.3l3.2 3.2 6.2-6.8"/></svg>'};
/* v75: a lista NÃO é mais reescrita inteira — cada mensagem é atualizada no lugar (sem piscar/tremer) e só as novas animam */
function chBody(m,me,adm){const g=CH.g&&m.f!=me;
 return(g?`<small class="cn" style="${ncSt(ncKey(m.f),ncG())}">${esc(m.n||'')}${adm.has(m.f)?`<i class="adb${m.f==gOwnerId()?' own':''}">${m.f==gOwnerId()?I('cr'):''}Admin</i>`:''}</small>`:'')+rpHtml(m,me)+(okI(m.i)?(imgGate(m)?dlHtml(m):mediaTag(m)):'')+(okA(m.a)?apHtml(m):'')+(m.t?`<p${emOnly(m.t)&&!m.i&&!m.a?' class="jb"':''}>${linkify(m.t)}</p>`:'')}
function chRow(m,me){const row=document.createElement('div'),mine=m.f==me;row.className='cr '+(mine?'me':'th');row.dataset.id=m.id;
 let av='';if(CH.g&&!mine){const u=(CH.p[m.f]&&CH.p[m.f].u)||'';av=`<span class="cht-av cm-av" style="${ncSt(u||m.f,ncG())}" data-pu="${esc(u)}" role="button" aria-label="Ver perfil de ${esc(m.n||'membro')}">${esc(ini(m.n))}</span>`}
 row.innerHTML=av+`<div class="cm ${mine?'me':'th'}"><div class="cb"></div><div class="rx" hidden></div><time></time></div>`;
 const a=$('.cm-av',row);if(a&&a.dataset.pu)avFill(a,a.dataset.pu);return row}
function chRender(L){CH.msgs=L;if(!CH.ml){chSkel();return}const me=FB.auth.currentUser.uid,oth=CH.ps.filter(x=>x!=me),rd=CH.rd||{},adm=new Set(gAdmins());
 const rcn={};L.forEach(x=>{if(x.rp&&x.rp.id)rcn[x.rp.id]=(rcn[x.rp.id]||0)+1});
 const tk=m=>{if(m.f!=me)return'';if(m._p)return`<span class="tk pd" role="img" aria-label="Enviando">${TKS.c}</span>`;const r=oth.length&&oth.every(o=>rd[o]&&tsOf(rd[o])>=tsOf(m.at));return`<span class="tk${r?' r':''}" role="img" aria-label="${r?'Lida':'Enviada'}">${r?TKS.r:TKS.s}</span>`};
 {const sk=$('.sk-w',chl);if(sk){sk.remove();chl.removeAttribute('aria-busy');chl.classList.add('ldin');setTimeout(()=>chl.classList.remove('ldin'),320)}}
 if(!L.length){if(!$('.cht-em',chl))chl.innerHTML=CH.iv?'<p class="cht-em">Ainda não há mensagens.</p>':'<p class="cht-em">Diga olá '+emoT('👋')+'<br><small>As mensagens ficam entre vocês.</small></p>';return}
 const em=$('.cht-em',chl);if(em)em.remove();
 const near=chl.scrollHeight-chl.scrollTop-chl.clientHeight<140||!chl.children.length||Date.now()<(CH.stick||0);
 const have=new Map(),ids=new Set(L.map(m=>m.id));[...chl.children].forEach(r=>have.set(r.dataset.id,r));have.forEach((r,id)=>{if(!ids.has(id)){r.remove();have.delete(id)}});
 let fresh=false;
 L.forEach((m,i)=>{let r=have.get(m.id);
  if(!r){r=chRow(m,me);if(Date.now()-CH.t0>1500&&Date.now()-tsOf(m.at)<30000){fresh=true;r.classList.add('new');r.addEventListener('animationend',()=>r.classList.remove('new'),{once:true})}}
  const b=chBody(m,me,adm),mt=`${rcn[m.id]?`<span class="rpc" role="button" aria-label="${rcn[m.id]} respostas">${I('rpl')}${rcn[m.id]}</span>`:''}${m.ed?'editada · ':''}${hhmm(tsOf(m.at))}${tk(m)}`;
  if(r._b!==b){$('.cb',r).innerHTML=b;r._b=b;if(r._au)apPaint(r,r._au)}
  if(r._m!==mt){$('time',r).innerHTML=mt;r._m=mt}
  const rxh=rxHtml(m,me);if(r._x!==rxh){const x=$('.rx',r);x.innerHTML=rxh;x.hidden=!rxh;r._x=rxh}
  if(chl.children[i]!==r)chl.insertBefore(r,chl.children[i]||null)});
 if(near)chBottom(fresh);mnLater()}
/* v96: scroll do chat em requestAnimationFrame (1 por frame, junta chamadas seguidas; lê scrollHeight já com o layout pronto) */
function chBottom(smooth){
 if(smooth)chl._sm=1;if(chl._sc)return;
 chl._sc=requestAnimationFrame(()=>{chl._sc=0;const s=chl._sm;chl._sm=0;
  if(s)chl.scrollTo({top:chl.scrollHeight,behavior:'smooth'});else chl.scrollTop=chl.scrollHeight})}
const chLoad=e=>{if(e.type=='loadedmetadata'){const w=e.target.closest&&e.target.closest('.vw'),t=w&&w.querySelector('.vt');if(t&&isFinite(e.target.duration))t.textContent=fmtT(Math.round(e.target.duration))}
 if((e.target.tagName=='IMG'||e.target.tagName=='VIDEO')&&!(e.target.closest&&e.target.closest('.dlw,.vw'))&&(Date.now()<(CH.stick||0)||chl.scrollHeight-chl.scrollTop-chl.clientHeight<420))chBottom()};
chl.addEventListener('load',chLoad,true);chl.addEventListener('loadedmetadata',chLoad,true);
function chRead(){if(CH.iv||document.visibilityState!='visible')return;const me=FB.auth.currentUser.uid;FB.updateDoc(FB.doc(FB.db,'chats',CH.cid),{['un.'+me]:0,['rd.'+me]:FB.serverTimestamp()}).catch(()=>{})}
async function chOpen(uid,u,n,pre,g,iv){await fbReady();const me=FB.auth.currentUser;if(!me)return;
 if(CH.cid&&!cht.hidden)chShut(true);
 if(g){CH.cid=g.id;CH.ps=g.ps;CH.g=true;CH.to='';CH.tu='';CH.tn=g.gn||'Grupo';CH.gd=g}
 else{CH.ps=[me.uid,uid].sort();CH.cid=CH.ps.join('_');CH.g=false;CH.to=uid;CH.tu=u;CH.tn=String(n||u).replace(/^@/,'');CH.gd=null}
 CH.iv=iv||'';/* v84: id do convite quando é só pré-visualização de grupo */chPvClr();CH.rq='';CH.rep=false;CH.rpk=false;CH.rd=g&&g.rd||{};CH.sc=g&&g.sc||{};CH.p=g&&g.p||{};CH.ex=!!g;CH.sk=false;CH.tyT=0;CH.msgs=[];CH.ml=false;CH.mn=[];clearTimeout(CH.mlT);CH.sig='';CH.edit=null;CH.reply=null;$('#chtrp').hidden=true;CH.rp=false;CH.seen=0;CH.t0=Date.now();CH.stick=Date.now()+2500;CH.had=false;CH.quit=false;$('#chtpv').hidden=true;$('#chted').hidden=true;
 const av=$('#chtav');av.style.cssText=g?'':ncSt(u||uid);av.classList.remove('ph');av.textContent=ini(CH.tn);$('#chtnm').textContent=CH.tn;$('#chtnm').removeAttribute('data-vf');
 $('#chtwho').disabled=false;$('#chtwho').setAttribute('aria-label',CH.g?'Informações do grupo':'Abrir perfil');if(CH.g)grpHead();chtSeen();
 if(!CH.g){avFill(av,u);peer(u).then(p=>{if(CH.tu==u)$('#chtnm').toggleAttribute('data-vf',!!p.v)});
  if(PRK[u]!==undefined){CH.rp=PRK[u]>=1;CH.rpk=true}else FB.getDoc(FB.doc(FB.db,'pages',u)).then(s=>{if(CH.tu==u){CH.rp=s.exists()&&(+s.data().r||0)>=1&&(!(+s.data().pu)||+s.data().pu>Date.now());CH.rpk=true;chLock()}}).catch(()=>{});
  const cid=CH.cid;CH.pu=FB.onSnapshot(FB.doc(FB.db,'presence',uid),s=>{if(CH.cid!=cid)return;CH.seen=s.exists()?+s.data().t||0:0;chtSeen()},()=>{})}
 chl.innerHTML='';chSkel();mnPaint();{const c0=CH.cid;CH.mlT=setTimeout(()=>{if(CH.cid==c0&&!CH.ml){CH.ml=true;chRender(CH.msgs)}},4500)}chin.value=pre||CH.dr[CH.cid]||'';chGrow();chMode();chLock();$('#chtep').hidden=true;
 cht.hidden=false;document.body.style.overflow='hidden';requestAnimationFrame(()=>{cht.classList.add('on');if(matchMedia('(hover:hover)').matches&&!chin.disabled)chin.focus({preventScroll:true})});chSub()}
function chtSeen(){const s=$('#chtun'),ty=tyWho(CH.cid);
 if(ty.length){const nm=CH.g?tyName(CH.p,ty):'',h=(nm?esc(nm)+' ':'')+TYD;if(s.dataset.ty!=h){s.innerHTML=h;s.dataset.ty=h}s.classList.remove('on');s.classList.add('ty');return}
 delete s.dataset.ty;s.classList.remove('ty');
 if(CH.g){s.textContent=CH.iv&&!CH.ps.length?'Convite de grupo':CH.ps.length+' membros';s.classList.remove('on');return}
 const t=CH.seen,d=Date.now()-t;let x='offline';if(t){if(d<100000)x='online';else{const m=Math.round(d/60000);if(m<60)x=`visto há ${m} min`;else{const h=Math.floor(m/60);x=h<24?`visto há ${h} h`:`visto há ${Math.floor(h/24)} ${Math.floor(h/24)==1?'dia':'dias'}`}}}
 s.textContent=x;s.classList.toggle('on',x=='online')}
setInterval(()=>{if(!cht.hidden&&!CH.g)chtSeen()},30000);
function chShut(q){CH.iv='';clearTimeout(CH.mlT);mnb.classList.remove('on');if(CH.cid)CH.dr[CH.cid]=chin.value;tySend(false);if(CH.un){CH.un();CH.un=null}if(CH.dn){CH.dn();CH.dn=null}if(CH.pu){CH.pu();CH.pu=null}if(AUD.r)auStop(false);apStop();
 cht.classList.remove('on');if(q){cht.hidden=true;return}document.body.style.overflow=(!xpv.hidden||!msr.hidden)?'hidden':'';setTimeout(()=>{cht.hidden=true},260);CH.cid=''}
$('#chtx').onclick=()=>chShut();
function chGrow(){chin.style.height='auto';chin.style.height=Math.min(120,chin.scrollHeight)+'px'}
chin.addEventListener('input',chGrow);
chin.addEventListener('keydown',e=>{if(e.key=='Enter'&&!e.shiftKey&&matchMedia('(hover:hover)').matches){e.preventDefault();chSend()}});
$('#chtsd').addEventListener('pointerdown',e=>{if(e.pointerType!='mouse'||document.activeElement==chin)e.preventDefault()});$('#chtsd').onclick=()=>chSend();
function chMode(){const has=chin.value.trim()||CH.ph||CH.edit;$('#chtsd').hidden=!has;$('#chtmic').hidden=!!has}
function chEditEnd(){CH.edit=null;$('#chted').hidden=true;chin.value='';chGrow();chMode()}
async function chEditSend(t,cid){const m=CH.edit,btn=$('#chtsd');if(!t){toast('Escreva a mensagem.');return}if(t==m.t){chEditEnd();return}
 try{await withSpin(btn,async()=>{await Promise.race([FB.updateDoc(FB.doc(FB.db,'chats',cid,'m',m.id),{t,ed:true}),wait(8000)]);const l=CH.msgs[CH.msgs.length-1];if(l&&l.id==m.id)FB.updateDoc(FB.doc(FB.db,'chats',cid),{'last.t':t}).catch(()=>{})},400);chEditEnd()}
 catch(e){toast('Não foi possível editar (só até 15 minutos depois de enviar).',4200)}}
/* v75: envio instantâneo — limpa o campo na hora, sem spinner no botão, mantém o teclado aberto e a mensagem aparece como "enviando" (relógio) até o servidor confirmar */
function chSend(au){const t=chin.value.trim(),im=CH.ph,vd=!!CH.pv,cid=CH.cid;if(CH.up&&!au){toast('Aguarde o envio da mídia…',1800);return}if((!t&&!im&&!au)||!cid||chin.disabled&&!au)return;
 if(CH.edit&&!au){chEditSend(t,cid);return}
 if(!CH.g&&!CH.ex&&!CH.rpk&&stRank()<1&&CH.tu){rpOf(CH.tu).then(v=>{if(CH.cid!=cid)return;CH.rp=v;CH.rpk=true;chLock();chSend(au)});return}/* v80: antes de criar a conversa precisa saber se o destino é premium (vira solicitação) */
 const me=FB.auth.currentUser,P=S.profile||{},b=FB.writeBatch(FB.db),cr=FB.doc(FB.db,'chats',cid),mr=FB.doc(FB.collection(FB.db,'chats',cid,'m'));
 const un={[me.uid]:0};CH.ps.forEach(x=>{if(x!=me.uid)un[x]=FB.increment(1)});
 const dc={p:{[me.uid]:{u:P.username||'',n:P.name||S.u.name||''}},last:{t:au?'🎤 Áudio':(t||(vd?'🎥 Vídeo':'📷 Foto')),f:me.uid},at:FB.serverTimestamp(),un,sc:{[me.uid]:FB.increment(1)}};
 if(!CH.g){dc.to=CH.tu;dc.p[CH.to]={u:CH.tu,n:CH.tn}}
 if(!CH.ex){dc.ps=CH.ps;if(CH.g){dc.g=true;dc.gn=CH.tn;dc.to=''}}
 if(!CH.ex&&!CH.g&&stRank()<1&&CH.rp){dc.rq=me.uid;CH.rq=me.uid}/* conta grátis → premium: a 1ª mensagem vira solicitação na caixa de entrada */
 if(CH.ex)dc.ty={[me.uid]:0};
 const md={f:me.uid,n:(P.name||S.u.name||'').slice(0,60),t:au?'':t,i:au?'':(im||''),at:FB.serverTimestamp()};if(au){md.a=au.a;md.ad=au.d}else if(im&&vd)md.video=true;/* v91: vídeo = i (URL) + video:true */
 const rpl=CH.reply;if(rpl)md.rp={id:rpl.id,f:rpl.f,n:String(rpl.n||'').slice(0,60),t:String(rpl.t||'').slice(0,120),k:rpl.k||''};
 if(rpl&&rpl.f&&rpl.f!=me.uid)dc.mn={[rpl.f]:FB.arrayUnion(mr.id)};
 b.set(cr,dc,{merge:true});b.set(mr,md);
 playSound('send');vibrate('tap');
 CH.stick=Date.now()+1800;
 if(!au){chin.value='';chPvClr();chGrow();if(ep.hidden&&matchMedia('(hover:hover)').matches){try{chin.focus({preventScroll:true})}catch(e){}}}
 CH.reply=null;rpBar();delete CH.dr[cid];CH.sc[me.uid]=(CH.sc[me.uid]||0)+1;CH.tyT=0;chMode();chLock();
 b.commit().then(()=>{if(CH.cid==cid&&CH.dead)chSub()}).catch(e=>{console.error('mensagem:',e);
  if(CH.cid==cid){if(rpl&&!CH.reply){CH.reply=rpl;rpBar()}CH.sc[me.uid]=Math.max(0,(CH.sc[me.uid]||1)-1);if(!au&&!chin.value){chin.value=t;CH.ph=im||'';CH.pv=vd;if(im)chPvSet(im,vd,false);chGrow()}chMode();chLock()}
  toast(e&&e.code=='permission-denied'?'Sem permissão. Publique o firestore.rules atualizado no Firebase.':'Não foi possível enviar. Tente de novo.',5200)})}
/* ===== v91: mídia do chat — folha inferior (Galeria / Câmera / Vídeo) → Cloudinary → URL em m.i ===== */
const mpk=$('#mpk'),mpkF=$('#mpkfile');
/* Capacitor: no APK, com @capacitor/camera instalado, "Galeria" e "Câmera" usam o plugin; na web (ou sem plugin) caem no <input type="file"> */
const CAP=()=>{try{const c=window.Capacitor;return c&&c.isNativePlatform&&c.isNativePlatform()&&c.Plugins&&c.Plugins.Camera?c.Plugins.Camera:null}catch(e){return null}};
function mpkOpen(){if($('#chtph').disabled)return;chin.blur();mpk.hidden=false;requestAnimationFrame(()=>mpk.classList.add('on'))}
function mpkClose(){prsHide(mpk)}
function mpkInput(kind){mpkF.accept=kind=='video'?'video/*':'image/*,video/*';
 if(kind=='camera')mpkF.setAttribute('capture','environment');else mpkF.removeAttribute('capture');mpkF.click()}
async function mpkNative(kind){const cam=CAP();if(!cam)return false;
 try{let p;if(kind=='camera')p=await cam.getPhoto({quality:90,resultType:'uri',source:'CAMERA',correctOrientation:true});
  else{const r=await cam.pickImages({quality:90,limit:1});p=r&&r.photos&&r.photos[0]}
  if(!p||!p.webPath)return true;
  const bl=await(await fetch(p.webPath)).blob();chMedia(new File([bl],'foto.'+(p.format||'jpg'),{type:bl.type||'image/'+(p.format||'jpeg')}));return true}
 catch(e){return /cancel/i.test(String((e&&(e.message||e))||''))}}
function mpkPick(kind){mpkClose();
 if(kind!='video'&&CAP()){mpkNative(kind).then(done=>{if(!done)mpkInput(kind)});return}/* vídeo: sempre <input> (o plugin só entrega fotos) */
 mpkInput(kind)}
/* grade de prévias: o app nativo pode preencher com as mídias recentes → QuantumMedia.setPreviews([{thumb:'https://…',path:'file://…',video:false}]) */
window.QuantumMedia={setPreviews(list){const g=$('#mpkgd');$$('.mpk-th',g).forEach(x=>x.remove());
 (Array.isArray(list)?list:[]).slice(0,24).forEach(o=>{if(!o||!o.path)return;const b=document.createElement('button');b.type='button';b.className='mpk-th'+(o.video?' v':'');b.dataset.path=o.path;b.dataset.vid=o.video?'1':'';b.setAttribute('aria-label',o.video?'Vídeo recente':'Foto recente');
  const im=document.createElement('img');im.alt='';im.loading='lazy';im.src=o.thumb||o.path;b.appendChild(im);g.appendChild(b)})}};
mpk.onclick=e=>{if(e.target.closest('[data-x]')){mpkClose();return}
 const t=e.target.closest('[data-mp]');if(t){mpkPick(t.dataset.mp);return}
 const th=e.target.closest('.mpk-th');if(th){mpkClose();fetch(th.dataset.path).then(r=>r.blob()).then(bl=>chMedia(new File([bl],th.dataset.vid?'video.mp4':'foto.jpg',{type:bl.type}))).catch(()=>toast('Não foi possível abrir essa mídia.'))}};
$('#chtph').onclick=mpkOpen;
mpkF.onchange=e=>{const f=e.target.files[0];e.target.value='';if(f)chMedia(f)};
/* prévia (miniatura) acima do campo: foto ou vídeo + spinner enquanto sobe */
function chPvSet(src,vid,busy){const p=$('#chtpv'),im=$('img',p),vd=$('video',p);
 if(vid){vd.src=src+'#t=0.1';vd.hidden=false;im.hidden=true;im.removeAttribute('src')}else{im.src=src;im.hidden=false;vd.hidden=true;vd.removeAttribute('src')}
 $('.cht-sp',p).hidden=!busy;p.classList.toggle('vid',!!vid);p.hidden=false}
function chPvClr(){if(CH.up){CH.up.abort();CH.up=null}CH.ph='';CH.pv=false;if(CH.pl){URL.revokeObjectURL(CH.pl);CH.pl=''}
 const p=$('#chtpv');if(!p)return;p.hidden=true;$('img',p).removeAttribute('src');$('video',p).removeAttribute('src');$('.cht-sp',p).hidden=true}
async function chMedia(f){const vid=/^video\//.test(f.type)||(!f.type&&/\.(mp4|mov|m4v|webm|3gp)$/i.test(f.name||''));
 if(!vid&&!/^image\//.test(f.type)){toast('Escolha uma foto ou um vídeo.',3200);return}
 if(f.size>(vid?CLD.maxVid:CLD.maxImg)){toast(vid?'O vídeo passa de 100 MB.':'A foto passa de 10 MB.',4200);return}
 if(!CH.cid)return;chPvClr();
 const cid=CH.cid,ac=new AbortController(),loc=URL.createObjectURL(f);CH.up=ac;CH.pl=loc;chPvSet(loc,vid,true);chMode();
 try{const u=await uploadToCloudinary(f,{signal:ac.signal});if(CH.up!==ac||CH.cid!=cid)return;CH.up=null;CH.ph=u;CH.pv=vid;$('.cht-sp',$('#chtpv')).hidden=true}
 catch(e){if(CH.up===ac){chPvClr();if(!(e&&e.name=='AbortError'))toast((e&&e.message)||'Não foi possível enviar a mídia. Tente de novo.',4800,'error')}}
 finally{chMode()}}
$('#chtpx').onclick=()=>{chPvClr();chMode()};
/* emojis (usa os emojis do próprio aparelho: no iPhone aparecem os da Apple) */
const ep=$('#chtep');let epT=Object.keys(EMO)[0];
function epPaint(){ep.innerHTML='<div class="ep-t" role="tablist">'+Object.keys(EMO).map(k=>`<button type="button" role="tab" aria-selected="${k==epT}" data-k="${k}">${k}</button>`).join('')+'</div><div class="ep-g">'+EMO[epT].map(x=>`<button type="button" data-e="${x}" aria-label="${x}">${emoT(x)}</button>`).join('')+'</div>'}
$('#chtem').onclick=e=>{const o=ep.hidden;ep.hidden=!o;e.currentTarget.setAttribute('aria-expanded',o);if(o){epPaint();chin.blur()}else chin.focus()};
ep.onclick=e=>{const k=e.target.closest('[data-k]'),x=e.target.closest('[data-e]');if(k){epT=k.dataset.k;epPaint();return}
 if(x){const s=chin.selectionStart??chin.value.length,en=chin.selectionEnd??s;chin.value=chin.value.slice(0,s)+x.dataset.e+chin.value.slice(en);chin.selectionStart=chin.selectionEnd=s+x.dataset.e.length;chGrow()}};
chin.addEventListener('focus',()=>{ep.hidden=true;$('#chtem').setAttribute('aria-expanded','false')});

/* ---------- caixa de mensagens (aba Público) ---------- */
const IB={uid:'',un:null,list:[],inv:[],ui:null},rqs=$('#rqs'),rqIn=c=>!c.g&&!!c.rq&&c.rq!=IB.uid;/* v80: c.rq = uid de quem enviou a solicitação enquanto o premium ainda não aceitou ('' = conversa normal) */
/* v84: convite de grupo vale 5h (a partir de ginv.at); depois disso aparece "Link expirado" e o grupo não abre mais */
const IV_TTL=5*3600*1000,ivExp=v=>!!v&&!!v.at&&Date.now()-tsOf(v.at)>IV_TTL,ivLive=()=>(IB.inv||[]).filter(v=>!ivExp(v));
function ivTimer(){clearTimeout(IB.iT);const t=(IB.inv||[]).filter(v=>v.at&&!ivExp(v)).map(v=>tsOf(v.at)+IV_TTL-Date.now());if(t.length)IB.iT=setTimeout(()=>{inboxPaint();ivTimer()},Math.min(...t)+500)}
function inboxInit(){const me=FB.auth&&FB.auth.currentUser;if(!me||!S.u)return;presStart();if(IB.uid==me.uid){inboxPaint();return}
 if(IB.un)IB.un();if(IB.ui){IB.ui();IB.ui=null}IB.uid=me.uid;IB.list=[];IB.inv=[];
 /* v82: convites de grupo (perfil premium não entra direto: aceita aqui) */
 try{IB.ui=FB.onSnapshot(FB.query(FB.collection(FB.db,'ginv'),FB.where('to','==',me.uid),FB.limit(20)),s=>{IB.inv=s.docs.map(d=>({id:d.id,...d.data()}));ivTimer();rqPaint();inboxPaint()},e=>console.warn('convites:',e))}catch(e){}
 try{IB.un=FB.onSnapshot(FB.query(FB.collection(FB.db,'chats'),FB.where('ps','array-contains',me.uid),FB.limit(40)),
  s=>{IB.list=s.docs.map(d=>({id:d.id,...d.data({serverTimestamps:'estimate'})})).sort((a,b)=>tsOf(b.at)-tsOf(a.at));IB.list.forEach(c=>tyFeed(c.id,c.ty));inboxPaint()},e=>{console.warn('mensagens:',e);inboxPaint()})}catch(e){}}
const lastHtml=(t,k)=>{t=String(t||'');if(t.startsWith('🎤'))return I('qmic')+'Áudio';if(/^📷\s*Foto$/.test(t))return I('img')+'Foto';if(/^🎥\s*Vídeo$/.test(t))return I('vid')+'Vídeo';return emoT(t||k||'')};
const cInfo=c=>{const me=IB.uid;if(c.g)return{g:1,n:c.gn||'Grupo',u:'',o:'',k:(c.ps||[]).length+((c.ps||[]).length==1?' membro':' membros'),gp:okI(c.gp)?c.gp:''};const o=(c.ps||[]).find(x=>x!=me)||'',p=(c.p&&c.p[o])||{};return{g:0,n:p.n||p.u||'Conversa',u:p.u||'',o,k:''}};
const unOf=c=>(c.un&&c.un[IB.uid])||0,mnOf=c=>{const a=c.mn&&c.mn[IB.uid];return Array.isArray(a)?a.length:0};
function inboxPaint(){const me=IB.uid,rn=IB.list.filter(c=>rqIn(c)&&unOf(c)>0).length,/* v81: solicitação já vista (aberta) não conta mais como pendente */n=IB.list.filter(c=>!rqIn(c)).reduce((a,c)=>a+unOf(c),0)+rn+ivLive().length,/* v84: convite de grupo válido também conta */d=$('.dk-tab[data-t="public"]');if(d)d.classList.toggle('dot',n>0);
 const el=$('#inbox');if(el)el.innerHTML=`<button class="ib-row" id="ibrow" type="button"><svg class="i"><use href="#qchat"/></svg><b>Mensagens</b>${n?`<em aria-label="${n} não lidas">${n}</em>`:''}<span class="ib-ch" aria-hidden="true">›</span></button>`;msrPaint();rqPaint()}
$('#inbox').onclick=e=>{if(e.target.closest('#ibrow'))msrOpen()};
/* v74: bolinha verde "online" na lista (usa a mesma presença do cabeçalho; só escuta enquanto a lista está aberta) */
const OLN=new Map(),olOn=u=>{const r=OLN.get(u);return !!(r&&r.t&&Date.now()-r.t<100000)};
function olPaint(){$$('#msrl .ib-i[data-o]').forEach(b=>b.classList.toggle('ol',olOn(b.dataset.o)))}
function olWatch(){if(msr.hidden)return;const want=new Set(IB.list.filter(c=>!c.g).map(c=>cInfo(c).o).filter(Boolean));
 OLN.forEach((r,u)=>{if(!want.has(u)){r.un&&r.un();OLN.delete(u)}});
 want.forEach(u=>{if(OLN.has(u))return;const r={t:0,un:null};OLN.set(u,r);try{r.un=FB.onSnapshot(FB.doc(FB.db,'presence',u),s=>{r.t=s.exists()?+s.data().t||0:0;olPaint()},()=>{})}catch(e){}})}
function olStop(){OLN.forEach(r=>r.un&&r.un());OLN.clear()}
setInterval(()=>{if(!msr.hidden)olPaint()},20000);
/* ---------- central de mensagens (ecrã inteiro) ---------- */
const msr=$('#msr'),MF={f:'all',q:''};
function msrOpen(){inboxInit();msr.hidden=false;document.body.style.overflow='hidden';requestAnimationFrame(()=>msr.classList.add('on'));msrPaint()}
function msrShut(){olStop();msr.classList.remove('on');document.body.style.overflow='';setTimeout(()=>{msr.hidden=true},260)}
function msrPaint(){if(msr.hidden)return;$('#msrng').classList.toggle('vip',stRank()<2);const q=MF.q.trim().toLowerCase().replace(/^@/,''),all=IB.list.filter(c=>!rqIn(c)),nu=all.filter(c=>unOf(c)>0).length;
 $('.msr-t [data-f="un"]').textContent='Não lidas'+(nu?' '+nu:'');
 const L=all.filter(c=>MF.f=='un'?unOf(c)>0:MF.f=='gr'?c.g:true).filter(c=>{if(!q)return true;const i=cInfo(c);return(i.n+' '+i.u+' '+((c.last&&c.last.t)||'')).toLowerCase().includes(q)});
 $('#msrl').innerHTML=L.length?L.map(c=>{const i=cInfo(c),u=unOf(c);const ty=tyWho(c.id),pv=ty.length?`<small class="ty">${i.g?esc(tyName(c.p,ty))+' ':''}${TYD}</small>`:`<small>${c.last&&c.last.f==IB.uid?'Você: ':''}${lastHtml((c.last&&c.last.t)||'',i.k)}</small>`;
  return `<button class="ib-i${u?' nw':''}${!i.g&&olOn(i.o)?' ol':''}" type="button" data-id="${esc(c.id)}" data-pu="${esc(i.u)}" data-o="${esc(i.o)}"><span class="cht-av${i.g?' gp':''}${i.gp?' ph':''}"${i.gp?` style="background-image:url('${esc(i.gp)}')"`:(!i.g?` style="${ncSt(i.u||i.o)}"`:'')}>${i.gp?'':esc(ini(i.n))}</span><i class="ol-d" aria-hidden="true"></i><div><b>${esc(i.n)}</b>${pv}</div><time>${hhmm(tsOf(c.at))}</time>${mnOf(c)?'<em class="at" aria-label="Resposta a uma mensagem sua">@</em>':''}${u?`<em>${u}</em>`:''}</button>`}).join(''):
  `<div class="ib-box"><svg class="i"><use href="#qchat"/></svg><b>${q||MF.f!='all'?'Nada encontrado':'Nenhuma conversa ainda'}</b><span>${q||MF.f!='all'?'Tente outra pesquisa ou filtro.':'Toque no + para começar um chat.'+(stRank()<2?' Criar grupos é um recurso do plano Pro.':'')}</span>${!q&&MF.f=='all'&&stRank()<2?'<button class="btn p" data-go="planos" type="button">Ver planos</button>':''}</div>`;olWatch()}
$('#msrx').onclick=msrShut;new MutationObserver(()=>peersPaint($('#msrl'),'.ib-i','b')).observe($('#msrl'),{childList:true});$('#msrq').addEventListener('input',e=>{MF.q=e.target.value;msrPaint()});
$('.msr-t').onclick=e=>{const b=e.target.closest('[data-f]');if(!b)return;MF.f=b.dataset.f;$$('.msr-t button').forEach(x=>x.setAttribute('aria-selected',x==b));msrPaint()};
$('#msrl').onclick=e=>{const b=e.target.closest('.ib-i');if(!b)return;const c=IB.list.find(x=>x.id==b.dataset.id);if(!c)return;const i=cInfo(c);
 withSpin(b,async()=>{await wait(0)},350).then(()=>c.g?chOpen(null,'',c.gn,'',c):chOpen(i.o,i.u,i.n))};
/* v80: caixa de entrada (solicitações de conversa de contas grátis para perfis premium) */
function rqPaint(){const L=IB.list.filter(rqIn),V=IB.inv||[],n=L.filter(c=>unOf(c)>0).length+ivLive().length,b=$('#msrnb');/* v81: n = só as não vistas; a lista continua mostrando todas até aceitar */
 if(b){b.hidden=!n;b.textContent=n>9?'9+':n}
 const bn=$('#msnrqn'),s=$('#msnrqs');if(bn){bn.hidden=!n;bn.textContent=n}if(s)s.textContent=n?(n==1?'1 solicitação nova':n+' solicitações novas'):(L.length+V.length)?((L.length+V.length)==1?'1 solicitação':(L.length+V.length)+' solicitações'):'Nenhuma solicitação no momento';
 if(rqs.hidden)return;
 const ivH=V.map(v=>{const ex=ivExp(v);return`<button class="rq-iv${ex?' exp':''}" type="button" data-id="${esc(v.id)}"><span class="cht-av gp">${esc(ini(v.gn||'G'))}</span><div><b>${esc(v.gn||'Grupo')}</b><small>${ex?'Link expirado':'Convite para entrar no grupo · toque para ver'}</small></div><span class="rq-ch" aria-hidden="true">›</span></button>`}).join('');
 $('#rqsl').innerHTML=(L.length||V.length)?ivH+L.map(c=>{const i=cInfo(c),u=unOf(c);return`<button class="msn-i rq-i" type="button" data-id="${esc(c.id)}" data-pu="${esc(i.u)}"><span class="cht-av" style="${ncSt(i.u||i.o)}">${esc(ini(i.n))}</span><div><b>${esc(i.n)}</b><small>${lastHtml((c.last&&c.last.t)||'','')}</small></div>${u?`<em class="rq-n" aria-label="${u} não lidas">${u}</em>`:''}</button>`}).join(''):'<p class="pr-em">Nenhuma solicitação no momento.</p>';
 peersPaint($('#rqsl'),'.msn-i','b')}
function gvAnswer(b,id,done){const v=(IB.inv||[]).find(x=>x.id==id);if(!v)return;const yes=b.dataset.a=='yes',me=FB.auth.currentUser,P=S.profile||{};
 withSpin(b,async()=>{
  if(yes)await Promise.race([FB.updateDoc(FB.doc(FB.db,'chats',v.cid),{ps:FB.arrayUnion(me.uid),['p.'+me.uid]:{u:P.username||'',n:P.name||S.u.name||''}}),wait(8000).then(()=>{throw{code:'timeout'}})]);
  await FB.deleteDoc(FB.doc(FB.db,'ginv',v.id)).catch(()=>{})},500)
 .then(()=>{toast(yes?'Você entrou no grupo.':'Convite recusado.',2400);if(done)done()})
 .catch(er=>{console.error('convite:',er);toast(yes?'Não foi possível entrar. O grupo pode estar cheio ou ter sido apagado.':'Não foi possível recusar.',4200)})}
/* v84: o convite abre como um grupo normal (tela cheia, só leitura) com Aceitar/Recusar no topo. Sem detalhes do grupo. */
function gvOpen(id){const v=(IB.inv||[]).find(x=>x.id==id);if(!v)return;
 if(ivExp(v)){toast('Link expirado.',3000);return}
 prsHide(rqs);prsHide(msn);chOpen(null,'',v.gn||'Grupo','',{id:v.cid,ps:[],gn:v.gn||'Grupo',p:{}},v.id)}
$('#chtgv').onclick=e=>{const b=e.target.closest('[data-a]');if(!b||!CH.iv)return;const id=CH.iv,v=(IB.inv||[]).find(x=>x.id==id),cid=CH.cid;
 if(!v){toast('Este convite não está mais disponível.',3200);chShut();return}
 if(ivExp(v)){toast('Link expirado.',3200);chShut();return}
 const yes=b.dataset.a=='yes';
 gvAnswer(b,id,()=>{if(yes){if(CH.cid==cid){CH.iv='';chLock()}}else if(CH.cid==cid)chShut()})};
$('#msnrq').onclick=()=>{rqs.hidden=false;rqPaint();requestAnimationFrame(()=>rqs.classList.add('on'))};
rqs.onclick=e=>{if(e.target.closest('[data-x]')){prsHide(rqs);return}const gb=e.target.closest('.rq-iv');if(gb){gvOpen(gb.dataset.id);return}const b=e.target.closest('.rq-i');if(!b)return;const c=IB.list.find(x=>x.id==b.dataset.id);if(!c)return;const i=cInfo(c);
 prsHide(rqs);prsHide(msn);chOpen(i.o,i.u,i.n)};
/* banner dentro da conversa: Aceitar / Denunciar */
$('#chtrqa').onclick=e=>{const cid=CH.cid;if(!cid||CH.g||!CH.rq)return;
 withSpin(e.currentTarget,async()=>{await Promise.race([FB.updateDoc(FB.doc(FB.db,'chats',cid),{rq:''}),wait(8000)]);if(CH.cid==cid){CH.rq='';chLock()}},500)
  .then(()=>toast('Solicitação aceita. Agora é uma conversa normal.',2800)).catch(er=>toast(er&&er.code=='permission-denied'?'Sem permissão. Publique o firestore.rules atualizado no Firebase.':'Não foi possível aceitar. Tente de novo.',4200))};
$('#chtrqd').onclick=async e=>{const btn=e.currentTarget,cid=CH.cid,me=FB.auth.currentUser;if(!cid||CH.g||CH.rep||!me)return;if(!(await cfm({t:'Denunciar esta pessoa?',m:'Nossa equipe vai analisar a conversa.',ok:'Denunciar',i:'shield',d:true})))return;
 const ev=(CH.msgs||[]).filter(m=>m.f!=me.uid&&m.t).slice(-5).map(m=>String(m.t).slice(0,200));
 withSpin(btn,async()=>{await Promise.race([FB.setDoc(FB.doc(FB.collection(FB.db,'reports')),{by:me.uid,on:CH.to,cid,ev,at:FB.serverTimestamp()}),wait(8000)]);CH.rep=true},500)
  .then(()=>{chLock();toast('Denúncia enviada. Obrigado.',2800)}).catch(er=>toast(er&&er.code=='permission-denied'?'Sem permissão. Publique o firestore.rules atualizado no Firebase.':'Não foi possível denunciar. Tente de novo.',4200))};
/* ---------- v85: notificações (sino da Início) ----------
   notifs/{uid}              {seen: ms}  → até onde a pessoa já viu
   notifs/{uid}/items/{id}   {t, at, f?, u?, n?, pg?, p?, d?, pu?}
   t: like · follow (alguém)  |  gift (plano ganho do Quantum) · sub (plano assinado) · end (plano terminou/removido) · vf (verificação) · restrict (conta) */
const NT={uid:'',list:[],seen:0,mk:0,un:null,us:null,f:'all'},ntf=$('#ntf');
const ntNm=x=>String(x.n||(x.u?'@'+x.u:'Alguém')),
 ntDt=ms=>new Date(ms).toLocaleDateString([],{day:'numeric',month:'long',year:'numeric'});
function ntView(x){const nm='<b>'+esc(ntNm(x))+'</b>',pl=PLN[x.p]||'',at=x.u?'@'+x.u:'';
 switch(x.t){
  case 'like':return{k:'act',c:'#FF4D6D',i:'heart',lk:1,h:nm+' curtiu a sua página',s:at};
  case 'follow':return{k:'act',c:'#1E6BFF',i:'userplus',h:nm+' começou a seguir você',s:at};
  case 'gift':return{k:'acc',c:'#9B51E0',g:'linear-gradient(135deg,#9B51E0,#FF7AD9)',i:'gift',h:'Você ganhou o plano <b>'+esc(pl)+'</b>',s:'Presente do Quantum · '+(x.d&&x.d!='permanente'?'por '+x.d:'acesso permanente')};
  case 'sub':return{k:'acc',c:'#1E6BFF',g:'linear-gradient(135deg,#1E6BFF,#3CCDFF)',i:x.p=='pro'?'cr':'bolt',h:'Plano <b>'+esc(pl)+'</b> assinado',s:x.d?'Válido por '+x.d:'Obrigado por apoiar o Quantum'};
  case 'end':return x.d=='rm'?{k:'acc',c:'#F59E0B',i:'clock',h:'O seu plano <b>'+esc(pl)+'</b> foi removido',s:'A conta voltou ao plano Gratuito'}
   :{k:'acc',c:'#F59E0B',i:'clock',h:'O seu plano <b>'+esc(pl)+'</b> terminou',s:x.pu?'Terminou em '+ntDt(x.pu):'Faça upgrade para continuar com os recursos'};
  case 'vf':return x.d=='ok'?{k:'acc',c:'#1d9bf0',i:'verified',h:'A sua página foi <b>verificada</b>',s:'O selo azul já aparece no seu perfil'}
   :x.d=='no'?{k:'acc',c:'#E5484D',i:'verified',h:'Pedido de verificação <b>recusado</b>',s:'Toque para enviar de novo'}
   :{k:'acc',c:'#8A93A6',i:'verified',h:'O seu selo de verificação foi <b>removido</b>',s:''};
  case 'restrict':return x.d=='off'?{k:'acc',c:'#22A559',i:'shield',h:'A restrição da sua conta foi <b>removida</b>',s:'Você já pode usar o Quantum normalmente'}
   :{k:'acc',c:'#E5484D',i:'shield',h:'A sua conta foi <b>restrita</b>',s:'Fale com o suporte do Quantum'};
 }return null}
function ntAgo(ms){const m=Math.floor((Date.now()-ms)/60000);if(m<1)return'agora';if(m<60)return m+' min';const h=Math.floor(m/60);if(h<24)return h+' h';return new Date(ms).toLocaleDateString([],{day:'2-digit',month:'short'})}
function ntDay(ms){const s=x=>new Date(x.getFullYear(),x.getMonth(),x.getDate()).getTime(),k=Math.round((s(new Date())-s(new Date(ms)))/864e5);return k<=0?'Hoje':k==1?'Ontem':k<7?'Esta semana':'Mais antigas'}
const ntUn=()=>NT.list.filter(x=>ntView(x)&&tsOf(x.at)>NT.seen).length;
function ntBadge(){const n=ntUn(),b=$('#hmntn'),h=$('#hmnt');if(b){b.hidden=!n;b.textContent=n>9?'9+':n}
 if(h){h.classList.toggle('has',n>0);h.setAttribute('aria-label',n?'Notificações, '+n+(n==1?' nova':' novas'):'Notificações')}
 const d=$('.dk-tab[data-t="profile"]');if(d)d.classList.toggle('dot',n>0)}
function ntInit(){const me=FB&&FB.auth&&FB.auth.currentUser;if(!me||!S.u||NT.uid==me.uid)return;
 ntStop();NT.uid=me.uid;NT.list=[];NT.seen=0;
 try{NT.us=FB.onSnapshot(FB.doc(FB.db,'notifs',me.uid),s=>{NT.seen=s.exists()?+s.data().seen||0:0;ntBadge();ntPaint()},e=>console.warn('notificações:',e))}catch(e){}
 try{NT.un=FB.onSnapshot(FB.query(FB.collection(FB.db,'notifs',me.uid,'items'),FB.orderBy('at','desc'),FB.limit(50)),
  s=>{NT.list=s.docs.map(d=>({id:d.id,...d.data({serverTimestamps:'estimate'})}));ntBadge();ntPaint();if(!ntf.hidden)ntSeen()},e=>console.warn('notificações:',e))}catch(e){}}
function ntStop(){if(NT.un){NT.un();NT.un=null}if(NT.us){NT.us();NT.us=null}NT.uid=''}
function ntSeen(){if(!NT.uid||!NT.list.length)return;const m=Math.max(...NT.list.map(x=>tsOf(x.at)));if(m<=NT.seen)return;NT.seen=m;ntBadge();
 FB.setDoc(FB.doc(FB.db,'notifs',NT.uid),{seen:m}).catch(e=>console.warn('notificações:',e))}
function ntRow(x,v){const nw=tsOf(x.at)>NT.mk,so=x.t=='like'||x.t=='follow',
 lead=so?`<span class="nt-av"><span class="cht-av" style="${ncSt(x.u||x.f)}">${esc(ini(ntNm(x)))}</span><span class="nt-bd"><svg class="i"><use href="#${v.i}"/></svg></span></span>`
  :`<span class="nt-ic"><svg class="i"><use href="#${v.i}"/></svg></span>`;
 return`<button type="button" class="nt-i${nw?' nw':''}${v.lk?' lk':''}" data-id="${esc(x.id)}"${so&&x.u?` data-pu="${esc(x.u)}"`:''} style="--c:${v.c}${v.g?';--g:'+v.g:''}">${lead}<div class="nt-b"><p>${v.h}</p>${v.s?`<small>${esc(v.s)}</small>`:''}</div><time>${ntAgo(tsOf(x.at))}</time></button>`}
function ntPaint(){if(ntf.hidden)return;const el=$('#ntfl'),A=NT.list.map(x=>({x,v:ntView(x)})).filter(o=>o.v);
 $('#ntfclr').hidden=!NT.list.length;
 const L=A.filter(o=>NT.f=='all'||o.v.k==NT.f);
 if(!L.length){el.innerHTML=`<div class="ib-box"><svg class="i"><use href="#bell"/></svg><b>${A.length?'Nada por aqui':'Nenhuma notificação ainda'}</b><span>${A.length?'Tente outro filtro.':'Curtidas, novos seguidores, planos, verificação e avisos da sua conta aparecem aqui.'}</span></div>`;return}
 let last='',h='';L.forEach(o=>{const g=ntDay(tsOf(o.x.at));if(g!=last){h+=`<h3 class="nt-g">${g}</h3>`;last=g}h+=ntRow(o.x,o.v)});
 el.innerHTML=h;peersPaint(el,'.nt-i','b')}
function ntOpen(){ntInit();NT.f='all';NT.mk=NT.seen;$$('.nt-t button').forEach(b=>b.setAttribute('aria-selected',b.dataset.f=='all'));
 ntf.hidden=false;document.body.style.overflow='hidden';requestAnimationFrame(()=>ntf.classList.add('on'));ntPaint();$('#ntfl').scrollTop=0;
 const u=NT.uid;setTimeout(()=>{if(!ntf.hidden&&NT.uid==u)ntSeen()},900)}
function ntClose(){ntf.classList.remove('on');document.body.style.overflow='';setTimeout(()=>{if(!ntf.classList.contains('on'))ntf.hidden=true},260)}
$('#hmnt').onclick=ntOpen;$('#ntfx').onclick=ntClose;
$('.nt-t').onclick=e=>{const b=e.target.closest('[data-f]');if(!b)return;NT.f=b.dataset.f;$$('.nt-t button').forEach(x=>x.setAttribute('aria-selected',x==b));ntPaint()};
$('#ntfl').onclick=e=>{const b=e.target.closest('.nt-i');if(!b)return;const x=NT.list.find(y=>y.id==b.dataset.id);if(!x)return;
 if(x.t=='like'||x.t=='follow'){if(x.u){xpv.style.zIndex='9800';xpOpen(x.u)}return}
 if(x.t=='gift'||x.t=='sub'||x.t=='end'){ntClose();go('plan');return}
 if(x.t=='vf'&&x.d=='no'){ntClose();go('look');vfOpen()}};
$('#ntfclr').onclick=async()=>{if(!NT.uid||!NT.list.length)return;
 if(!(await cfm({t:'Limpar notificações?',m:'Todas as notificações serão apagadas.',ok:'Limpar',i:'trash',d:true})))return;
 try{const b=FB.writeBatch(FB.db),me=NT.uid;NT.list.forEach(x=>b.delete(FB.doc(FB.db,'notifs',me,'items',x.id)));await Promise.race([b.commit(),wait(8000)])}
 catch(er){toast(er&&er.code=='permission-denied'?'Sem permissão. Publique o firestore.rules atualizado no Firebase.':'Não foi possível limpar. Tente de novo.',4200)}};
/* gravação dos avisos */
function ntTo(to,o){if(!to||!FB)return Promise.resolve();return FB.setDoc(FB.doc(FB.collection(FB.db,'notifs',to,'items')),{...o,at:FB.serverTimestamp()}).catch(e=>console.warn('notificação:',e))}/* admin → pessoa */
function ntEnd(pp,pu){try{if(!uid||!FB||!FB.auth||!FB.auth.currentUser||!PL[pp]||pp=='free'||!pu)return;
 FB.setDoc(FB.doc(FB.db,'notifs',uid,'items','end_'+pu),{t:'end',p:pp,d:'exp',pu,at:FB.serverTimestamp()}).catch(()=>{})}catch(e){}}/* VIP venceu: 1 aviso por vencimento (id fixo) */
async function ntSend(t,pg){try{const me=FB.auth.currentUser,P=S.profile||{};if(!me||!pg)return;
 const us=await FB.getDoc(FB.doc(FB.db,'usernames',pg));if(!us.exists())return;const to=us.data().uid;if(!to||to==me.uid)return;
 await FB.setDoc(FB.doc(FB.db,'notifs',to,'items',t+'_'+me.uid),{t,f:me.uid,u:P.username||'',n:String(P.name||(S.u&&S.u.name)||'').slice(0,60),pg,at:FB.serverTimestamp()})}
 catch(e){/* já avisou antes (1 por pessoa) ou regras ainda não publicadas: segue sem barulho */}}
/* novo chat / novo grupo */
const msn=$('#msn'),MN={m:'chat',sel:new Map(),t:0};
const isProRaw=r=>(+r.r||0)>=2&&(!(+r.pu)||+r.pu>Date.now());
async function msnFind(q){q=q.trim().toLowerCase().replace(/^@/,'');const me=myU(),out=new Map();if(!q)return[];
 const toks=xpToks(q),un=q.replace(/\s+/g,''),add=(u,n)=>{if(u&&u!=me&&PUBR.test(u)&&!out.has(u))out.set(u,{u,n:n||u})};
 /* 1) o que já está carregado (feed/pesquisa do Público) */
 [...XP.feed,...XP.res].forEach(d=>{if(d.u.includes(un)||String(d.n||'').toLowerCase().includes(q)||(toks.length&&xpMatch(d,toks)))add(d.u,d.n)});
 /* 2) servidor: vitrine (nome/@ por prefixo) + @usernames por prefixo — basta 1 letra */
 try{await fbReady();const jobs=[],tk=toks.reduce((a,b)=>b.length>a.length?b:a,'').slice(0,12);
  if(tk)jobs.push(FB.getDocs(FB.query(FB.collection(FB.db,'dir'),FB.where('s','array-contains',tk),FB.limit(30))).then(r=>r.docs.forEach(s=>{const d=xpDoc(s);if(d&&xpMatch(d,toks))add(d.u,d.n)})).catch(e=>console.warn('busca dir:',e)));
  if(/^[a-z0-9_]+$/.test(un))jobs.push(FB.getDocs(FB.query(FB.collection(FB.db,'usernames'),FB.where(FB.documentId(),'>=',un),FB.where(FB.documentId(),'<=',un+'\uf8ff'),FB.limit(15))).then(r=>r.docs.forEach(s=>add(s.id))).catch(e=>console.warn('busca @:',e)));
  await Promise.all(jobs)}catch(e){console.warn('busca:',e)}
 /* 3) @ exato (funciona mesmo sem o aviso acima das regras) */
 if(PUBR.test(un)&&un!=me&&!out.has(un)){try{if(await uidOf(un))add(un)}catch(e){}}
 const ex=MN.m=='add'?new Set((CH.ps||[]).map(id=>(CH.p[id]||{}).u).filter(Boolean)):null;const sc=x=>x.u.startsWith(un)||String(x.n||'').toLowerCase().startsWith(q)?0:1;return[...out.values()].filter(x=>!ex||!ex.has(x.u)).sort((x,y)=>sc(x)-sc(y)||(xpL(y.u).n||0)-(xpL(x.u).n||0)||x.u.localeCompare(y.u)).slice(0,20)}
async function msnPaint(){const q=$('#msnq').value,my=++MN.t,L=await msnFind(q);if(my!=MN.t)return;
 $('#msnl').innerHTML=L.length?L.map(x=>`<button class="msn-i${MN.sel.has(x.u)?' on':''}" type="button" data-pu="${esc(x.u)}" data-u="${esc(x.u)}" data-n="${esc(x.n)}"><span class="cht-av" style="${ncSt(x.u)}">${esc(ini(x.n))}</span><div><b>${esc(x.n)}</b><small>@${esc(x.u)}</small></div><i class="msn-ck" aria-hidden="true"></i></button>`).join(''):'<p class="pr-em">'+(!q.trim()?'Digite o nome ou o @ da pessoa para procurar.':'Ninguém encontrado. Confira o nome ou o @.')+'</p>';
 peersPaint($('#msnl'),'.msn-i','b');const g=MN.m!='chat';$('#msns').hidden=!g||!MN.sel.size;$('#msns').innerHTML=[...MN.sel.values()].map(x=>`<span>${esc(x.n)}</span>`).join('');$('#msnok').hidden=!g;$('#msnok').disabled=MN.m=='add'?!MN.sel.size:(!MN.sel.size||!$('#msngn').value.trim())}
function msnOpen(m){MN.m=m;MN.sel.clear();$('#msnt').textContent=m=='group'?'Novo grupo':m=='add'?'Adicionar membros':'Novo chat';$('#msnok').textContent=m=='add'?'Adicionar':'Criar grupo';msn.toggleAttribute('data-g',m!='chat');$('#msngn').hidden=m!='group';$('#msngn').value='';$('#msnq').value='';$('#msnrq').hidden=m!='chat';rqPaint();msn.hidden=false;requestAnimationFrame(()=>msn.classList.add('on'));msnPaint()}
$('#msrnc').onclick=()=>msnOpen('chat');
$('#msrng').onclick=()=>{if(stRank()<2){msrShut();SELP='pro';location.hash='planos';return}msnOpen('group')};
$('#msnq').addEventListener('input',()=>{clearTimeout(MN.d);MN.d=setTimeout(msnPaint,220)});$('#msngn').addEventListener('input',msnPaint);
msn.onclick=e=>{if(e.target.closest('[data-x]')){prsHide(msn);return}
 const b=e.target.closest('.msn-i');if(!b)return;const u=b.dataset.u,n=b.dataset.n;
 if(MN.m!='chat'){const cap=MN.m=='add'?20-(CH.ps||[]).length:19;if(MN.sel.has(u))MN.sel.delete(u);else if(MN.sel.size<cap)MN.sel.set(u,{u,n});else toast('Limite de 20 pessoas por grupo.');b.classList.toggle('on',MN.sel.has(u));msnPaint();return}
 withSpin(b,async()=>{const id=await uidOf(u);if(!id)throw 0;return id},500)
  .then(id=>{if(!id)return;prsHide(msn);chOpen(id,u,n)}).catch(er=>toast('Não foi possível abrir a conversa.',3600))};
$('#msnok').onclick=e=>{if(MN.m=='add'){gAddMembers(e.currentTarget);return}const nm=$('#msngn').value.trim();if(!MN.sel.size||!nm)return;
 withSpin(e.currentTarget,async()=>{const me=FB.auth.currentUser,P=S.profile||{},ids=[],p={[me.uid]:{u:P.username||'',n:P.name||S.u.name||''}};
  const inv=[];/* v81: perfil premium não entra direto: recebe solicitação e NÃO aparece em membros */
  for(const x of MN.sel.values()){const id=await uidOf(x.u);if(!id)continue;if(await rpOf(x.u))inv.push({id,u:x.u,n:x.n});else{ids.push(id);p[id]={u:x.u,n:x.n}}}
  if(!ids.length&&!inv.length)throw 0;const ref=FB.doc(FB.collection(FB.db,'chats')),ps=[me.uid,...ids];
  const gr={m:true,i:true,a:true};await Promise.race([FB.setDoc(ref,{ps,to:P.username||'',g:true,gn:nm,p,last:{t:'Grupo criado',f:me.uid},at:FB.serverTimestamp(),un:{},ad:[me.uid],ow:me.uid,gr}),wait(8000)]);const iv=inv.length?await gInvite(ref.id,nm,inv):{ok:0,err:null};return{id:ref.id,ps,gn:nm,p,ad:[me.uid],ow:me.uid,gr,to:P.username||'',_iv:{n:inv.length,ok:iv.ok,err:iv.err}}},600)
 .then(g=>{if(!g)return;prsHide(msn);const iv=g._iv;delete g._iv;chOpen(null,'',nm,'',g);gInvToast(iv)}).catch(er=>{console.error('criar grupo:',er);toast(er&&er.code=='permission-denied'?'Sem permissão para criar grupo. Só contas Pro podem, e o firestore.rules atualizado precisa estar publicado.':'Não foi possível criar o grupo.',5200)})};
/* v89: fecha folhas inferiores (chat, grupos, caixa de entrada) e @ do próprio usuário */
function prsHide(m){m.classList.remove('on');setTimeout(()=>{m.hidden=true},240)}
const myU=()=>(S.profile&&S.profile.username)||'';
document.addEventListener('keydown',e=>{if(e.key!='Escape')return;if(!mpk.hidden){mpkClose();return}if(!mv.hidden){mvClose();return}if(!fwd.hidden){prsHide(fwd);return}if(!gi.hidden){giClose();return}if(!cht.hidden)chShut()});


/* ===== v73: áudio, apagar/editar, bloqueio de 1 mensagem (grátis → premium), presença ===== */
const AUD={r:null};
function fmtT(s){return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}
async function auStart(){if(!navigator.mediaDevices||!window.MediaRecorder){toast('Este navegador não grava áudio.',3200);return}
 let st;try{st=await navigator.mediaDevices.getUserMedia({audio:true})}catch(e){toast('Permita o microfone para gravar áudio.',3600);return}
 const mt=['audio/webm;codecs=opus','audio/mp4','audio/webm'].find(x=>MediaRecorder.isTypeSupported(x)),r=new MediaRecorder(st,mt?{mimeType:mt,audioBitsPerSecond:16000}:{audioBitsPerSecond:16000});
 Object.assign(AUD,{r,st,ch:[],bytes:0,t0:Date.now(),send:false,mt:r.mimeType||mt||'audio/webm'});
 r.ondataavailable=e=>{if(e.data&&e.data.size){AUD.ch.push(e.data);AUD.bytes+=e.data.size;if(AUD.bytes>130000){toast('Limite do áudio atingido.',2400);auStop(true)}}};
 r.onstop=()=>{AUD.st.getTracks().forEach(t=>t.stop());clearInterval(AUD.iv);const send=AUD.send,d=Math.max(1,Math.round((Date.now()-AUD.t0)/1000)),bl=new Blob(AUD.ch,{type:AUD.mt});AUD.r=null;$('#chtrec').hidden=true;$('#chtc').hidden=false;
  if(!send)return;const fr=new FileReader();fr.onload=()=>chSend({a:fr.result,d});fr.readAsDataURL(bl)};
 r.start(1000);$('#chtrec').hidden=false;$('#chtc').hidden=true;$('#chtrt').textContent='0:00';AUD.iv=setInterval(()=>{const s=Math.round((Date.now()-AUD.t0)/1000);$('#chtrt').textContent=fmtT(s);if(s>=90)auStop(true)},500)}
function auStop(send){if(!AUD.r||AUD.r.state=='inactive')return;AUD.send=!!send;AUD.r.stop()}
$('#chtmic').onclick=auStart;$('#chtrx').onclick=()=>auStop(false);$('#chtrs').onclick=()=>auStop(true);
chin.addEventListener('input',chMode);
chin.addEventListener('input',()=>tySend(!!chin.value.trim()));
$('#chtedx').onclick=chEditEnd;
/* menu da mensagem: copiar / editar / apagar */
const cmm=$('#cmm');
function msgCopy(m){navigator.clipboard&&navigator.clipboard.writeText(m.t).then(()=>toast('Copiado!',1600),()=>{})}
function msgEdit(m){CH.reply=null;rpBar();CH.edit=m;chin.value=m.t;chGrow();$('#chted').hidden=false;chMode();chin.focus()}
async function msgRemove(m){if(!(await cfm({t:'Apagar mensagem?',m:'Ela será apagada para todos na conversa.',ok:'Apagar',i:'trash',d:true})))return;const cid=CH.cid,i=CH.msgs.findIndex(x=>x.id==m.id);
 FB.deleteDoc(FB.doc(FB.db,'chats',cid,'m',m.id)).then(()=>{if(i==CH.msgs.length-1){const p=CH.msgs[i-1];FB.updateDoc(FB.doc(FB.db,'chats',cid),{last:{t:p?(p.a?'🎤 Áudio':p.t||(isVid(p)?'🎥 Vídeo':'📷 Foto')):'Mensagem apagada',f:p?p.f:FB.auth.currentUser.uid}}).catch(()=>{})}}).catch(()=>toast('Não foi possível apagar.'))}
/* popover pequeno, ao lado da mensagem (perto do toque) */
function cmPop(row,items,ev){const a=$('.cm',row)||row;edM.classList.add('cmp');
 edM.innerHTML=items.map((it,k)=>`<button class="ed-mi${it.c?' '+it.c:''}" type="button" role="menuitem" data-k="${k}">${I(it.i)}<span>${it.t}</span></button>`).join('');
 edM._it=items;edM._a=a;edM.hidden=false;
 const r=a.getBoundingClientRect(),w=edM.offsetWidth,h=edM.offsetHeight,mine=row.classList.contains('me');
 let x=mine?r.right-w:r.left,y=(ev&&ev.clientY!=null?ev.clientY:r.bottom)+6;
 if(y+h>innerHeight-12)y=(ev&&ev.clientY!=null?ev.clientY:r.top)-h-6;
 edM.style.top=Math.max(12,Math.min(y,innerHeight-h-12))+'px';edM.style.left=Math.min(Math.max(12,x),innerWidth-w-12)+'px'}
chl.addEventListener('scroll',()=>{if(!edM.hidden)edPopX()},{passive:true});
chl.onclick=e=>{if(e.target.closest('a,.ap-b,.ap-w'))return;
 const dg=e.target.closest('.dlg');if(dg){dlToggle(dg.closest('.dlw'));return}
 const rpc=e.target.closest('.rpc');if(rpc){const rr=rpc.closest('.cr');if(rr)rcGo(rr.dataset.id);return}
 const rc=e.target.closest('.rxc');if(rc){const rw=rc.closest('.cr'),mm=rw&&CH.msgs.find(x=>x.id==rw.dataset.id);if(mm&&!mm._p)msgReact(mm,rc.dataset.e);return}
 const rq=e.target.closest('.rq');if(rq){rpGo(rq.dataset.rq);return}
 if(Date.now()-(SW.t||0)<450)return;
 const row=e.target.closest('.cr');if(!row)return;
 const av=e.target.closest('.cm-av');if(av){const u=av.dataset.pu;if(u){xpv.style.zIndex='9800';xpOpen(u)}return}
 const m=CH.msgs.find(x=>x.id==row.dataset.id);if(!m||m._p)return;
 if((e.target.closest('img[data-v]')||e.target.closest('.vw')&&isVid(m))&&okI(m.i)){mvOpen(m);return}
 const me=FB.auth.currentUser.uid,mine=m.f==me,can=m.t&&!m.a&&!m.i&&Date.now()-tsOf(m.at)<15*60000,adm=CH.g&&gIsAdm(me),med=(okI(m.i)&&!imgGate(m))||okA(m.a),it=[];
 it.push({i:'rpl',t:'Responder',f:()=>msgReply(m)});
 if(okI(m.i)&&!imgGate(m)&&!isVid(m))it.push({i:'img',t:'Abrir foto',f:()=>mvOpen(m)});
 if(m.t)it.push({i:'cpy',t:'Copiar',f:()=>msgCopy(m)});
 if(med){it.push({i:'dl',t:'Baixar',f:()=>mediaSave(m)});it.push({i:'share',t:'Compartilhar',f:()=>mediaShare(m)})}
 it.push({i:'fwi',t:'Encaminhar',f:()=>fwdOpen(m)});
 if(mine&&can)it.push({i:'pen',t:'Editar',f:()=>msgEdit(m)});
 if(mine||adm)it.push({i:'trash',t:'Apagar',c:'dg',f:()=>msgRemove(m)});
 msgMenu(row,it,m)};
cmm.onclick=async e=>{if(e.target.closest('[data-x]')){prsHide(cmm);return}const b=e.target.closest('[data-a]');if(!b)return;const m=CH.msgs.find(x=>x.id==cmm.dataset.id);if(!m)return;
 if(b.dataset.a=='op'){prsHide(cmm);mvOpen(m);return}
 if(b.dataset.a=='dl'){prsHide(cmm);mediaSave(m);return}
 if(b.dataset.a=='sh'){prsHide(cmm);mediaShare(m);return}
 if(b.dataset.a=='fw'){prsHide(cmm);fwdOpen(m);return}
 if(b.dataset.a=='cp'){navigator.clipboard&&navigator.clipboard.writeText(m.t).then(()=>toast('Copiado!',1600),()=>{});prsHide(cmm);return}
 if(b.dataset.a=='ed'){prsHide(cmm);CH.edit=m;chin.value=m.t;chGrow();$('#chted').hidden=false;chMode();chin.focus();return}
 if(b.dataset.a=='rm'&&await cfm({t:'Apagar mensagem?',m:'Ela será apagada para todos na conversa.',ok:'Apagar',i:'trash',d:true}))withSpin(b,async()=>{const cid=CH.cid,i=CH.msgs.findIndex(x=>x.id==m.id);await Promise.race([FB.deleteDoc(FB.doc(FB.db,'chats',cid,'m',m.id)),wait(8000)]);
   if(i==CH.msgs.length-1){const p=CH.msgs[i-1];FB.updateDoc(FB.doc(FB.db,'chats',cid),{last:{t:p?(p.a?'🎤 Áudio':p.t||(isVid(p)?'🎥 Vídeo':'📷 Foto')):'Mensagem apagada',f:p?p.f:FB.auth.currentUser.uid}}).catch(()=>{})}},450)
  .then(()=>prsHide(cmm)).catch(()=>toast('Não foi possível apagar.'))};
/* bloqueio: conta grátis só envia 1 mensagem a perfil premium (libera quando a pessoa responde ou com upgrade) */
function chLock(){const me=FB.auth.currentUser&&FB.auth.currentUser.uid,sc=CH.sc||{},mine=sc[me]||0,
 pend=!CH.g&&!!CH.rq&&CH.rq==me,inc=!CH.g&&!!CH.rq&&CH.rq!=me,will=!CH.g&&!CH.ex&&stRank()<1&&!!CH.rp&&!!CH.sk,
 lock=(pend||will)&&mine>=1,show=will&&mine<1,lk=$('#chtlk');
 let gm=false,gi_=false,ga=false;if(CH.g&&CH.gd&&!gIsAdm(me)){const r=CH.gd.gr||{};gm=r.m===false;gi_=r.i===false;ga=r.a===false}
 const dis=lock||gm,gnote=gm?'Só administradores podem enviar mensagens neste grupo.':(gi_||ga)?(gi_&&ga?'Neste grupo, só administradores podem enviar fotos e áudios.':gi_?'Neste grupo, só administradores podem enviar fotos.':'Neste grupo, só administradores podem enviar áudios.'):'';
 chin.disabled=dis;['chtem','chtsd'].forEach(i=>{$('#'+i).disabled=dis});$('#chtph').disabled=dis||gi_;$('#chtmic').disabled=dis||ga;$('#chtc').classList.toggle('lk',dis);
 lk.hidden=!(lock||show||gnote);lk.className='cht-lk'+(lock?' bl':'');
 lk.innerHTML=lock?'<b>Solicitação enviada</b><span>Você só pode enviar <b>1 mensagem</b> até a pessoa aceitar. Mesmo que ela responda, a conversa só é liberada depois que ela aceitar.</span>':(gnote?'<span>'+gnote+'</span>':(show?'<span>Sua conta é grátis, então a mensagem vai como <b>solicitação</b> na caixa de entrada de '+esc(CH.tn)+'. Você poderá enviar <b>1 mensagem</b> até a pessoa aceitar.</span>':''));
 cht.classList.toggle('iv',!!CH.iv);$('#chtgv').hidden=!CH.iv;/* v84 */
 const rb=$('#chtrq');rb.hidden=!inc;if(inc){$('#chtrqn').textContent=CH.tn;const d=$('#chtrqd');d.disabled=!!CH.rep;d.textContent=CH.rep?'Denunciado':'Denunciar'}}
$('#chtlk').addEventListener('click',e=>{if(e.target.closest('[data-go]')){chShut(true);if(!msr.hidden){msr.hidden=true;msr.classList.remove('on')}if(!xpv.hidden)xpClose();document.body.style.overflow=''}});
$('#chtwho').onclick=()=>{if(CH.iv)return;/* v84: convite = sem detalhes do grupo */if(CH.g){giOpen();return}if(!CH.tu)return;xpv.style.zIndex='9800';xpOpen(CH.tu)};
/* presença: "online" / "visto há…" */
function presBeat(){const me=FB.auth&&FB.auth.currentUser;if(!me||document.visibilityState!='visible')return;FB.setDoc(FB.doc(FB.db,'presence',me.uid),{t:Date.now()}).catch(()=>{})}
let presOn=false;function presStart(){if(presOn)return;presOn=true;presBeat();setInterval(presBeat,45000);document.addEventListener('visibilitychange',presBeat)}

/* ===== v75: foto/áudio — abrir, baixar, compartilhar, encaminhar · grupos completos ===== */
const mv=$('#mv'),fwd=$('#fwd'),gi=$('#gi'),gib=$('#gib'),gma=$('#gma'),GI={edit:false,val:undefined},FW={m:null,sel:new Set()};
const EXT={'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','audio/webm':'webm','audio/mp4':'m4a','audio/ogg':'ogg','audio/mpeg':'mp3','video/mp4':'mp4','video/webm':'webm','video/quicktime':'mov','video/ogg':'ogv','video/3gpp':'3gp'};
function dataBlob(d){try{const k=d.indexOf(','),h=d.slice(5,k),b64=/;base64$/.test(h),mt=h.split(';')[0]||'application/octet-stream',raw=d.slice(k+1),bin=b64?atob(raw):decodeURIComponent(raw),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);return new Blob([u],{type:mt})}catch(e){return null}}
/* v91: a mídia agora é uma URL (Cloudinary); data: continua funcionando para mensagens antigas */
async function mediaBlob(m){const u=m.i||m.a||'';if(/^data:/.test(u))return dataBlob(u);if(isVid(m)){const lb=await vidLocal(u);if(lb)return lb}try{const r=await fetch(u);if(!r.ok)throw 0;return await r.blob()}catch(e){return null}}
const mediaName=(m,bl)=>'quantum-'+(m.i?(isVid(m)?'video':'foto'):'audio')+'-'+new Date(tsOf(m.at)).toISOString().slice(0,19).replace(/[-:T]/g,'')+'.'+(EXT[bl.type]||(m.i?(isVid(m)?'mp4':'jpg'):'webm'));
async function mediaSave(m){toast('Baixando…',1800);const bl=await mediaBlob(m);
 if(!bl){/* sem CORS/sem rede para ler o arquivo: o Cloudinary entrega com Content-Disposition: attachment (fl_attachment) */
  if(cldOk(m.i)&&m.i.includes('/upload/')){const a=document.createElement('a');a.href=m.i.replace('/upload/','/upload/fl_attachment/');a.rel='noopener';a.download='';document.body.appendChild(a);a.click();a.remove();return}
  toast('Não foi possível baixar.');return}
 const url=URL.createObjectURL(bl),a=document.createElement('a');a.href=url;a.download=mediaName(m,bl);document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),8000)}
async function mediaShare(m){const bl=await mediaBlob(m);if(!bl){toast('Não foi possível compartilhar.');return}
 try{const f=new File([bl],mediaName(m,bl),{type:bl.type});if(navigator.canShare&&navigator.canShare({files:[f]})){await navigator.share({files:[f]});return}}catch(e){if(e&&e.name=='AbortError')return}
 toast('Compartilhar do aparelho não está disponível aqui. Escolha para quem encaminhar.',3200);fwdOpen(m)}
/* visualizador de foto */
function mvOpen(m){{const v=isVid(m);$('#mvi').hidden=v;$('#mvvw').hidden=!v;if(v)vvLoad(m.i);else $('#mvi').src=m.i}$('#mvn').textContent=m.f==meId()?'Você':(m.n||'');$('#mvt').textContent=new Date(tsOf(m.at)).toLocaleString([],{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});mv._m=m;clearTimeout(mv._t);mv.hidden=false;void mv.offsetWidth;/* v94: força o estado inicial ser pintado antes, senão a transição é pulada */requestAnimationFrame(()=>requestAnimationFrame(()=>mv.classList.add('on')))}
function mvClose(){vvPause();try{if(document.fullscreenElement)document.exitFullscreen()}catch(e){}mv.classList.remove('on');clearTimeout(mv._t);mv._t=setTimeout(()=>{if(!mv.classList.contains('on')){mv.hidden=true;vvStop();$('#mvi').removeAttribute('src')}},360)}
mv.onclick=e=>{const m=mv._m;if(e.target.closest('.vv'))return;if(e.target.closest('[data-x]')){mvClose();return}if(!m)return;
 };
/* v92: player de vídeo do visualizador — play/pause, barra de posição, som e tela cheia */
const vv=$('#mvv'),vvw=$('#mvvw'),vvr=$('#vvr');let vvT=0,vvSk=false;
const vvPct=()=>{const d=vv.duration||0;return d?Math.min(100,vv.currentTime/d*100):0};
function vvPaint(){const p=vvPct();if(!vvSk)vvr.value=p*10;vvr.style.setProperty('--p',(vvSk?vvr.value/10:p)+'%');$('#vvcur').textContent=fmtT(Math.floor(vv.currentTime||0))}
function vvWake(){vvw.classList.remove('idle');clearTimeout(vvT);if(!vv.paused)vvT=setTimeout(()=>vvw.classList.add('idle'),2600)}
let vvTok=0,vvObj='';
const vvRev=()=>{if(vvObj){try{URL.revokeObjectURL(vvObj)}catch(e){}vvObj=''}};
/* v94: 'ld' = abrindo (sem ícone de play/pause), 'rdy' = 1º quadro pronto (vídeo aparece com fade) */
function vvLoad(u){const tk=++vvTok;vvw.classList.remove('pl','idle','mu','rdy');vvw.classList.add('ld');vv.muted=false;vvr.value=0;vvPaint();$('#vvdur').textContent='0:00';
 vvLocal2(u).then(src=>{if(tk!=vvTok)return;vv.src=src;vv.play().catch(()=>{vvw.classList.remove('ld')});vvWake()})}
async function vvLocal2(u){vvRev();const b=await vidLocal(u);if(b){vvObj=URL.createObjectURL(b);return vvObj}return u}
function vvPause(){vvTok++;clearTimeout(vvT);try{vv.pause()}catch(e){}}
function vvStop(){vvPause();if(vv.getAttribute('src')){vv.removeAttribute('src');vv.load()}vvRev();vvw.classList.remove('pl','rdy','ld')}
vv.addEventListener('loadedmetadata',()=>{$('#vvdur').textContent=fmtT(Math.floor(vv.duration||0));vvPaint()});
vv.addEventListener('timeupdate',vvPaint);
vv.addEventListener('loadeddata',()=>vvw.classList.add('rdy'));
vv.addEventListener('playing',()=>{vvw.classList.add('rdy');vvw.classList.remove('ld')});
vv.addEventListener('play',()=>{vvw.classList.add('pl');vvWake()});
vv.addEventListener('pause',()=>{vvw.classList.remove('pl','ld');vvWake()});
vv.addEventListener('ended',()=>{vvw.classList.remove('pl','idle')});
vv.addEventListener('error',()=>{vvw.classList.remove('ld');if(vv.getAttribute('src'))toast('Não foi possível reproduzir o vídeo.',3200)});
vvr.addEventListener('input',()=>{vvSk=true;vvr.style.setProperty('--p',vvr.value/10+'%');if(vv.duration)vv.currentTime=vvr.value/1000*vv.duration;$('#vvcur').textContent=fmtT(Math.floor(vv.currentTime||0))});
['change','pointerup','touchend'].forEach(n=>vvr.addEventListener(n,()=>{vvSk=false}));
function vvFs(){const d=document;
 if(d.fullscreenElement||d.webkitFullscreenElement){try{(d.exitFullscreen||d.webkitExitFullscreen).call(d)}catch(e){}return}
 const rq=mv.requestFullscreen||mv.webkitRequestFullscreen;
 if(rq){try{const p=rq.call(mv);if(p&&p.then)p.then(()=>{if(vv.videoWidth>vv.videoHeight&&screen.orientation&&screen.orientation.lock)screen.orientation.lock('landscape').catch(()=>{})}).catch(()=>{})}catch(e){}}
 else if(vv.webkitEnterFullscreen)vv.webkitEnterFullscreen()}
document.addEventListener('fullscreenchange',()=>{mv.classList.toggle('fs',!!document.fullscreenElement);if(!document.fullscreenElement&&screen.orientation&&screen.orientation.unlock)try{screen.orientation.unlock()}catch(e){}});
vvw.addEventListener('click',e=>{vvWake();if(e.target.closest('#vvmu')){vv.muted=!vv.muted;vvw.classList.toggle('mu',vv.muted);return}
 if(e.target.closest('#vvfs')){vvFs();return}if(e.target.closest('.vv-b'))return;
 if(vv.paused)vv.play().catch(()=>{});else vv.pause()});
vvw.addEventListener('pointermove',vvWake);
/* encaminhar para outras conversas */
async function rpOf(u){if(!u)return false;if(PRK[u]!==undefined)return PRK[u]>=1;try{const s=await FB.getDoc(FB.doc(FB.db,'pages',u));if(s.exists()){const x=s.data();return(+x.r||0)>=1&&(!(+x.pu)||+x.pu>Date.now())}}catch(e){}return false}
async function fwdBlock(c,kind){const me=meId();
 if(c.g){if(gIsAdm(me,c))return'';const r=c.gr||{};if(r.m===false)return'só administradores podem enviar';if(kind=='i'&&r.i===false)return'fotos bloqueadas';if(kind=='a'&&r.a===false)return'áudios bloqueados';return''}
 return c.rq&&c.rq==me?'aguardando a pessoa aceitar':''}
async function fwdOne(c,m){const me=FB.auth.currentUser,P=S.profile||{},b=FB.writeBatch(FB.db),cr=FB.doc(FB.db,'chats',c.id),mr=FB.doc(FB.collection(FB.db,'chats',c.id,'m'));
 const un={[me.uid]:0};(c.ps||[]).forEach(x=>{if(x!=me.uid)un[x]=FB.increment(1)});
 b.set(cr,{p:{[me.uid]:{u:P.username||'',n:P.name||S.u.name||''}},last:{t:m.a?'🎤 Áudio':(m.t||(isVid(m)?'🎥 Vídeo':'📷 Foto')),f:me.uid},at:FB.serverTimestamp(),un,sc:{[me.uid]:FB.increment(1)}},{merge:true});
 const md={f:me.uid,n:(P.name||S.u.name||'').slice(0,60),t:m.t||'',i:m.i||'',at:FB.serverTimestamp()};if(m.a){md.a=m.a;md.ad=m.ad||0}else if(isVid(m))md.video=true;
 b.set(mr,md);await Promise.race([b.commit(),wait(8000)])}
function fwdBtn(){const o=$('#fwdok');o.disabled=!FW.sel.size;o.textContent=FW.sel.size?'Enviar para '+FW.sel.size:'Enviar'}
function fwdOpen(m){FW.m=m;FW.sel.clear();const L=IB.list||[];
 $('#fwdl').innerHTML=L.length?L.map(c=>{const i=cInfo(c);return`<button class="msn-i" type="button" data-id="${esc(c.id)}" data-pu="${esc(i.u)}"><span class="cht-av${i.g?' gp':''}${i.gp?' ph':''}"${i.gp?` style="background-image:url('${esc(i.gp)}')"`:(!i.g?` style="${ncSt(i.u||i.o)}"`:'')}>${i.gp?'':esc(ini(i.n))}</span><div><b>${esc(i.n)}</b><small>${i.g?esc(i.k):'@'+esc(i.u)}</small></div><i class="msn-ck" aria-hidden="true"></i></button>`}).join(''):'<p class="pr-em">Você ainda não tem outras conversas. Inicie um chat primeiro e depois encaminhe.</p>';
 fwdBtn();peersPaint($('#fwdl'),'.msn-i','b');fwd.hidden=false;requestAnimationFrame(()=>fwd.classList.add('on'))}
fwd.onclick=e=>{if(e.target.closest('[data-x]')){prsHide(fwd);return}
 const b=e.target.closest('.msn-i');if(b){const id=b.dataset.id;if(FW.sel.has(id))FW.sel.delete(id);else FW.sel.add(id);b.classList.toggle('on',FW.sel.has(id));fwdBtn();return}
 const ok=e.target.closest('#fwdok');if(ok)fwdGo(ok)};
function fwdGo(btn){const m=FW.m,ids=[...FW.sel];if(!m||!ids.length)return;const kind=m.i?'i':m.a?'a':'t';
 withSpin(btn,async()=>{let ok=0;const bad=[];
  for(const id of ids){const c=(IB.list||[]).find(x=>x.id==id);if(!c)continue;const why=await fwdBlock(c,kind);if(why){bad.push(cInfo(c).n+' ('+why+')');continue}
   try{await fwdOne(c,m);ok++}catch(e){console.error('encaminhar:',e);bad.push(cInfo(c).n)}}
  return{ok,bad}},500).then(r=>{if(!r)return;prsHide(fwd);toast(r.ok?('Encaminhado para '+r.ok+(r.ok==1?' conversa':' conversas')+(r.bad.length?'. Não enviado: '+r.bad.join(', '):'.')):('Não foi possível encaminhar: '+r.bad.join(', ')),r.bad.length?5600:2400)}).catch(()=>toast('Não foi possível encaminhar.'))}

/* ---------- informações do grupo ---------- */
const gName=u=>{const p=(CH.p||{})[u]||{};return String(p.n||p.u||'Membro')};
function giOpen(){if(!CH.g)return;GI.edit=false;GI.val=undefined;gi.hidden=false;giPaint();requestAnimationFrame(()=>gi.classList.add('on'))}
function giClose(q){GI.edit=false;{const g=$('#gset');if(g&&!g.hidden)prsHide(g)}gi.classList.remove('on');if(q){gi.hidden=true;return}setTimeout(()=>{if(!gi.classList.contains('on'))gi.hidden=true},260)}
$('#gix').onclick=()=>giClose();
function giPaint(){if(gi.hidden||!CH.g)return;
 const me=meId(),d=CH.gd||{},ow=gOwnerId(),ad=new Set(gAdmins()),adm=ad.has(me),own=ow==me,ps=CH.ps||[],P=CH.p||{},r=d.gr||{},gp=okI(d.gp)?d.gp:'',nm=CH.tn||'Grupo';
 if(GI.edit){const i=$('#gienn');if(i)GI.val=i.value}
 const st=gib.scrollTop;$('#gigear').hidden=!adm;gsetPaint();
 const sw=(k,t,s)=>`<div class="gi-r"><div><b>${t}</b><small>${s}</small></div><button class="gi-sw" type="button" role="switch" data-r="${k}" aria-checked="${r[k]!==false}" aria-label="${t}"${adm?'':' disabled'}><i></i></button></div>`;
 const order=[...ps].sort((a,b)=>(b==ow)-(a==ow)||(ad.has(b)-ad.has(a))||gName(a).localeCompare(gName(b)));
 const rows=order.map(id=>{const p=P[id]||{},n=gName(id),u=p.u||'';return`<button class="gi-m" type="button" data-id="${esc(id)}" data-pu="${esc(u)}"><span class="cht-av" style="${ncSt(u||id,ncGrp((CH.ps||[]).map(ncKey)))}">${esc(ini(n))}</span><div><b>${esc(n)}${id==me?' <span class="gi-you">(você)</span>':''}</b><small>${u?'@'+esc(u):''}</small></div>${id==ow?`<em class="adb own">${I('cr')}Admin</em>`:ad.has(id)?'<em class="adb">Admin</em>':''}</button>`}).join('');
 gib.innerHTML=`<div class="gi-top"><div class="gi-avw"><span class="cht-av gp gi-big${gp?' ph':''}"${gp?` style="background-image:url('${esc(gp)}')"`:''}>${gp?'':esc(ini(nm))}</span>${adm?'<button class="gi-cam" id="giav" type="button" aria-label="Alterar foto do grupo"><svg class="i"><use href="#img"/></svg></button>':''}</div>`+
  (GI.edit?`<div class="gi-en"><input class="ds-in" id="gienn" maxlength="40" value="${esc(GI.val!==undefined?GI.val:nm)}" aria-label="Nome do grupo"><button class="gi-sv" id="giens" type="button">Salvar</button></div>`:`<h2>${esc(nm)}${adm?'<button class="gi-pen" id="gien" type="button" aria-label="Mudar o nome do grupo"><svg class="i"><use href="#pen"/></svg></button>':''}</h2>`)+
  `<p class="gi-sub">Grupo · ${ps.length} ${ps.length==1?'membro':'membros'}</p>${adm&&gp?'<button class="gi-lnk" id="gird" type="button">Remover foto</button>':''}</div>`+
  `<section class="gi-s"><h3>Membros · ${ps.length}</h3>${adm&&ps.length<20?'<button class="gi-add" id="giadd" type="button"><span class="cht-av"><svg class="i"><use href="#users"/></svg></span><b>Adicionar membros</b></button>':''}<div class="gi-card gi-ml">${rows}</div>${adm?'<p class="gi-note">Toque num membro para promover, remover de admin ou tirar do grupo.</p>':''}</section>`+
  `<section class="gi-s">${own?'<button class="gi-dg" id="gidel" type="button">Apagar grupo</button><p class="gi-note">Só o criador pode apagar o grupo. As mensagens são apagadas para todos.</p>':'<button class="gi-dg" id="gileave" type="button">Sair do grupo</button>'}</section>`;
 peersPaint(gib,'.gi-m','b');gib.scrollTop=st}
async function gSave(upd,raw){const cid=CH.cid;if(!cid||!CH.g)return false;const d=CH.gd||{};
 if(!raw&&!d.ow){const ow=gOwnerId();if(ow){upd={...upd,ow};if(!upd.ad)upd.ad=gAdmins()}}
 try{await Promise.race([FB.updateDoc(FB.doc(FB.db,'chats',cid),upd),wait(8000)]);return true}
 catch(e){console.error('grupo:',e);toast(e&&e.code=='permission-denied'?'Sem permissão. Só administradores podem mudar o grupo (e o firestore.rules precisa estar publicado).':'Não foi possível salvar. Tente de novo.',4800);return false}}
function giRename(){const v=(($('#gienn')||{}).value||'').trim().slice(0,40);if(!v){toast('Dê um nome ao grupo.');return}
 GI.edit=false;GI.val=undefined;if(v==CH.tn){giPaint();return}gSave({gn:v}).then(ok=>{if(ok)toast('Nome alterado.',1800);giPaint()})}
function giMember(b){const id=b.dataset.id,me=meId(),ow=gOwnerId(),ad=gAdmins(),adm=ad.includes(me),u=b.dataset.pu;if(id==me)return;
 let h=u?'<button type="button" data-a="pf">Ver perfil</button>':'';
 if(adm&&id!=ow){h+=ad.includes(id)?'<button type="button" data-a="dm">Remover de admin</button>':'<button type="button" data-a="pm">Promover a admin</button>';h+='<button type="button" class="dg" data-a="rm">Remover do grupo</button>'}
 if(!h)return;$('#gmab').innerHTML=h+'<button type="button" data-x>Cancelar</button>';gma.dataset.id=id;gma.dataset.u=u;gma.hidden=false;requestAnimationFrame(()=>gma.classList.add('on'))}
gma.onclick=async e=>{if(e.target.closest('[data-x]')){prsHide(gma);return}const b=e.target.closest('[data-a]');if(!b)return;const id=gma.dataset.id,u=gma.dataset.u,a=b.dataset.a,n=gName(id);
 if(a=='pf'){prsHide(gma);xpv.style.zIndex='9900';xpOpen(u);return}
 if(a=='pm'){prsHide(gma);gSave({ad:[...gAdmins(),id]}).then(ok=>ok&&toast(n+' agora é admin.',2200));return}
 if(a=='dm'){prsHide(gma);gSave({ad:gAdmins().filter(x=>x!=id)}).then(ok=>ok&&toast(n+' não é mais admin.',2200));return}
 if(a=='rm'&&await cfm({t:'Remover do grupo?',m:n+' deixa de fazer parte deste grupo.',ok:'Remover',i:'users',d:true})){prsHide(gma);gSave({ps:(CH.ps||[]).filter(x=>x!=id),ad:gAdmins().filter(x=>x!=id)}).then(ok=>ok&&toast(n+' foi removido.',2200))}};
/* v81: convite de grupo para perfil premium (coleção ginv/{cid}_{uid}); a pessoa NÃO entra em ps até aceitar */
async function gInvite(cid,gn,L){const me=FB.auth.currentUser.uid;let ok=0,err=null;
 for(const x of L){try{await Promise.race([FB.setDoc(FB.doc(FB.db,'ginv',cid+'_'+x.id),{cid,to:x.id,by:me,gn:String(gn||'').slice(0,40),at:FB.serverTimestamp()}),wait(8000).then(()=>{throw{code:'timeout'}})]);ok++}catch(e){console.error('convite:',e);err=e&&e.code||'erro'}}
 return{ok,err}}
function gInvToast(iv){if(!iv||!iv.n)return;
 if(iv.ok==iv.n){toast(iv.n==1?'Solicitação enviada.':'Solicitações enviadas.',2800);return}
 toast(iv.err=='permission-denied'?'Sem permissão. Publique o firestore.rules atualizado no Firebase.':'Não foi possível enviar a solicitação. Tente de novo.',4600)}
function gAddMembers(btn){return withSpin(btn,async()=>{const add=[],inv=[],pp={};
  for(const x of MN.sel.values()){const id=await uidOf(x.u);if(!id||(CH.ps||[]).includes(id)||add.includes(id)||inv.some(v=>v.id==id))continue;
   if(await rpOf(x.u))inv.push({id,u:x.u,n:x.n});else{add.push(id);pp['p.'+id]={u:x.u,n:x.n}}}
  if(!add.length&&!inv.length)throw'none';if((CH.ps||[]).length+add.length>20)throw'cap';
  if(add.length&&!(await gSave({ps:[...CH.ps,...add],...pp})))return null;
  const iv=inv.length?await gInvite(CH.cid,CH.tn,inv):{ok:0,err:null};
  return{add:add.length,iv:{n:inv.length,ok:iv.ok,err:iv.err}}},600).then(r=>{if(!r)return;prsHide(msn);
   if(r.add&&!r.iv.n)toast('Membros adicionados.',2200);else if(r.add&&r.iv.ok==r.iv.n)toast('Membros adicionados. '+(r.iv.n==1?'Solicitação enviada.':'Solicitações enviadas.'),3200);else if(r.add){toast('Membros adicionados, mas a solicitação não foi enviada.',4200)}else gInvToast(r.iv)}).catch(er=>toast(er=='cap'?'Limite de 20 pessoas por grupo.':er=='none'?'Ninguém novo para adicionar.':'Não foi possível adicionar.',3600))}
async function gDelete(btn){if(!(await cfm({t:'Apagar o grupo?',m:'As mensagens serão apagadas para todos. Isso não pode ser desfeito.',ok:'Apagar grupo',i:'trash',d:true})))return;const cid=CH.cid;
 withSpin(btn,async()=>{if(!(CH.gd||{}).ow&&!(await gSave({})))throw 0;CH.quit=true;
  for(let n=0;n<25;n++){const s=await FB.getDocs(FB.query(FB.collection(FB.db,'chats',cid,'m'),FB.limit(200)));if(s.empty)break;const b=FB.writeBatch(FB.db);s.docs.forEach(x=>b.delete(x.ref));await b.commit()}
  await FB.deleteDoc(FB.doc(FB.db,'chats',cid))},600)
 .then(()=>{toast('Grupo apagado.',2400);giClose(true);chShut()}).catch(er=>{CH.quit=false;console.error(er);toast('Não foi possível apagar o grupo.',4200)})}
async function gLeave(btn){if(!(await cfm({t:'Sair do grupo?',m:'Você deixa de receber as mensagens deste grupo.',ok:'Sair',i:'out',d:true})))return;const me=meId();
 withSpin(btn,async()=>{CH.quit=true;const upd={ps:(CH.ps||[]).filter(x=>x!=me)},adm=gIsAdm(me);if(adm)upd.ad=gAdmins().filter(x=>x!=me);if(!(await gSave(upd,!adm)))throw 0},600)
 .then(()=>{toast('Você saiu do grupo.',2400);giClose(true);chShut()}).catch(()=>{CH.quit=false})}
gib.onclick=e=>{const t=e.target;
 if(t.closest('#giav')){$('#gifile').click();return}
 if(t.closest('#gird')){gSave({gp:''});return}
 if(t.closest('#gien')){GI.edit=true;GI.val=undefined;giPaint();const i=$('#gienn');if(i){i.focus();i.select()}return}
 if(t.closest('#giens')){giRename();return}
 const sw=t.closest('.gi-sw');if(sw&&!sw.disabled){const k=sw.dataset.r,on=sw.getAttribute('aria-checked')=='true';sw.setAttribute('aria-checked',String(!on));gSave({['gr.'+k]:!on}).then(ok=>{if(!ok)giPaint()});return}
 if(t.closest('#giadd')){msnOpen('add');return}
 if(t.closest('#gidel')){gDelete(t.closest('#gidel'));return}
 if(t.closest('#gileave')){gLeave(t.closest('#gileave'));return}
 const m=t.closest('.gi-m');if(m)giMember(m)};
gib.addEventListener('keydown',e=>{if(e.target.id!='gienn')return;if(e.key=='Enter'){e.preventDefault();giRename()}else if(e.key=='Escape'){e.stopPropagation();GI.edit=false;GI.val=undefined;giPaint()}});
$('#gifile').onchange=e=>{const f=e.target.files[0];e.target.value='';
 cpOpen(f,{cld:false,ratio:1,w:360,mime:'image/jpeg',q:.82,max:26000,title:'Foto do grupo',ok:'Usar foto',again:()=>$('#gifile').click(),cb:d=>{gSave({gp:d}).then(ok=>ok&&toast('Foto do grupo atualizada.',2000))}})};

/* ===== v76: player de áudio (estilo Telegram) e configurações do grupo (engrenagem, só admin) ===== */
const AP={row:null,raf:0,drag:null};
function apHtml(m){const d=+m.ad||0;
 return`<div class="ap" data-d="${d}"><button class="ap-b" type="button" aria-label="Reproduzir áudio"><svg class="ap-play" viewBox="0 0 24 24" aria-hidden="true"><path d="M8.2 6 8.2 18 17.4 12z"/></svg><svg class="ap-pause" viewBox="0 0 24 24" aria-hidden="true"><rect x="6.5" y="5" width="4" height="14" rx="1.3"/><rect x="13.5" y="5" width="4" height="14" rx="1.3"/></svg></button><div class="ap-m"><div class="ap-w" role="slider" aria-label="Posição do áudio" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i class="ap-f"></i><i class="ap-k"></i></div><span class="ap-t">${fmtT(d)}</span></div></div>`}
const apMsg=row=>CH.msgs.find(x=>x.id==row.dataset.id);
function apDur(row,a){const ap=$('.ap',row);return a&&isFinite(a.duration)&&a.duration>0?a.duration:(ap?+ap.dataset.d||0:0)}
function apPaint(row,a){const ap=$('.ap',row);if(!ap)return;const d=apDur(row,a),c=a?a.currentTime:0,p=d?Math.min(1,c/d):0,w=$('.ap-w',ap);
 w.style.setProperty('--p',p.toFixed(4));w.setAttribute('aria-valuenow',Math.round(p*100));$('.ap-t',ap).textContent=fmtT(Math.floor(c>.05?c:d))}
function apInit(row,m){const a=row._au=new Audio();a.preload='metadata';a.src=m.a;
 a.addEventListener('ended',()=>{row.classList.remove('playing');a.currentTime=0;apPaint(row,a)});
 a.addEventListener('pause',()=>row.classList.remove('playing'));a.addEventListener('play',()=>row.classList.add('playing'));
 a.addEventListener('loadedmetadata',()=>apPaint(row,a));a.addEventListener('timeupdate',()=>apPaint(row,a));return a}
function apTick(){cancelAnimationFrame(AP.raf);const f=()=>{const r=AP.row;if(r&&r._au&&!r._au.paused){apPaint(r,r._au);AP.raf=requestAnimationFrame(f)}};f()}
function apStop(){cancelAnimationFrame(AP.raf);if(AP.row&&AP.row._au)AP.row._au.pause();AP.row=null}
function apToggle(row){const m=apMsg(row);if(!m||!okA(m.a))return;if(AP.row&&AP.row!==row&&AP.row._au)AP.row._au.pause();
 const a=row._au||apInit(row,m);if(a.paused){AP.row=row;a.play().then(apTick).catch(()=>toast('Não foi possível reproduzir o áudio.',2600))}else a.pause()}
function apSeek(row,w,e){const m=apMsg(row);if(!m)return;const r=w.getBoundingClientRect(),f=Math.min(1,Math.max(0,(e.clientX-r.left-6)/Math.max(1,r.width-12))),a=row._au||apInit(row,m),d=apDur(row,a);if(!d)return;try{a.currentTime=f*d}catch(x){}apPaint(row,a)}
chl.addEventListener('click',e=>{const b=e.target.closest('.ap-b');if(b){const row=b.closest('.cr');if(row)apToggle(row)}});
chl.addEventListener('pointerdown',e=>{const w=e.target.closest('.ap-w');if(!w)return;const row=w.closest('.cr');if(!row)return;AP.drag={w,row};w.classList.add('dg');apSeek(row,w,e);try{w.setPointerCapture(e.pointerId)}catch(x){}});
chl.addEventListener('pointermove',e=>{if(AP.drag)apSeek(AP.drag.row,AP.drag.w,e)});
['pointerup','pointercancel'].forEach(t=>chl.addEventListener(t,()=>{if(AP.drag)AP.drag.w.classList.remove('dg');AP.drag=null}));

/* ===== v77: responder, reagir (estilo Telegram/WhatsApp) e arrastar para responder ===== */
const RXQ=['👍','❤️','😂','😮','😢','🙏','🔥'];
/* -- respostas -- */
const rpPrev=m=>({id:m.id,f:m.f,n:m.n||'',t:String(m.t||(m.a?'Áudio':isVid(m)?'Vídeo':'Foto')).replace(/\s+/g,' ').slice(0,100),k:m.a?'a':(m.i?'i':'')});
function rpHtml(m,me){const r=m.rp;if(!r||typeof r!='object')return'';const who=r.f==me?'Você':String(r.n||'Mensagem');
 return`<div class="rq${r.f==me?' own':''}" style="${ncSt(ncKey(r.f),ncG())}" data-rq="${esc(r.id||'')}" role="button" aria-label="Ver a mensagem respondida"><b>${esc(who)}</b><span>${r.k=='a'?I('qmic'):r.k=='i'?I('img'):''}${emoT(String(r.t||'').slice(0,120))}</span></div>`}
function rpBar(){const b=$('#chtrp'),r=CH.reply;b.hidden=!r;if(!r)return;
 $('b',b).textContent=r.f==meId()?'Você':(r.n||'Mensagem');$('span',b).innerHTML=(r.k=='a'?I('qmic'):r.k=='i'?I('img'):'')+emoT(r.t||'')}
function msgReply(m){if(!m||m._p)return;if(CH.edit)chEditEnd();CH.reply=rpPrev(m);rpBar();try{if(!chin.disabled)chin.focus({preventScroll:true})}catch(e){}}
$('#chtrpx').onclick=()=>{CH.reply=null;rpBar();try{chin.focus({preventScroll:true})}catch(e){}};
function rpGo(id){const row=id&&$$('.cr',chl).find(r=>r.dataset.id==id);
 if(!row){toast('A mensagem original não está mais disponível.',2400);return}
 cancelAnimationFrame(chl._sc);chl._sc=0;row.scrollIntoView({block:'center',behavior:'smooth'});const c=$('.cm',row);c.classList.remove('hl');void c.offsetWidth;c.classList.add('hl');setTimeout(()=>c.classList.remove('hl'),1500)}
/* -- reações (guardadas em chats/{id}/m/{msg}.rx = {uid: emoji}; uma por pessoa) -- */
function rxHtml(m,me){const x=m.rx;if(!x||typeof x!='object')return'';const g=new Map();
 Object.keys(x).forEach(u=>{const e=x[u];if(typeof e!='string'||!e)return;const o=g.get(e)||{n:0,me:false,u:[]};o.n++;o.u.push(u);if(u==me)o.me=true;g.set(e,o)});
 if(!g.size)return'';
 return[...g.entries()].sort((a,b)=>b[1].n-a[1].n).map(([e,o])=>{const nm=CH.g?o.u.map(u=>u==me?'Você':gName(u)).join(', '):'';
  return`<button class="rxc${o.me?' on':''}" type="button" data-e="${esc(e)}" aria-pressed="${o.me}" aria-label="${esc(e)} ${o.n}"${nm?` title="${esc(nm)}"`:''}>${emoT(e)}${o.n>1?`<b>${o.n}</b>`:''}</button>`}).join('')}
function msgReact(m,e){const me=meId(),cur=(m.rx||{})[me];if(!m||!me||!e)return;
 FB.updateDoc(FB.doc(FB.db,'chats',CH.cid,'m',m.id),{['rx.'+me]:cur==e?FB.deleteField():e})
  .catch(er=>toast(er&&er.code=='permission-denied'?'Sem permissão. Publique o firestore.rules atualizado no Firebase.':'Não foi possível reagir. Tente de novo.',4600))}
/* -- menu da mensagem: barra de reações em cima + opções embaixo, com a mensagem em destaque -- */
const mx=$('#mx');let mxRow=null;
function mxClose(){if(mx.hidden)return;mx.classList.remove('on');if(mxRow){mxRow.classList.remove('mxsel');mxRow=null}setTimeout(()=>{if(!mx.classList.contains('on')){mx.hidden=true;mx.innerHTML='';mx.classList.remove('pk')}},170)}
function msgMenu(row,items,m){if(mxRow)mxClose();const cm=$('.cm',row);if(!cm)return;
 const me=meId(),cur=(m.rx||{})[me],mine=row.classList.contains('me'),r=cm.getBoundingClientRect();
 const quick=RXQ.slice();if(cur&&!quick.includes(cur))quick.splice(quick.length-1,1,cur);
 mx.innerHTML='<div class="mx-bk"></div><div class="mx-cl"></div>'
  +'<div class="mx-rb" role="toolbar" aria-label="Reagir">'+quick.map(e=>`<button class="mx-e${cur==e?' on':''}" type="button" data-e="${esc(e)}" aria-label="Reagir com ${esc(e)}">${emoT(e)}</button>`).join('')+'<button class="mx-m" type="button" aria-label="Mais reações" aria-expanded="false">'+I('chev')+'</button></div>'
  +'<div class="mx-ml" role="menu">'+items.map((it,k)=>`<button class="ed-mi mx-i${it.c?' '+it.c:''}" type="button" role="menuitem" data-k="${k}">${I(it.i)}<span>${it.t}</span></button>`).join('')+'</div>'
  +'<div class="mx-pk" aria-label="Todas as reações">'+Object.keys(EMO).map(k=>`<h6>${k}</h6><div class="mx-g">${EMO[k].map(x=>`<button type="button" data-e="${esc(x)}" aria-label="${esc(x)}">${emoT(x)}</button>`).join('')}</div>`).join('')+'</div>';
 const cl=$('.mx-cl',mx),c2=cm.cloneNode(true);c2.removeAttribute('id');c2.querySelectorAll('[id]').forEach(n=>n.removeAttribute('id'));c2.classList.add('mxc');cl.appendChild(c2);
 mx._m=m;mx._it=items;mx.classList.remove('pk');mx.style.visibility='hidden';mx.hidden=false;
 const pill=$('.mx-rb',mx),menu=$('.mx-ml',mx),pk=$('.mx-pk',mx),W=innerWidth,H=innerHeight,G=8,T=Math.max(64,(parseFloat(getComputedStyle(cht).paddingTop)||0)+56),
  pw=pill.offsetWidth,ph=pill.offsetHeight,mw=menu.offsetWidth,mh=menu.offsetHeight;
 let bh=r.height,bt=r.top;const maxB=H-12-T-ph-G*2-mh;if(bh>maxB){bh=Math.max(96,maxB)}
 if(bt-ph-G<T)bt=T+ph+G;if(bt+bh+G+mh>H-12)bt=H-12-mh-G-bh;if(bt-ph-G<T)bt=T+ph+G;
 const put=(el,w)=>{el.style.left=Math.min(Math.max(12,mine?r.right-w:r.left),W-12-w)+'px'};
 cl.style.cssText=`left:${r.left}px;top:${bt}px;width:${r.width}px;height:${bh}px`;
 pill.style.top=(bt-ph-G)+'px';put(pill,pw);menu.style.top=(bt+bh+G)+'px';put(menu,mw);
 const pt=bt-ph-G+ph+G,pwid=Math.min(W-24,344);pk.style.width=pwid+'px';pk.style.top=pt+'px';pk.style.maxHeight=Math.min(330,Math.max(160,H-12-pt))+'px';pk.style.left=Math.min(Math.max(12,mine?r.right-pwid:r.left),W-12-pwid)+'px';
 pill.style.transformOrigin=pk.style.transformOrigin=(mine?'right':'left')+' bottom';menu.style.transformOrigin=(mine?'right':'left')+' top';
 row.classList.add('mxsel');mxRow=row;mx.style.visibility='';requestAnimationFrame(()=>mx.classList.add('on'))}
mx.addEventListener('click',e=>{const m=mx._m;
 if(e.target.closest('.mx-bk,.mx-cl')){mxClose();return}
 const ch=e.target.closest('.mx-m');if(ch){const on=!mx.classList.contains('pk');mx.classList.toggle('pk',on);ch.setAttribute('aria-expanded',on);return}
 const em=e.target.closest('[data-e]');if(em&&m){mxClose();msgReact(m,em.dataset.e);return}
 const it=e.target.closest('.mx-i');if(it&&m){const f=(mx._it[+it.dataset.k]||{}).f;mxClose();if(f)setTimeout(f,60)}});
document.addEventListener('keydown',e=>{if(e.key=='Escape'&&!mx.hidden){e.stopImmediatePropagation();mxClose()}},true);
addEventListener('resize',mxClose);
/* -- arrastar a mensagem para a direita = responder (como no WhatsApp) -- */
const SW={row:null,cm:null,x:0,y:0,dx:0,mode:'',t:0,ok:false},swi=$('#swi');
function swReset(go){const cm=SW.cm,row=SW.row;if(cm){cm.style.transition='transform .22s cubic-bezier(.2,.8,.2,1)';cm.style.transform='';setTimeout(()=>{if(cm.style.transform==='')cm.style.transition=''},260)}
 swi.classList.remove('on','ok');swi.style.transform='';swi.style.opacity='';
 if(go&&row){const m=CH.msgs.find(x=>x.id==row.dataset.id);if(m)msgReply(m)}
 SW.row=SW.cm=null;SW.mode='';SW.dx=0;SW.ok=false}
chl.addEventListener('touchstart',e=>{SW.row=null;if(e.touches.length!=1||e.target.closest('.ap-w,a,.rxc'))return;const cm=e.target.closest('.cm'),row=cm&&cm.closest('.cr');if(!row||row.classList.contains('mxsel'))return;
 const t=e.touches[0];Object.assign(SW,{row,cm,x:t.clientX,y:t.clientY,dx:0,mode:'',ok:false})},{passive:true});
chl.addEventListener('touchmove',e=>{if(!SW.row)return;const t=e.touches[0],dx=t.clientX-SW.x,dy=t.clientY-SW.y;
 if(!SW.mode){if(Math.abs(dy)>10&&Math.abs(dy)>Math.abs(dx)){SW.row=null;return}if(dx>12&&dx>Math.abs(dy)*1.6){SW.mode='h';SW.cm.style.transition='none'}else return}
 if(e.cancelable)e.preventDefault();SW.dx=Math.max(0,dx);const tx=SW.dx<=64?SW.dx:Math.min(96,64+(SW.dx-64)*.3);SW.cm.style.transform=`translateX(${tx}px)`;
 const rr=SW.cm.getBoundingClientRect(),lr=chl.getBoundingClientRect(),p=Math.min(1,SW.dx/56);
 swi.style.left=(lr.left+10)+'px';swi.style.top=(rr.top+rr.height/2-16)+'px';swi.classList.add('on');swi.style.transform=`scale(${.5+.5*p})`;swi.style.opacity=p;
 const ok=SW.dx>=56;if(ok!=SW.ok){SW.ok=ok;swi.classList.toggle('ok',ok);if(ok&&navigator.vibrate)try{navigator.vibrate(12)}catch(x){}}},{passive:false});
['touchend','touchcancel'].forEach(n=>chl.addEventListener(n,e=>{if(!SW.row)return;const go=SW.mode=='h'&&SW.ok&&n=='touchend';if(SW.mode=='h')SW.t=Date.now();swReset(go)},{passive:true}));

/* ===== v79: nomes coloridos, contador de respostas, foto com download, "@" de resposta e skeleton ===== */
/* cor do nome: sai do uid da pessoa (igual em todos os aparelhos), como no Telegram */
/* ===== v80: cada pessoa tem a SUA cor (matiz 0-359 × 3 saturações × 3 luminosidades = 3.240 cores, sempre a mesma para o mesmo @).
   Dentro de uma conversa em grupo as cores são afastadas à força para ninguém ficar com cor igual/parecida. A mesma cor pinta o nome e o fundo do avatar sem foto. */
const nHash=s=>{let h=2166136261>>>0;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619)>>>0}h^=h>>>15;h=Math.imul(h,2246822507)>>>0;h^=h>>>13;h=Math.imul(h,3266489909)>>>0;h^=h>>>16;return h>>>0};
const nBase=k=>{const h=nHash(k);return{h:h%360,s:[62,70,78,86][(h>>>9)%4],l:[40,45,50][(h>>>12)%3]}};
const NG={sig:'',m:new Map()};
function ncGrp(keys){const L=[...new Set(keys.filter(Boolean).map(k=>String(k).toLowerCase()))].sort(),sig=L.join('|');if(NG.sig==sig)return NG.m;
 const m=new Map(),used=[],T=Math.min(22,Math.floor(300/Math.max(1,L.length))),dist=(x,h)=>{const d=Math.abs(x-h)%360;return Math.min(d,360-d)};
 L.sort((a,b)=>nHash(a)-nHash(b)||(a<b?-1:1)).forEach(k=>{const c=nBase(k);let best=c.h,bd=-1;
  for(let j=0;j<52;j++){const h=(c.h+j*7)%360,d=used.length?Math.min(...used.map(x=>dist(x,h))):360;if(d>=T){best=h;bd=d;break}if(d>bd){bd=d;best=h}}
  used.push(best);m.set(k,{...c,h:best})});NG.sig=sig;NG.m=m;return m}
const ncSt=(k,grp)=>{k=String(k||'?').toLowerCase();const c=(grp&&grp.get(k))||nBase(k);return`--nh:${c.h};--ns:${c.s}%;--nl:${c.l}%`};
const ncKey=id=>(CH.p&&CH.p[id]&&CH.p[id].u)||id,ncG=()=>CH.g?ncGrp((CH.ps||[]).map(ncKey)):null;
/* skeleton enquanto as mensagens carregam */
const SKR=[['th',58,2],['th',40,1],['me',46,1],['th',66,3],['me',54,2],['th',36,1],['me',60,2]];
function chSkel(){if($('.sk-w',chl))return;
 chl.innerHTML='<div class="sk-w" aria-hidden="true">'+SKR.map(r=>`<div class="sk-r ${r[0]}">${CH.g&&r[0]=='th'?'<i class="sk-a"></i>':''}<div class="sk-b" style="width:${r[1]}%">${'<i></i>'.repeat(r[2])}</div></div>`).join('')+'</div>';chl.setAttribute('aria-busy','true')}
/* ir até a mensagem original / até as respostas (rolagem suave + destaque) */
const RCI=new Map();
function rcGo(id){const rs=CH.msgs.filter(m=>m.rp&&m.rp.id==id);if(!rs.length)return;const i=(RCI.get(id)||0)%rs.length;RCI.set(id,i+1);rpGo(rs[i].id)}
/* "@" — chats/{id}.mn.{uid} = lista de mensagens que responderam a uma mensagem sua e que você ainda não viu */
const mnb=$('#mnb'),MNST=new Map();let mnT=0,mnQ=0;
const mnVis=()=>{const ix=new Map(CH.msgs.map((m,i)=>[m.id,i]));return(CH.mn||[]).filter(id=>ix.has(id)).sort((a,b)=>ix.get(a)-ix.get(b))};
function mnPos(){const r=chl.getBoundingClientRect(),h=cht.getBoundingClientRect();mnb.style.setProperty('--mnb',Math.max(12,h.bottom-r.bottom+12)+'px')}
function mnPaint(){const ids=CH.ml&&!cht.hidden?mnVis():[],on=ids.length>0;mnb.classList.toggle('on',on);mnb.tabIndex=on?0:-1;mnb.setAttribute('aria-hidden',String(!on));if(on){$('b',mnb).textContent=ids.length;mnPos()}}
function mnCheck(){if(!CH.ml||!CH.cid||cht.hidden||document.visibilityState!='visible')return;const ids=CH.mn||[];if(!ids.length)return;
 const lr=chl.getBoundingClientRect(),have=new Set(CH.msgs.map(m=>m.id)),seen=[];
 ids.forEach(id=>{if(!have.has(id)){const t0=MNST.get(id)||Date.now();MNST.set(id,t0);if(Date.now()-t0>3000)seen.push(id);return}
  MNST.delete(id);const row=chl.querySelector('.cr[data-id="'+id+'"]');if(!row)return;const r=row.getBoundingClientRect(),vis=Math.min(r.bottom,lr.bottom)-Math.max(r.top,lr.top);
  if(vis>=Math.min(r.height,80)*.6)seen.push(id)});
 if(MNST.size)setTimeout(mnLater,3200);
 if(!seen.length)return;
 CH.mn=ids.filter(x=>!seen.includes(x));mnPaint();
 FB.updateDoc(FB.doc(FB.db,'chats',CH.cid),{['mn.'+meId()]:FB.arrayRemove(...seen)}).catch(()=>{})}
function mnLater(){clearTimeout(mnT);mnT=setTimeout(()=>{mnCheck();mnPaint()},380)}
chl.addEventListener('scroll',()=>{if(mnQ)return;mnQ=requestAnimationFrame(()=>{mnQ=0;mnCheck()})},{passive:true});
document.addEventListener('visibilitychange',()=>{if(document.visibilityState=='visible')mnLater()});
try{new ResizeObserver(()=>{if(mnb.classList.contains('on'))mnPos()}).observe(chl)}catch(e){}
mnb.onclick=()=>{const ids=mnVis();if(!ids.length)return;rpGo(ids[0])};
/* foto de outra pessoa: primeiro precisa baixar (toque → anel de progresso com X para cancelar → foto nítida) */
const DLD=(()=>{try{return new Set(JSON.parse(localStorage.getItem('qdl')||'[]'))}catch(e){return new Set()}})(),DLJ=new Map();
const dlSave=()=>{try{localStorage.setItem('qdl',JSON.stringify([...DLD].slice(-500)))}catch(e){}};
const imgGate=m=>okI(m.i)&&m.f!=meId()&&!m._p&&!DLD.has(m.id);
const vidSrc=u=>esc(u)+'#t=0.1';
/* v93: capa do vídeo = imagem JPG do 1º quadro (Cloudinary). Aparece já pronta, como foto — sem tela preta e sem mudar de tamanho */
const vidThumb=u=>esc(String(u).replace('/video/upload/','/video/upload/so_0,w_640,c_limit,f_jpg,q_auto/').replace(/\.[a-z0-9]{2,4}(?=($|[?#]))/i,'.jpg'));
const VPLAY='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13l11-6.5z"/></svg>';
const mediaTag=m=>isVid(m)?`<div class="vw" role="button" tabindex="0" aria-label="Abrir vídeo"><img class="vth" src="${vidThumb(m.i)}" alt="Vídeo" decoding="async"><span class="vp">${VPLAY}</span></div>`:`<img src="${esc(m.i)}" alt="Foto" data-v="1">`;
const dlHtml=m=>`<div class="dlw${isVid(m)?' vd':''}" data-dl="${esc(m.id)}">${isVid(m)?`<img class="dlb" src="${vidThumb(m.i)}" alt="Vídeo" decoding="async">`:`<img class="dlb" src="${esc(m.i)}" alt="Foto" decoding="async">`}<button class="dlg" type="button" aria-label="${isVid(m)?'Baixar vídeo':'Baixar foto'}"><svg class="dlr" viewBox="0 0 56 56" aria-hidden="true"><circle class="dlp" cx="28" cy="28" r="24" pathLength="100"/></svg><svg class="dla" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v13M6 12l6 6 6-6"/></svg><svg class="dlx" viewBox="0 0 24 24" aria-hidden="true"><path d="M7 7l10 10M17 7L7 17"/></svg></button></div>`;
/* v94: vídeo de outra pessoa — o botão baixa o arquivo INTEIRO (com progresso real) e guarda no aparelho; ao tocar no vídeo ele abre do arquivo local, sem travar */
const VQ='qvid-v1',VQI='qvc',VQMAX=12,VMEM=new Map();
const vidIdx=()=>{try{return JSON.parse(localStorage.getItem(VQI)||'[]')}catch(e){return[]}};
async function vidKeep(url,bl){
 VMEM.delete(url);VMEM.set(url,bl);while(VMEM.size>3)VMEM.delete(VMEM.keys().next().value);
 try{const c=await caches.open(VQ);await c.put(url,new Response(bl,{headers:{'Content-Type':bl.type||'video/mp4'}}));
  let ix=vidIdx().filter(x=>x!=url);ix.push(url);while(ix.length>VQMAX){const o=ix.shift();await c.delete(o)}
  localStorage.setItem(VQI,JSON.stringify(ix))}catch(e){}}
async function vidLocal(url){
 if(VMEM.has(url))return VMEM.get(url);
 try{const c=await caches.open(VQ),r=await c.match(url);if(r){const b=await r.blob();VMEM.set(url,b);return b}}catch(e){}
 return null}
async function vidFetch(url,onP,sig){
 const r=await fetch(url,{signal:sig});if(!r.ok)throw new Error('http '+r.status);
 const ct=r.headers.get('content-type')||'',type=/^video\//.test(ct)?ct:(/\.webm(\?|#|$)/i.test(url)?'video/webm':'video/mp4'),tot=+r.headers.get('content-length')||0;
 if(!r.body||!r.body.getReader){const b=await r.blob();onP(1);return new Blob([b],{type})}
 const rd=r.body.getReader(),parts=[];let got=0;
 for(;;){const x=await rd.read();if(x.done)break;parts.push(x.value);got+=x.value.length;onP(tot?Math.min(1,got/tot):-1)}
 if(tot&&got<tot)throw new Error('incompleto');
 onP(1);return new Blob(parts,{type})}
function dlRing(w,p){const r=$('.dlp',w);if(!r)return;r.style.transition='stroke-dashoffset .25s linear';r.style.strokeDashoffset=String(p<0?60:78-74*p)}
function dlToggle(w){if(!w)return;const id=w.dataset.dl,p=$('.dlp',w),j=DLJ.get(id);
 if(j){/* toque de novo = cancela */if(j.ac){try{j.ac.abort()}catch(e){}}else clearTimeout(j);DLJ.delete(id);w.classList.remove('go');p.style.transition='none';p.style.strokeDashoffset='78';return}
 const m=CH.msgs.find(x=>x.id==id);if(!m)return;
 p.style.transition='none';p.style.strokeDashoffset='78';void p.getBoundingClientRect();w.classList.add('go');
 if(isVid(m)){const ac=new AbortController();DLJ.set(id,{ac});dlRing(w,0.04);
  vidFetch(m.i,v=>dlRing(w,v),ac.signal).then(bl=>vidKeep(m.i,bl)).then(()=>{if(DLJ.get(id)&&DLJ.get(id).ac===ac){DLJ.delete(id);dlDone(w,id)}})
   .catch(e=>{if(DLJ.get(id)&&DLJ.get(id).ac===ac)DLJ.delete(id);else return;w.classList.remove('go');p.style.transition='none';p.style.strokeDashoffset='78';if(!(e&&e.name=='AbortError'))toast('Não foi possível baixar o vídeo. Toque para tentar de novo.',3200)});return}
 const ms=Math.min(2600,Math.max(900,Math.round(m.i.length/170)));
 p.style.transition=`stroke-dashoffset ${ms}ms cubic-bezier(.4,.1,.3,1)`;p.style.strokeDashoffset='4';
 DLJ.set(id,setTimeout(()=>{DLJ.delete(id);dlDone(w,id)},ms))}
function dlDone(w,id){DLD.add(id);dlSave();w.classList.remove('go');w.classList.add('ok');
 /* v93: troca no lugar (mesma imagem, mesmo tamanho), com altura travada e scroll preservado — sem tremer */
 setTimeout(()=>{const m=CH.msgs.find(x=>x.id==id),row=w.closest('.cr');if(cht.hidden||!m||!row||!row.isConnected)return;
  const cb=$('.cb',row),h=cb.offsetHeight,st=chl.scrollTop;cb.style.minHeight=h+'px';
  const b=chBody(m,meId(),new Set(gAdmins()));cb.innerHTML=b;row._b=b;chl.scrollTop=st;
  setTimeout(()=>{cb.style.minHeight='';chl.scrollTop=st},350)},560)}

const gset=$('#gset');
function gsetPaint(){const g=$('#gsetb');if(!g||!gset||gset.hidden)return;const r=(CH.gd||{}).gr||{},adm=gIsAdm(meId());
 const sw=(k,t,s)=>`<div class="gi-r"><div><b>${t}</b><small>${s}</small></div><button class="gi-sw" type="button" role="switch" data-r="${k}" aria-checked="${r[k]!==false}" aria-label="${t}"${adm?'':' disabled'}><i></i></button></div>`;
 g.innerHTML=sw('m','Enviar mensagens','Membros podem escrever no grupo')+sw('i','Enviar fotos','Membros podem enviar imagens')+sw('a','Enviar áudios','Membros podem gravar e enviar áudios')}
$('#gigear').onclick=()=>{if(!gIsAdm(meId()))return;gset.hidden=false;gsetPaint();requestAnimationFrame(()=>gset.classList.add('on'))};
gset.onclick=e=>{if(e.target.closest('[data-x]')){prsHide(gset);return}
 const sw=e.target.closest('.gi-sw');if(!sw||sw.disabled)return;const k=sw.dataset.r,on=sw.getAttribute('aria-checked')=='true';sw.setAttribute('aria-checked',String(!on));
 gSave({['gr.'+k]:!on}).then(ok=>{if(!ok)gsetPaint()})};


/* ===== v88: Configurações > Conta (nome, troca de e-mail em 4 passos, senha, exclusão) ===== */
const CNK='qx-pend-email',cnCU=()=>FB&&FB.auth&&FB.auth.currentUser,cnEm=v=>String(v||'').trim().toLowerCase(),cnOkEm=v=>/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v);
const cnPw=()=>{const u=cnCU();return !!u&&u.providerData.some(p=>p.providerId=='password')};
const cnGG='<svg class="g" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.5 5.4 2.6 13.2l7.9 6.1C12.4 13.5 17.7 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.6 5.9c4.4-4.1 7-10.1 7-17.6z"/><path fill="#FBBC05" d="M10.5 28.7A14.5 14.5 0 019.5 24c0-1.6.3-3.2.8-4.7l-7.9-6.1A24 24 0 000 24c0 3.9.9 7.5 2.6 10.8l7.9-6.1z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.6-5.9c-2.1 1.4-4.9 2.3-8.3 2.3-6.3 0-11.6-4-13.5-9.8l-7.9 6.1C6.5 42.6 14.6 48 24 48z"/></svg>';
const CNE={'auth/wrong-password':'Senha incorreta.','auth/invalid-credential':'Senha incorreta.','auth/invalid-login-credentials':'Senha incorreta.','auth/too-many-requests':'Muitas tentativas. Aguarde um pouco e tente de novo.','auth/email-already-in-use':'Esse e-mail já está em uso por outra conta.','auth/invalid-email':'E-mail inválido.','auth/weak-password':'Senha fraca. Use pelo menos 6 caracteres.','auth/network-request-failed':'Sem ligação à internet.','auth/popup-closed-by-user':'Você fechou a janela do Google.','auth/cancelled-popup-request':'Você fechou a janela do Google.','auth/popup-blocked':'O navegador bloqueou a janela do Google. Permita pop-ups e tente de novo.','auth/user-mismatch':'Entre com a conta Google correta.','auth/requires-recent-login':'Por segurança, confirme que é você de novo.','auth/credential-already-in-use':'Essa credencial já está em uso.','auth/provider-already-linked':'Essa conta já tem senha.','auth/operation-not-allowed':'Troca de e-mail não está ativa no Firebase (veja as instruções).','auth/unauthorized-continue-uri':'Domínio não autorizado no Firebase (Authentication > Settings > Authorized domains).'};
const cnErr=e=>CNE[e&&e.code]||'Não foi possível concluir. Tente novamente.';
let CN={step:0,kind:'',from:'',to:'',t:0,left:0,busy:false,after:null};
const cnPend=()=>{try{const p=JSON.parse(localStorage.getItem(CNK)||'null');return p&&p.uid==uid&&p.email?p:null}catch(e){return null}};
const cnSetPend=p=>{try{p?localStorage.setItem(CNK,JSON.stringify({uid,email:p})):localStorage.removeItem(CNK)}catch(e){}};
function cnFill(){const u=S.u,p=S.profile||{};if(!u)return;
 if(document.activeElement!==$('#cnnm'))$('#cnnm').value=u.name||'';
 if(document.activeElement!==$('#cnem')&&!$('#cnem').dataset.d)$('#cnem').value=u.email||'';
 const ini=(u.name||'?').trim().slice(0,1).toUpperCase(),un=p.username||'';
 $('#cnav').textContent=ini;$('#cnmn').textContent=un||u.name;$('#cnmu').textContent=un?'@'+un:'';
 $('#cnop2').textContent=un?'@'+un:'Escolha seu @ primeiro';$('#cnpl2').textContent=u.plan=='free'?'Faça upgrade para liberar mais recursos':'Plano '+PL[u.plan].n;
 $('#cnpl3').textContent={free:'Free',plus:'Plus',pro:'Pro'}[u.plan];$('#cnti').textContent=u.email||'';
 const pw=cnPw();$('#cnpwt').textContent=pw?'Alterar sua senha':'Crie sua senha';
 const pd=cnPend();if(pd&&cnCU()&&cnEm(cnCU().email)==cnEm(pd.email)){cnSetPend(null);$('#cnpd').hidden=true}else{$('#cnpd').hidden=!pd;$('#cnpde').textContent=pd?pd.email:''}
 cnDirty()}
function cnDirty(){const u=S.u;if(!u)return;const n=$('#cnnm').value.trim(),e=cnEm($('#cnem').value),ch=(n&&n!==u.name)||(e&&e!==cnEm(u.email));
 $('#cnem').dataset.d=e&&e!==cnEm(u.email)?'1':'';$('#cnsv').disabled=!ch;const er=$('#cner');if(!er.hidden&&!ch)er.hidden=true}
$('#cnnm').oninput=$('#cnem').oninput=()=>{$('#cner').hidden=true;cnDirty()};
$('#cnbk').onclick=()=>go('profile');
$('#cnop').onclick=()=>{const u=S.profile&&S.profile.username;if(!u){toast('Você ainda não tem um @username.');return}open(pubHost()+'#/'+u,'_blank','noopener')};
$('#cnpl').onclick=()=>{location.hash='planos'};
$('#cnpd').onclick=()=>{const p=cnPend();if(!p)return;CN.from=cnEm(S.u.email);CN.to=p.email;cnOpen();cnStep(3)};
$('#cnsv').onclick=async()=>{const u=S.u,n=$('#cnnm').value.trim(),e=cnEm($('#cnem').value),er=$('#cner');er.hidden=true;
 if(!n){er.textContent='Digite seu nome.';er.hidden=false;return}
 if(e&&e!==cnEm(u.email)&&!cnOkEm(e)){er.textContent='Digite um e-mail válido.';er.hidden=false;return}
 const b=$('#cnsv');
 if(n!==u.name){b.disabled=true;u.name=n;try{const cu=cnCU();if(cu)await FB.updateProfile(cu,{displayName:n})}catch(x){console.error(x)}save();hdr();if(e==cnEm(u.email)||!e){playSound('success');vibrate('success');toast('Informações salvas!',2500)}}
 if(e&&e!==cnEm(u.email)){CN.from=cnEm(u.email);CN.to=e;cnOpen();const pd=cnPend();if(pd&&pd.email==e)cnStep(3);else cnStep(1)}
 cnFill()};

/* painel (sheet) */
const cns=$('#cns');
function cnOpen(){CN.busy=false;clearInterval(CN.t);cns.hidden=false;document.body.style.overflow='hidden';requestAnimationFrame(()=>cns.classList.add('on'))}
function cnClose(){clearInterval(CN.t);cns.classList.remove('on');document.body.style.overflow='';setTimeout(()=>{if(!cns.classList.contains('on'))cns.hidden=true},260);cnFill()}
cns.addEventListener('click',e=>{if(e.target.closest('[data-x]')){if(CN.step==4&&CN.kind=='email')return cnOut();cnClose()}});
$('#cnsb').onclick=()=>{if(CN.busy)return;if(CN.kind=='email'){if(CN.step==2)cnStep(1);else if(CN.step==3)cnStep(1)}else if(CN.back)CN.back()};
const cnMsg=t=>{const e=$('#cnsbd .cns-er');if(e){e.textContent=t;e.hidden=!t}};
const cnLd=(b,on)=>{if(on){b.dataset.h=b.innerHTML;b.disabled=true;b.innerHTML='<span class="spin"></span>'}else{b.disabled=false;if(b.dataset.h)b.innerHTML=b.dataset.h}};
function cnPaint(o){/* o: {t,bar,back,ic,ico,st,h,p,html} */
 $('#cnst').textContent=o.t;$('#cnspb').style.width=o.bar+'%';$('#cnsb').hidden=!o.back;
 $('#cnsbd').innerHTML=`<div class="cns-ci ${o.ico||''}">${I(o.ic)}</div>${o.st?`<div class="cns-st">${o.st}</div>`:''}<h3>${o.h}</h3>${o.p?`<p>${o.p}</p>`:''}${o.html||''}`;
 $('#cnsbd').style.animation='none';void $('#cnsbd').offsetWidth;$('#cnsbd').style.animation=''}
const cnEsc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
async function cnReauth(pass){const cu=cnCU();if(!cu)throw{code:'auth/user-not-found'};
 if(cnPw()&&pass!=null){await FB.reauthenticateWithCredential(cu,FB.EmailAuthProvider.credential(cu.email,pass))}
 else{const p=new FB.GoogleAuthProvider();p.setCustomParameters({login_hint:cu.email});await FB.reauthenticateWithPopup(cu,p)}}
/* bloco "confirme que é você" reutilizado (e-mail, senha, exclusão) */
function cnConfirmHtml(){const cu=cnCU(),pw=cnPw();
 return pw?`<input class="cns-in" id="cnsp" type="password" placeholder="Sua senha atual" autocomplete="current-password"><button class="cns-b" id="cnsg" type="button">Continuar</button><p class="cns-er" hidden></p>`
  :`<div class="cns-kv"><span>Conta Google</span><b>${cnEsc(cu?cu.email:'')}</b></div><button class="cns-b gg" id="cnsg" type="button">${cnGG}Continuar com o Google</button><p class="cns-er" hidden></p>`}
function cnConfirmBind(ok){const b=$('#cnsg'),pw=cnPw(),inp=$('#cnsp');
 const run=async()=>{if(pw&&!inp.value){cnMsg('Digite sua senha.');return}cnMsg('');CN.busy=true;cnLd(b,true);
  try{await cnReauth(pw?inp.value:null);CN.busy=false;await ok()}catch(e){CN.busy=false;cnLd(b,false);cnMsg(cnErr(e))}};
 b.onclick=run;if(inp){inp.onkeydown=e=>{if(e.key=='Enter')run()};setTimeout(()=>inp.focus(),320)}}

/* ---- troca de e-mail ---- */
function cnStep(n){CN.step=n;CN.kind='email';
 if(n==1){cnPaint({t:'Trocar e-mail',bar:25,back:false,ic:'mail',st:'PASSO 1 DE 4',h:'Trocar o seu e-mail?',p:'Vamos enviar um link para o novo endereço. Seu e-mail só muda depois que você confirmar.',
  html:`<div class="cns-kv"><span>De</span><b>${cnEsc(CN.from)}</b></div><div class="cns-kv"><span>Para</span><b>${cnEsc(CN.to)}</b></div><button class="cns-b" id="cn1">Continuar</button><button class="cns-l" id="cn1b">Corrigir e-mail</button>`});
  $('#cn1').onclick=()=>cnStep(2);$('#cn1b').onclick=()=>{cnClose();setTimeout(()=>$('#cnem').focus(),300)}}
 if(n==2){cnPaint({t:'Confirme que é você',bar:50,back:true,ic:'lock',st:'PASSO 2 DE 4',h:'Confirme que é você',p:cnPw()?'Digite sua senha para enviarmos o link de confirmação.':'Entre de novo com o Google para enviarmos o link de confirmação.',html:cnConfirmHtml()});
  cnConfirmBind(async()=>{CN.reauthed=1;await cnSend(true)})}
 if(n==3){cnPaint({t:'Verifique seu e-mail',bar:75,back:true,ic:'mail',st:'PASSO 3 DE 4',h:'Enviamos um link',p:`Para <b>${cnEsc(CN.to)}</b>`,
  html:`<ol class="cns-ol"><li><i>1</i>Abra o e-mail que enviamos (veja também o spam)</li><li><i>2</i>Toque no link de confirmação</li><li><i>3</i>Volte aqui e toque em “Já confirmei”</li></ol><p class="cns-er" hidden></p><button class="cns-b" id="cn3">Já confirmei</button><button class="cns-l" id="cn3r" disabled></button>`});
  $('#cn3').onclick=cnCheck;$('#cn3r').onclick=()=>cnSend(false);cnTick()}
 if(n==4){cnPaint({t:'E-mail confirmado',bar:100,back:false,ic:'ck',ico:'ok',h:'E-mail confirmado',p:`Seu e-mail agora é <b>${cnEsc(CN.to)}</b>. Por segurança, entre de novo com ele.`,html:'<button class="cns-b" id="cn4">Entrar de novo</button>'});
  $('#cn4').onclick=cnOut}}
function cnTick(){clearInterval(CN.t);const r=$('#cn3r');if(!r)return;CN.left=Math.max(0,60-Math.floor((Date.now()-(CN.sent||0))/1000));
 const p=()=>{const b=$('#cn3r');if(!b||CN.step!=3){clearInterval(CN.t);return}if(CN.left>0){b.disabled=true;b.textContent='Reenviar em 0:'+String(CN.left).padStart(2,'0');b.style.color='var(--mut)'}else{b.disabled=false;b.textContent='Reenviar e-mail';b.style.color='';clearInterval(CN.t)}};
 p();CN.t=setInterval(()=>{CN.left--;p()},1000)}
async function cnSend(first){const cu=cnCU();if(!cu){cnMsg('Sessão expirada. Entre de novo.');return}
 const b=first?$('#cnsg'):$('#cn3r');if(!first){b.disabled=true;b.textContent='Enviando…'}
 try{await FB.verifyBeforeUpdateEmail(cu,CN.to);CN.sent=Date.now();cnSetPend(CN.to);if(first||CN.step!=3)cnStep(3);else{cnTick();toast('Link reenviado.',2500)}}
 catch(e){console.error(e);if(e&&e.code=='auth/requires-recent-login'){CN.reauthed=0;cnStep(2);setTimeout(()=>cnMsg(cnErr(e)),50);return}
  if(first){CN.busy=false;const g=$('#cnsg');if(g)cnLd(g,false);cnMsg(cnErr(e))}else{cnTick();cnMsg(cnErr(e))}}}
async function cnCheck(){const b=$('#cn3'),cu=cnCU();if(CN.busy)return;CN.busy=true;cnLd(b,true);cnMsg('');let done=false;
 try{if(!cu)throw{code:'auth/user-token-expired'};await FB.reload(cu);done=cnEm(cu.email)==cnEm(CN.to)}
 catch(e){const c=e&&e.code;if(c=='auth/user-token-expired'||c=='auth/invalid-user-token'||c=='auth/user-disabled'||c=='auth/id-token-revoked')done=true;else{console.error(e)}}
 CN.busy=false;
 if(done){cnSetPend(null);try{S.u.email=CN.to;save()}catch(x){}cnStep(4)}
 else{cnLd(b,false);cnMsg(`Ainda não confirmado. Abra o link que enviamos para ${CN.to} e tente de novo.`)}}
async function cnOut(){clearInterval(CN.t);const b=$('#cn4');if(b)cnLd(b,true);try{await Promise.race([flush(),new Promise(r=>setTimeout(r,2500))])}catch(e){}
 cns.classList.remove('on');document.body.style.overflow='';cns.hidden=true;try{await FB.signOut(FB.auth)}catch(e){console.error(e)}}

/* ---- senha ---- */
$('#cnpw').onclick=()=>{const pw=cnPw();CN.kind='pw';CN.step=1;cnOpen();
 const form=()=>{CN.back=pw?null:()=>cnAsk();
  cnPaint({t:pw?'Alterar senha':'Criar senha',bar:70,back:!pw,ic:'lock',h:pw?'Escolha uma nova senha':'Crie sua senha',p:'Use pelo menos 6 caracteres.',
   html:`<input class="cns-in" id="cnn1" type="password" placeholder="Nova senha" autocomplete="new-password"><input class="cns-in" id="cnn2" type="password" placeholder="Repita a nova senha" autocomplete="new-password"><p class="cns-er" hidden></p><button class="cns-b" id="cnng">Salvar senha</button>`});
  $('#cnng').onclick=async()=>{const a=$('#cnn1').value,c=$('#cnn2').value,b=$('#cnng');if(a.length<6){cnMsg('A senha precisa ter pelo menos 6 caracteres.');return}if(a!=c){cnMsg('As senhas não coincidem.');return}
   cnMsg('');CN.busy=true;cnLd(b,true);const cu=cnCU();
   try{if(pw)await FB.updatePassword(cu,a);else await FB.linkWithCredential(cu,FB.EmailAuthProvider.credential(cu.email,a));
    CN.busy=false;cnPaint({t:'Senha salva',bar:100,back:false,ic:'ck',ico:'ok',h:'Senha salva',p:pw?'Sua senha foi alterada.':'Agora você pode entrar com seu e-mail e senha.',html:'<button class="cns-b" id="cnok">Concluir</button>'});$('#cnok').onclick=cnClose}
   catch(e){CN.busy=false;cnLd(b,false);if(e&&e.code=='auth/requires-recent-login'){cnAsk(true);return}cnMsg(cnErr(e))}}};
 const cnAsk=err=>{CN.back=null;cnPaint({t:'Confirme que é você',bar:35,back:false,ic:'lock',h:'Confirme que é você',p:cnPw()?'Digite sua senha atual para continuar.':'Entre de novo com o Google para continuar.',html:cnConfirmHtml()});cnConfirmBind(async()=>form());if(err)setTimeout(()=>cnMsg('Por segurança, confirme que é você de novo.'),50)};
 cnAsk()};

/* ---- exclusão ---- */
$('#cndl').onclick=()=>{CN.kind='del';CN.step=1;cnOpen();CN.back=null;
 cnPaint({t:'Excluir conta',bar:30,back:false,ic:'trash',ico:'rd',h:'Excluir sua conta?',p:'Isso apaga para sempre a sua conta, a sua página e o seu @. Não dá para desfazer.',html:'<button class="cns-b rd" id="cnd1">Continuar</button><button class="cns-l" id="cnd0">Cancelar</button>'});
 $('#cnd0').onclick=cnClose;
 $('#cnd1').onclick=()=>{CN.back=()=>$('#cndl').onclick();cnPaint({t:'Confirme que é você',bar:60,back:true,ic:'lock',h:'Confirme que é você',p:cnPw()?'Digite sua senha para excluir a conta.':'Entre de novo com o Google para excluir a conta.',html:cnConfirmHtml()});
  cnConfirmBind(async()=>{const b=$('#cnsg');cnLd(b,true);CN.busy=true;const cu=cnCU(),id=cu.uid,un=S.profile&&S.profile.username;
   try{clearTimeout(saveT);uid=null;cloudOK=false;
    if(un){for(const c of ['pages','dir'])try{await FB.deleteDoc(FB.doc(FB.db,c,un))}catch(e){console.error(c,e)}
     try{await FB.deleteDoc(FB.doc(FB.db,'usernames',un))}catch(e){console.error('usernames',e)}}
    await FB.deleteDoc(FB.doc(FB.db,'users',id));
    await FB.deleteUser(cu);cnSetPend(null);
    cnPaint({t:'Conta excluída',bar:100,back:false,ic:'ck',ico:'ok',h:'Conta excluída',p:'Sua conta e a sua página foram apagadas.',html:'<button class="cns-b" id="cnok">Fechar</button>'});
    $('#cnok').onclick=()=>{cns.classList.remove('on');document.body.style.overflow='';cns.hidden=true;location.hash='inicio'}}
   catch(e){console.error(e);CN.busy=false;uid=id;cloudOK=true;cnLd(b,false);cnMsg(e&&e.code=='permission-denied'?'Sem permissão para apagar. Publique as regras novas do Firebase.':cnErr(e))}})}};
